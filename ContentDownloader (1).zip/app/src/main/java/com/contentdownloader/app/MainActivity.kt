package com.contentdownloader.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var polling = false

    // setup screen widgets
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var go: Button

    private val prefs get() = getSharedPreferences("app", MODE_PRIVATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (prefs.getBoolean("setup_done", false)) showMain() else showSetup()
    }

    private fun mb(n: Long) = String.format(Locale.US, "%.1f MB", n / 1048576.0)

    // ------------------------------------------------------------------ first-time setup
    private fun showSetup() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        col.addView(TextView(this).apply { text = "Content Downloader"; textSize = 26f; setTextColor(Color.WHITE) })
        col.addView(TextView(this).apply {
            text = "First-time setup"; textSize = 16f; setTextColor(Color.LTGRAY); setPadding(0, 4, 0, pad)
        })
        info = TextView(this).apply { textSize = 15f; setTextColor(Color.WHITE); text = "Checking sizes\u2026" }
        col.addView(info)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; setPadding(0, pad, 0, 0) }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        status = TextView(this).apply { textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 12, 0, pad) }
        col.addView(status)
        go = Button(this).apply { text = "Start setup"; isEnabled = false; setOnClickListener { begin() } }
        col.addView(go)
        setContentView(ScrollView(this).apply { addView(col) })

        Thread {
            val ff = Core.ffmpegSize(this)
            var yt = "checking\u2026"
            var ytSize = 0L
            try { val i = Core.prepareForInfo(this); ytSize = i.second; yt = "${mb(i.second)} (version ${i.first})" } catch (e: Throwable) {
                yt = "could not check (no internet?)"
            }
            val total = ytSize
            ui.post {
                info.text = "Items\n\n" +
                    "1.  Python engine \u2013 built into the app\n" +
                    "2.  ffmpeg (merge video + MP3) \u2013 ${mb(ff)}, built in, will be unpacked (about ${mb(ff * 2)} of space)\n" +
                    "3.  yt-dlp (YouTube engine) \u2013 download ${yt}\n\n" +
                    "Internet download: ${if (total > 0) mb(total) else "about 3 MB"}\n" +
                    "The app asks for storage permission so files can be saved in Download/Content Downloader."
                go.isEnabled = true
            }
        }.start()
    }

    private fun begin() {
        go.isEnabled = false
        if (Build.VERSION.SDK_INT >= 23 && !Core.hasStorage(this)) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 7)
        } else runSetup()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 7) runSetup()
    }

    private fun runSetup() {
        status.text = "Preparing\u2026"
        val tick = object : Runnable {
            override fun run() {
                try {
                    val (stage, done, total) = Core.progress()
                    if (stage.isNotEmpty() && stage != "done") {
                        bar.progress = if (total > 0) (done * 1000 / total).toInt() else 0
                        status.text = "$stage  \u2022  ${mb(done)} / ${mb(total)}  (${if (total > 0) done * 100 / total else 0}%)"
                    }
                } catch (e: Throwable) { }
                if (polling) ui.postDelayed(this, 300)
            }
        }
        polling = true
        Thread {
            try {
                ui.post { status.text = "Unpacking ffmpeg\u2026" }
                Core.prepare(this)
                ui.post { ui.post(tick) }
                Core.ytdlpInstall()
                if (!Core.ffmpegOk()) {
                    ui.post { status.text = "The built-in ffmpeg could not start. Downloading another one\u2026" }
                    Core.ffmpegDownload()
                }
                polling = false
                if (Core.ffmpegOk()) {
                    prefs.edit().putBoolean("setup_done", true).apply()
                    ui.post { Toast.makeText(this, "Setup finished", Toast.LENGTH_SHORT).show(); showMain() }
                } else {
                    val msg = Core.ffmpegMsg()
                    ui.post {
                        status.text = "yt-dlp is ready, but ffmpeg (needed to merge video and audio) does not run on this phone:\n\n$msg"
                        go.text = "Continue anyway"; go.isEnabled = true
                        go.setOnClickListener {
                            prefs.edit().putBoolean("setup_done", true).apply(); showMain()
                        }
                    }
                }
            } catch (e: Throwable) {
                polling = false
                ui.post {
                    status.text = "Setup failed: ${e.message}\n\nCheck your internet and tap Retry."
                    go.text = "Retry"; go.isEnabled = true
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ the app itself (WebView)
    private fun showMain() {
        val w = WebView(this)
        web = w
        val loading = TextView(this).apply {
            text = "Starting\u2026"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val root = android.widget.FrameLayout(this)
        root.addView(w, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(loading, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val h = r.url.host ?: ""
                if (h == "127.0.0.1" || h == "localhost") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }
            override fun onPageFinished(v: WebView, url: String) { loading.visibility = View.GONE }
        }
        w.setDownloadListener { _, _, _, _, _ ->
            Toast.makeText(this, "Finished files are in Download/Content Downloader", Toast.LENGTH_LONG).show()
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try {
                    startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 9)
                    true
                } catch (e: Exception) { chooser = null; false }
            }
            override fun onJsAlert(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }.show(); return true
            }
            override fun onJsConfirm(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }.show(); return true
            }
            override fun onJsPrompt(v: WebView, url: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val et = EditText(this@MainActivity).apply { setText(d ?: "") }
                AlertDialog.Builder(this@MainActivity).setMessage(m).setView(et).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> r.confirm(et.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }.show(); return true
            }
            override fun onConsoleMessage(c: ConsoleMessage?): Boolean = true
        }

        val svc = Intent(this, ServerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)

        Thread {
            var ok = false
            for (i in 0 until 180) {
                val p = Core.port
                if (p != 0) {
                    try {
                        val c = URL("http://127.0.0.1:$p/api/ping").openConnection() as HttpURLConnection
                        c.connectTimeout = 1000; c.readTimeout = 1500
                        if (c.responseCode == 200) { ok = true; c.disconnect(); break }
                        c.disconnect()
                    } catch (e: Exception) { }
                }
                try { Thread.sleep(500) } catch (e: InterruptedException) { }
            }
            ui.post {
                if (ok) w.loadUrl("http://127.0.0.1:${Core.port}/")
                else loading.text = "The app could not start. Close it fully and open it again."
            }
        }.start()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 9) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            chooser = null
        }
    }

    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else moveTaskToBack(true)
    }
}
