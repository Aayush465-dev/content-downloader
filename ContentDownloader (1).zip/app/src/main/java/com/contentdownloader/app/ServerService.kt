package com.contentdownloader.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Keeps the downloader alive in the background and shows what it is doing. */
class ServerService : Service() {
    private var started = false
    private var wake: PowerManager.WakeLock? = null
    @Volatile private var alive = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            alive = false
            try { wake?.release() } catch (e: Exception) { }
            stopForeground(true)
            stopSelf()
            android.os.Process.killProcess(android.os.Process.myPid())
            return START_NOT_STICKY
        }
        startForeground(1, build("Starting\u2026", "Content Downloader"))
        if (!started) {
            started = true
            Thread { try { Core.serveForever(this) } catch (e: Throwable) { e.printStackTrace() } }.start()
            Thread { poll() }.start()
        }
        return START_STICKY
    }

    private fun poll() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "contentdownloader:dl")
        var last = ""
        while (alive) {
            var title = "Content Downloader"
            var text = "Starting\u2026"
            var busy = false
            val p = Core.port
            if (p != 0) {
                try {
                    val c = URL("http://127.0.0.1:$p/api/jobs").openConnection() as HttpURLConnection
                    c.connectTimeout = 1500; c.readTimeout = 2500
                    val js = JSONObject(c.inputStream.bufferedReader().readText())
                    c.disconnect()
                    val s = js.optJSONObject("summary")
                    val act = s?.optInt("active") ?: 0
                    val q = s?.optInt("queued") ?: 0
                    val sp = s?.optDouble("speed") ?: 0.0
                    busy = act + q > 0
                    text = when {
                        act > 0 -> "Downloading $act" + (if (q > 0) " \u00b7 waiting $q" else "") +
                            (if (sp > 0) " \u00b7 %.1f MB/s".format(sp / 1e6) else "")
                        q > 0 -> "Waiting: $q"
                        else -> "Ready"
                    }
                } catch (e: Exception) { text = "Starting\u2026" }
            }
            try {
                if (busy && wake?.isHeld == false) wake?.acquire()
                if (!busy && wake?.isHeld == true) wake?.release()
            } catch (e: Exception) { }
            if (text != last) {
                last = text
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1, build(text, title))
            }
            try { Thread.sleep(3000) } catch (e: InterruptedException) { }
        }
    }

    private fun build(text: String, title: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("dl", "Downloads", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ServerService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "dl")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Stop app", stop)
            .build()
    }

    override fun onDestroy() { alive = false; super.onDestroy() }
}
