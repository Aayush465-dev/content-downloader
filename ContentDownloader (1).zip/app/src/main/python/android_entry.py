"""Bridge between the Android app (Kotlin) and yt_batch.py."""
import importlib
import os
import socket
import sys

_yt = None
_paths = {"bin": "", "ff": ""}
_log = []
FF_URL = ("https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/"
          "ffmpeg-master-latest-linuxarm64-gpl.tar.xz")


def _diag(line):
    _log.append(line)
    try:
        with open(os.environ["CD_FFDIAG"], "w", encoding="utf-8") as f:
            f.write("\n".join(_log[-12:]))
    except Exception:
        pass


def _is_elf(p):
    try:
        with open(p, "rb") as f:
            return f.read(4) == b"\x7fELF"
    except OSError:
        return False


def _try(cmd):
    """start `cmd -version`; True only if it really prints an ffmpeg banner"""
    import subprocess
    try:
        r = subprocess.run(cmd + ["-version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, errors="replace", timeout=30)
        out = (r.stdout or "").strip()
        return (r.returncode == 0 and "ffmpeg version" in out), ("exit %s: %s" % (r.returncode, out[:160].replace("\n", " | ")))
    except Exception as e:
        return False, "%s: %s" % (type(e).__name__, e)


def _launcher(bin_dir, target, via_linker):
    link = os.path.join(bin_dir, "ffmpeg")
    try:
        os.remove(link)
    except OSError:
        pass
    if via_linker:
        with open(link, "w") as f:
            f.write('#!/system/bin/sh\nexec /system/bin/linker64 "%s" "$@"\n' % target)
    else:
        try:
            os.symlink(target, link)
        except OSError:
            import shutil
            shutil.copy(target, link)
    os.chmod(link, 0o755)


def find_ffmpeg(ff_dir, bin_dir):
    """test every possible ffmpeg file the app carries; set up bin/ffmpeg for the first that really runs"""
    os.makedirs(bin_dir, exist_ok=True)
    link = os.path.join(bin_dir, "ffmpeg")
    if os.path.exists(link):
        ok, out = _try([link])
        if ok:
            return True
        _diag("existing launcher failed: " + out)
    cands = []
    for root, _, files in os.walk(ff_dir or "/nonexistent"):
        for f in files:
            p = os.path.join(root, f)
            if "ffmpeg" in f.lower() and _is_elf(p):
                cands.append(p)
    cands.sort(key=lambda p: (os.path.basename(p) != "ffmpeg", os.path.basename(p) != "libffmpeg.so", p))
    if not cands:
        _diag("no ffmpeg program found inside the app")
    for c in cands:
        try:
            os.chmod(c, 0o755)
        except OSError:
            pass
        ok, out = _try([c])
        _diag("direct %s -> %s" % (os.path.relpath(c, ff_dir), out))
        if ok:
            _launcher(bin_dir, c, False)
            break
        if os.path.exists("/system/bin/linker64"):
            ok, out = _try(["/system/bin/linker64", c])
            _diag("via linker %s -> %s" % (os.path.basename(c), out))
            if ok:
                _launcher(bin_dir, c, True)
                break
    for root, _, files in os.walk(ff_dir or "/nonexistent"):
        for f in files:
            if "ffprobe" in f.lower() and _is_elf(os.path.join(root, f)):
                lp = os.path.join(bin_dir, "ffprobe")
                try:
                    os.remove(lp)
                    os.symlink(os.path.join(root, f), lp)
                except OSError:
                    pass
    return os.path.exists(link) and _try([link])[0]


def ffmpeg_ok():
    return bool(_yt.ffmpeg_check(True))


def ffmpeg_msg():
    _yt.ffmpeg_check(True)
    return _yt.FF["msg"]


def ffmpeg_download():
    """fallback: download a ready-made static ffmpeg (about 40 MB) when the built-in one cannot start"""
    import tarfile
    import urllib.request as ureq
    try:
        import lzma  # noqa: F401
    except ImportError:
        _diag("download skipped: no xz support")
        return False
    prog = _yt.INSTALL_PROGRESS
    req = ureq.Request(FF_URL, headers={"User-Agent": "ContentDownloader"})
    bin_dir = _paths["bin"]
    with ureq.urlopen(req, timeout=60) as r:
        prog.update(stage="Downloading ffmpeg", done=0, total=int(r.headers.get("Content-Length") or 0))

        class Counter:
            def read(self, n=-1):
                b = r.read(n)
                prog["done"] += len(b)
                return b

        tar = tarfile.open(fileobj=Counter(), mode="r|xz")
        got = set()
        for m in tar:
            name = os.path.basename(m.name)
            if m.isfile() and name in ("ffmpeg", "ffprobe") and "/bin/" in m.name:
                dst = os.path.join(bin_dir, name + ".new")
                with open(dst, "wb") as o:
                    while True:
                        b = tar.extractfile(m).read(1 << 20)
                        if not b:
                            break
                        o.write(b)
                os.chmod(dst, 0o755)
                os.replace(dst, os.path.join(bin_dir, name))
                got.add(name)
                if name == "ffmpeg":
                    break
        tar.close()
    prog["stage"] = "done"
    ok, out = _try([os.path.join(bin_dir, "ffmpeg")])
    _diag("downloaded ffmpeg -> %s" % out)
    return ok


def prepare(files_dir, out_dir, ytdlp_dir, bin_dir, lib_dirs, ff_dir=""):
    global _yt
    os.environ["HOME"] = files_dir
    os.environ["CD_OUT"] = out_dir
    os.environ["CD_YTDLP_DIR"] = ytdlp_dir
    os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")
    if lib_dirs:
        old = os.environ.get("LD_LIBRARY_PATH", "")
        os.environ["LD_LIBRARY_PATH"] = lib_dirs + (os.pathsep + old if old else "")
    os.makedirs(files_dir + "/.tube_local", exist_ok=True)
    os.environ["CD_FFDIAG"] = files_dir + "/ffmpeg_diag.txt"
    _paths["bin"], _paths["ff"] = bin_dir, ff_dir
    try:
        find_ffmpeg(ff_dir, bin_dir)
    except Exception as e:
        _diag("find_ffmpeg crashed: %s: %s" % (type(e).__name__, e))
    _yt = importlib.import_module("yt_batch")


def ytdlp_info():
    i = _yt.ytdlp_latest_info()
    return "%s|%d" % (i["version"], i["size"])


def ytdlp_install():
    _yt.install_wheel()
    importlib.invalidate_caches()
    import yt_dlp
    _yt.yt_dlp = yt_dlp


def ytdlp_present():
    return _yt.yt_dlp is not None


def progress():
    p = _yt.INSTALL_PROGRESS
    return "%s|%d|%d" % (p["stage"], p["done"], p["total"])


def pick_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def serve(port, out_dir):
    from pathlib import Path
    _yt.DEFAULT_OUT = Path(out_dir)      # chosen after the storage permission answer
    sys.argv = ["yt_batch", "--no-browser", "--host", "127.0.0.1", "--port", str(port)]
    _yt.main()
