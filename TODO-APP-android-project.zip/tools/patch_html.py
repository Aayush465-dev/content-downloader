#!/usr/bin/env python3
"""Turns the original single-file website into app/src/main/assets/index.html
(desktop-site viewport, floating focus controller, native PDF saving hooks).
Run:  python3 tools/patch_html.py original/Index_-_Cvvopy.html app/src/main/assets/index.html
"""
import json, re, sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()

m = re.search(r'(<script id="jmt-site-source" type="application/json">)(.*?)(</script>)', s, re.S)
assert m, 'embedded test site not found'
site = json.loads(m.group(2))
main = s[:m.start()] + '@@SITE@@' + s[m.end():]


def sub1(text, old, new, label, regex=False):
    if regex:
        out, n = re.subn(old, lambda _m: new, text, count=0, flags=re.S)
    else:
        n = text.count(old)
        out = text.replace(old, new)
    assert n == 1, f'{label}: expected 1 match, found {n}'
    return out


# ---------------------------------------------------------------- main page
# 1. desktop-site viewport (same idea as "Desktop site" in a mobile browser)
VIEWPORT = '<meta name="viewport" content="width=1024, minimum-scale=0.1, maximum-scale=5, user-scalable=yes">'
main, n = re.subn(r'<meta name="viewport"[^>]*>', VIEWPORT, main)
assert n >= 1, 'viewport'

# 2. native bridge script
main = sub1(main, '<head>', '<head>\n    <script src="/native-bridge.js"></script>', 'head')

# 3. Float buttons
main = sub1(
    main,
    '<button id="btn-maximize-focus" style="background:#8b5cf6; padding:8px 16px; border-radius:20px;">Maximize ⛶</button>',
    '<button id="btn-maximize-focus" style="background:#8b5cf6; padding:8px 16px; border-radius:20px;">Maximize ⛶</button>\n'
    '            <button id="btn-float" class="float-btn" onclick="toggleFloat()" style="background:#f59e0b; padding:8px 16px; border-radius:20px;">🪟 Float</button>',
    'float bar button')
main = sub1(
    main,
    '<button id="btn-focus-minimize" style="background:rgba(71, 85, 105, 0.9);">↙ Minimize</button>',
    '<button id="btn-focus-minimize" style="background:rgba(71, 85, 105, 0.9);">↙ Minimize</button>\n'
    '                <button id="btn-float-fs" class="float-btn" onclick="toggleFloat()" style="background:#f59e0b;">🪟 Float</button>',
    'float fs button')

# 4. settings (Manage Tasks modal + focus screen settings popup)
FLOAT_OPTIONS = ('<option value="all_today">Today\'s total – all tasks (default)</option>'
                 '<option value="task_today">Today\'s total – running task</option>'
                 '<option value="task_total">Task total – running task (all days)</option>')
anchor = re.search(r'id="last-backup-text"></div>\s*</div>', main)
assert anchor, 'backup block anchor'
manage_block = (
    '\n\n        <div class="android-only" style="background:var(--surface); padding:15px; border-radius:8px; margin-top:15px; '
    'text-align:left; border:1px solid var(--border-color);">\n'
    '            <h4 style="margin-top:0; color:var(--text-main);">Floating Controller</h4>\n'
    '            <label style="display:block; font-size:13px; color:var(--text-muted); margin-bottom:6px;">Time shown on the floating button:</label>\n'
    '            <select class="float-mode-select" onchange="saveFloatSettings(this.value)" style="width:100%;">' + FLOAT_OPTIONS + '</select>\n'
    '        </div>')
main = main[:anchor.end()] + manage_block + main[anchor.end():]

main = sub1(
    main,
    '<button onclick="editFocusTimeFs()" style="background:transparent; border:1px solid #94a3b8; color:#f8fafc; width:100%; margin-top:15px;">✏️ Edit Focus Time</button>',
    '<button onclick="editFocusTimeFs()" style="background:transparent; border:1px solid #94a3b8; color:#f8fafc; width:100%; margin-top:15px;">✏️ Edit Focus Time</button>\n'
    '                <div class="android-only" style="margin-top:15px;"><label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Floating button shows:</label>'
    '<select class="float-mode-select" onchange="saveFloatSettings(this.value)" style="width:100%; background:#0f172a; color:white; border:1px solid #475569;">'
    + FLOAT_OPTIONS + '</select></div>',
    'fs settings')

# 5. focus tick must be callable from native code + fix a latent bug (undefined variable at midnight)
main = sub1(main, 'let focusInterval = null; let lastFocusTick = null;',
            'let focusInterval = null; let lastFocusTick = null; let focusTickFn = null;', 'focusTickFn decl')
tick_start = re.search(r'focusInterval = setInterval\(\(\) => \{(\s*let now = Date\.now\(\); let delta = now - lastFocusTick;)', main)
assert tick_start, 'tick start'
main = main[:tick_start.start()] + 'focusTickFn = () => {' + tick_start.group(1) + main[tick_start.end():]
tick_end = re.search(r'\}, 1000\);(\s*\}\s*function pauseFocus\(\))', main)
assert tick_end, 'tick end'
main = main[:tick_end.start()] + '}; focusInterval = setInterval(focusTickFn, 1000);' + tick_end.group(1) + main[tick_end.end():]
_i = main.index('focusTickFn = () =>')
_j = main.index('currentFocus.totalElapsed += actualSecsAdded;', _i)
main = main[:_j] + 'currentFocus.totalElapsed += actualAdded;' + main[_j + len('currentFocus.totalElapsed += actualSecsAdded;'):]

# 6. reminders: task form, parsers, AI prompt, export, saveTask / editTask
main = sub1(main, "document.getElementById('form-task').reset(); document.getElementById('task-edit-id').value='';",
            "document.getElementById('form-task').reset(); document.getElementById('task-edit-id').value=''; window.__setRemindField&&window.__setRemindField(undefined);",
            'reset reminder field')
main = sub1(main, "const obj = { description:", "const obj = { remind: (window.__readRemindField ? window.__readRemindField() : undefined), description:", 'obj remind')
main = sub1(main, "priority:obj.priority, tags:obj.tags}); t.date = d;", "priority:obj.priority, tags:obj.tags, remind:obj.remind}); t.date = d;", 'edit assign remind')
main = sub1(main, "tags:obj.tags, completed:false, focusTime:0", "tags:obj.tags, remind:obj.remind, completed:false, focusTime:0", 'repeat remind')
main = sub1(main, "document.getElementById('task-tags').value = t.tags.join(', ');",
            "document.getElementById('task-tags').value = t.tags.join(', '); window.__setRemindField&&window.__setRemindField(t.remind);", 'edit field')
# [remind: 18:30] / [remind: off] tag in the TXT import and in Plan by AI
main = sub1(main, "let prio = 'medium'; let pMatch",
            "let remind; { const rm = rest.match(/\\[\\s*remind\\s*:\\s*([^\\]]*)\\]/i); if(rm){ remind = window.__parseRemind(rm[1]); rest = rest.replace(rm[0], '').trim(); } }\n"
            "                    let prio = 'medium'; let pMatch", 'txt tag')
main = sub1(main, "taskDetails: details, completed: false", "taskDetails: details, remind: remind, completed: false", 'txt obj')
main = sub1(main, 'let priority = "medium";',
            "let remind; { const rm = cleanDesc.match(/\\[\\s*remind\\s*:\\s*([^\\]]*)\\]/i); if(rm){ remind = window.__parseRemind(rm[1]); cleanDesc = cleanDesc.replace(rm[0], ''); } }\n"
            '                let priority = "medium";', 'ps tag')
main = sub1(main, "taskDetails: detailsPart,", "taskDetails: detailsPart,\n                    remind: remind,", 'ps obj')
main = sub1(main, "6. write these copyable like you write code.",
            "6. Reminder (optional): add [remind: HH:MM] in 24-hour time (e.g. [remind: 18:30]) to get a reminder at that time on the task date, or [remind: off] for no reminder. "
            "If you leave it out the app reminds automatically at the user's default time, so only add it when a specific time is really needed.\n\n"
            "            7. write these copyable like you write code.", 'prompt rule')
main = sub1(main, "#physics #class-11 | Details: Focus on derivations and formulas on page 42.",
            "#physics #class-11 [remind: 18:30] | Details: Focus on derivations and formulas on page 42.", 'prompt example')
main = sub1(main, "${t.tags.map(x=>'#'+x).join(' ')} ${t.taskDetails ?",
            "${t.tags.map(x=>'#'+x).join(' ')} ${t.remind ? '[remind: '+t.remind+']' : ''} ${t.taskDetails ?", 'export tag')

# 7. extras (CSS + JS) -- floating controller bridge, reminders, alarms UI
main = sub1(main, '<head>\n    <script src="/native-bridge.js"></script>',
            '<head>\n    <script src="/native-bridge.js"></script>\n    <link rel="stylesheet" href="/app-extras.css">', 'extras css')
assert main.count('</body>') == 1, 'body end'
main = main.replace('</body>', '<script src="/app-extras.js"></script>\n</body>')
main = main.replace('@@SITE@@', '<script id="jmt-site-source" type="application/json">@@SITE@@</script>', 1)

# ---------------------------------------------------------------- embedded test website
site = sub1(site, '<head>', '<head>\n<script src="/native-bridge.js"></script>', 'site head')
site = sub1(
    site,
    "window.addEventListener('afterprint',rs,{once:true});window.print();setTimeout(rs,60000);break}",
    "window.addEventListener('afterprint',rs,{once:true});"
    "if(window.__nativePrintReport){window.__nativePrintReport(nm);setTimeout(rs,2000)}else{window.print();setTimeout(rs,60000)}break}",
    'report print')
gen = re.search(r"bar\.style\.width=Math\.round\(\(i\+1\)/list\.length\*100\)\+'%'\}\s*st\.textContent='';", site)
assert gen, 'generator anchor'
site = (site[:gen.end()]
        + "if(window.__nativeSave){for(const r of res){try{await window.__nativeSave(r.blob,r.nm,'questions')}catch(e){console.error(e)}}}"
        + site[gen.end():])

site_json = json.dumps(site, ensure_ascii=True).replace('<', '\\u003c')
out = main.replace('@@SITE@@', site_json, 1)
assert '@@SITE@@' not in out
open(dst, 'w', encoding='utf-8').write(out)
print('written', dst, len(out), 'bytes')
