package com.todoapp.focus;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

final class AlarmScheduler {
    static final String ACT_ALARM = "com.todoapp.focus.ALARM";
    static final String ACT_SNOOZE = "com.todoapp.focus.ALARM_SNOOZE";

    private AlarmScheduler() {}

    private static PendingIntent fire(Context c, String id) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACT_ALARM).putExtra("id", id);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent show(Context c) {
        return PendingIntent.getActivity(c, 7, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void rescheduleAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        JSONArray list = AlarmStore.all(c);
        long now = System.currentTimeMillis();
        for (int i = 0; i < list.length(); i++) {
            JSONObject a = list.optJSONObject(i);
            if (a == null) continue;
            String id = a.optString("id");
            long t = a.optBoolean("enabled", true) ? AlarmStore.nextTrigger(a, now) : 0;
            if (t > 0) am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, show(c)), fire(c, id));
            else am.cancel(fire(c, id));
        }
    }

    static void cancel(Context c, String id) {
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(fire(c, id));
    }

    static void scheduleSnooze(Context c, JSONObject alarm, String kind, int minutes, int count) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        String key = "snooze" + alarm.optString("id", "x");
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACT_SNOOZE)
                .putExtra("json", alarm.toString()).putExtra("kind", kind).putExtra("count", count);
        PendingIntent pi = PendingIntent.getBroadcast(c, key.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(System.currentTimeMillis() + minutes * 60000L, show(c)), pi);
    }
}
