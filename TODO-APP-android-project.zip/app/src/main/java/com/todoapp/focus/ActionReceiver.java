package com.todoapp.focus;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Buttons inside notifications: pause/resume focus, start/switch task, snooze reminder. */
public class ActionReceiver extends BroadcastReceiver {
    static final String ACT_TOGGLE = "com.todoapp.focus.A_TOGGLE";
    static final String ACT_START = "com.todoapp.focus.A_START";
    static final String ACT_SNOOZE = "com.todoapp.focus.A_SNOOZE";

    static PendingIntent pi(Context c, String action, String key, String name, int reqCode) {
        Intent i = new Intent(c, ActionReceiver.class).setAction(action).putExtra("key", key).putExtra("name", name).putExtra("nid", reqCode);
        return PendingIntent.getBroadcast(c, (action + key).hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        String act = intent.getAction();
        if (act == null) return;
        String key = intent.getStringExtra("key") == null ? "" : intent.getStringExtra("key");
        String name = intent.getStringExtra("name") == null ? "" : intent.getStringExtra("name");
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        switch (act) {
            case ACT_TOGGLE:
                FocusService.toggleFromNotification();
                break;
            case ACT_START:
                nm.cancel(intent.getIntExtra("nid", 0));
                Cmd.startTask(c, key);
                break;
            case ACT_SNOOZE:
                nm.cancel(intent.getIntExtra("nid", 0));
                ReminderCenter.snooze(c, key, name, Math.max(1, ReminderCenter.settings(c).optInt("snooze", 10)));
                FileStore.toast(c, "Reminder snoozed");
                break;
            default:
                break;
        }
    }
}
