package com.todoapp.focus;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/** Full-screen ring screen shown over the lock screen. */
public class AlarmActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView clock;
    private JSONObject alarm = new JSONObject();
    private String kind = "alarm";
    private int count;
    private int answer = -1;
    private Button dismissBtn;

    private final BroadcastReceiver stopped = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { finish(); }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            h.postDelayed(this, 1000);
        }
    };

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        try { alarm = new JSONObject(getIntent().getStringExtra("json")); } catch (Exception ignored) {}
        kind = getIntent().getStringExtra("kind") == null ? "alarm" : getIntent().getStringExtra("kind");
        count = getIntent().getIntExtra("count", 0);
        boolean reminder = "reminder".equals(kind);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(28), dp(70), dp(28), dp(40));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF0B1020, 0xFF2E2A6B, 0xFF6D28D9});
        root.setBackground(bg);

        TextView badge = text(reminder ? "TASK REMINDER" : "ALARM", 13, 0xFFC7D2FE, true);
        badge.setLetterSpacing(0.25f);
        root.addView(badge);

        clock = text("", 84, Color.WHITE, true);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clock.setPadding(0, dp(18), 0, 0);
        root.addView(clock);
        root.addView(text(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()), 16, 0xFFC7D2FE, false));

        String label = alarm.optString("label", "");
        TextView lbl = text(label.isEmpty() ? (reminder ? "Time to focus" : "Wake up") : label, 24, Color.WHITE, true);
        lbl.setPadding(0, dp(34), 0, dp(6));
        lbl.setGravity(Gravity.CENTER);
        root.addView(lbl);

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1f));

        if (alarm.optBoolean("math", false) && !reminder) {
            Random r = new Random();
            int a = 6 + r.nextInt(14), c2 = 3 + r.nextInt(9);
            answer = a * c2;
            TextView q = text("Solve to dismiss:  " + a + " × " + c2 + " = ?", 20, Color.WHITE, true);
            q.setPadding(0, 0, 0, dp(10));
            root.addView(q);
            final EditText et = new EditText(this);
            et.setInputType(InputType.TYPE_CLASS_NUMBER);
            et.setTextColor(Color.WHITE);
            et.setHintTextColor(0x88FFFFFF);
            et.setHint("Answer");
            et.setGravity(Gravity.CENTER);
            et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            root.addView(et, new LinearLayout.LayoutParams(dp(180), LinearLayout.LayoutParams.WRAP_CONTENT));
            dismissBtn = pill("Dismiss", 0xFFEF4444, true);
            dismissBtn.setOnClickListener(v -> {
                try {
                    if (Integer.parseInt(et.getText().toString().trim()) == answer) AlarmService.sendAction(this, AlarmService.ACT_DISMISS);
                    else { et.setText(""); et.setError("Try again"); }
                } catch (Exception e) { et.setError("Enter a number"); }
            });
        } else {
            dismissBtn = pill("Dismiss", 0xFFEF4444, true);
            dismissBtn.setOnClickListener(v -> AlarmService.sendAction(this, AlarmService.ACT_DISMISS));
        }

        if (reminder) {
            Button start = pill("Start focus", 0xFF10B981, true);
            start.setOnClickListener(v -> {
                AlarmService.sendAction(this, AlarmService.ACT_DISMISS);
                String key = alarm.optString("key", "");
                if (!key.isEmpty()) Cmd.startTask(getApplicationContext(), key);
            });
            root.addView(start, btnLp());
        }
        if (snoozeAllowed()) {
            Button sn = pill("Snooze " + alarm.optInt("snoozeMin", 10) + " min", 0x33FFFFFF, false);
            sn.setOnClickListener(v -> AlarmService.sendAction(this, AlarmService.ACT_SNOOZE));
            root.addView(sn, btnLp());
        }
        root.addView(dismissBtn, btnLp());
        setContentView(root);
        registerReceiver(stopped, new IntentFilter(AlarmService.ACT_STOPPED), Context.RECEIVER_NOT_EXPORTED);
        h.post(tick);
    }

    private boolean snoozeAllowed() {
        if (!alarm.optBoolean("snoozeOn", true)) return false;
        int max = alarm.optInt("snoozeMax", 3);
        return max <= 0 || count < max;
    }

    private LinearLayout.LayoutParams btnLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        lp.topMargin = dp(12);
        return lp;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private Button pill(String s, int color, boolean bold) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        if (bold) b.setTypeface(b.getTypeface(), Typeface.BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(30));
        b.setBackground(g);
        return b;
    }

    @Override
    public void onBackPressed() { /* must be dismissed or snoozed */ }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try { unregisterReceiver(stopped); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
