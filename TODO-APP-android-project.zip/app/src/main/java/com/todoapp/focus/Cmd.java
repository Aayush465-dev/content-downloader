package com.todoapp.focus;

import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

/** Sends commands (start focus on a task, toggle) to the web page, launching the app when needed. */
final class Cmd {
    private Cmd() {}

    static void startTask(Context c, String key) {
        if (MainActivity.instance != null) {
            MainActivity.evalJs("window.__nativeStartTask&&window.__nativeStartTask(" + JSONObject.quote(key) + ")");
        } else {
            c.getSharedPreferences("cmd", Context.MODE_PRIVATE).edit().putString("pending", key).apply();
        }
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try { c.startActivity(i); } catch (Exception ignored) {}
    }

    static String takePending(Context c) {
        android.content.SharedPreferences sp = c.getSharedPreferences("cmd", Context.MODE_PRIVATE);
        String k = sp.getString("pending", "");
        if (!k.isEmpty()) sp.edit().remove("pending").apply();
        return k;
    }
}
