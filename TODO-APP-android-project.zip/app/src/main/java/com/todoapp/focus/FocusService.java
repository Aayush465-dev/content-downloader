package com.todoapp.focus;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * Runs for as long as a task is being focused:
 *  - persistent notification (task name, today's total, task total, Pause/Resume button)
 *  - keeps the web timer ticking in the background
 *  - optional floating controller drawn over other apps (bar, bubble, panel with search / switch task / mini analysis)
 */
public class FocusService extends Service {
    private static final String CHANNEL = "focus_running";
    private static final int NOTIF_ID = 4711;
    private static final long BAR_IDLE_MS = 3000, PANEL_IDLE_MS = 15000;
    private static final int S_DOT = 0, S_BAR = 1, S_PANEL = 2, S_CONFIRM = 3;

    private static FocusService inst;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences prefs;
    private PowerManager.WakeLock wakeLock;
    private float density;

    // ---- state mirrored from the web page
    private String taskName = "No task", key = "";
    private boolean active, hasTask, maximized;
    private long baseSec, baseToday, baseTask, baseTs = System.currentTimeMillis();
    private long yesterdaySec, topSec;
    private String topDate = "";
    private JSONArray panelTasks = new JSONArray();

    // ---- overlay
    private boolean overlayOn = false, notifyJsOnClose = true;
    private int state = S_BAR;
    private boolean edgeLeft = false;
    private OverlayRoot root;
    private LinearLayout col, bar, panelBox, confirm;
    private GlyphView dot, btnToggle, btnMore, btnMove, btnClose;
    private TextView timeText, tvToday, tvYest, tvTop, tvDiff, tvDiffSub;
    private EditText search;
    private LinearLayout listBox;
    private GradientDrawable barBg, dotBg;
    private WindowManager.LayoutParams lp;
    private ValueAnimator anim;
    private boolean focusable = false;

    // ------------------------------------------------------------------ static API
    static boolean isFocusing() { return inst != null && inst.hasTask && inst.active; }
    static String focusKey() { return inst == null ? "" : inst.key; }
    static boolean isMaximized() { return inst != null && inst.maximized; }
    static boolean isRunning() { return inst != null; }

    static void pushState(final String json) {
        final FocusService s = inst;
        if (s != null) s.h.post(new Runnable() { @Override public void run() { s.applyState(json); } });
    }

    static void setPanelData(final String json) {
        final FocusService s = inst;
        if (s != null) s.h.post(new Runnable() { @Override public void run() { s.applyPanel(json); } });
    }

    static void toggleFromNotification() {
        final FocusService s = inst;
        if (s != null) s.h.post(new Runnable() { @Override public void run() { s.onToggle(); } });
    }

    /** show / hide the floating controller (starts the service when needed) */
    static void setOverlay(Context c, boolean on, String stateJson) {
        final FocusService s = inst;
        if (s != null) {
            if (stateJson != null) s.applyState(stateJson);
            if (on) s.showOverlay(); else s.hideOverlay(false);
        } else if (on) {
            ensureRunning(c, stateJson, true);
        }
    }

    static void ensureRunning(Context c, String stateJson, boolean overlay) {
        if (inst != null) return;
        try {
            Intent i = new Intent(c, FocusService.class).putExtra("state", stateJson).putExtra("overlay", overlay);
            c.startForegroundService(i);
        } catch (Exception ignored) {}
    }

    static void requestStop(Context c) {
        final FocusService s = inst;
        if (s != null) {
            s.notifyJsOnClose = false;
            s.h.post(new Runnable() { @Override public void run() { s.stopSelf(); } });
        }
    }

    // ------------------------------------------------------------------ lifecycle
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        density = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences("float", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        edgeLeft = prefs.getBoolean("left", false);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Focus timer (running)", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIF_ID, n);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "todoapp:focus");
        wakeLock.acquire(8 * 60 * 60 * 1000L);
        h.postDelayed(tick, 1000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getStringExtra("state") != null) applyState(intent.getStringExtra("state"));
        if (intent != null && intent.getBooleanExtra("overlay", false)) showOverlay();
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        notifyJsOnClose = false;
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        removeOverlayView();
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        if (notifyJsOnClose && overlayOn) MainActivity.evalJs("window.__nativeFloatClosed&&window.__nativeFloatClosed()");
        if (inst == this) inst = null;
        super.onDestroy();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (MainActivity.instance == null) { stopSelf(); return; }       // app was closed
            if (active) MainActivity.evalJs("window.__nativeTick&&window.__nativeTick()");   // keeps the page timer exact
            refreshTime();
            updateNotification();
            h.postDelayed(this, 1000);
        }
    };

    // ------------------------------------------------------------------ state
    private void applyState(String json) {
        try {
            JSONObject o = new JSONObject(json);
            hasTask = o.optBoolean("hasTask", false);
            if (!hasTask) { stopSelf(); return; }                              // focus stopped -> notification goes away
            taskName = o.optString("name", "Task");
            key = o.optString("key", "");
            active = o.optBoolean("active", false);
            maximized = o.optBoolean("maximized", false);
            baseSec = o.optLong("sec", 0);
            baseToday = o.optLong("todaySec", 0);
            baseTask = o.optLong("taskSec", 0);
            baseTs = o.optLong("ts", System.currentTimeMillis());
            if (active && wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(8 * 60 * 60 * 1000L);
        } catch (Exception ignored) { return; }
        refreshAll();
        updateNotification();
    }

    private void applyPanel(String json) {
        try {
            JSONObject o = new JSONObject(json);
            yesterdaySec = o.optLong("yesterday", 0);
            topSec = o.optLong("top", 0);
            topDate = o.optString("topDate", "");
            panelTasks = o.optJSONArray("tasks") == null ? new JSONArray() : o.optJSONArray("tasks");
        } catch (Exception ignored) { return; }
        renderList();
        refreshStats();
    }

    private long elapsed() { return active ? Math.max(0, (System.currentTimeMillis() - baseTs) / 1000) : 0; }
    private long curSec() { return baseSec + elapsed(); }
    private long todaySec() { return baseToday + elapsed(); }
    private long taskSec() { return baseTask + elapsed(); }

    private static String fmt(long s) {
        s = Math.max(0, s);
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
    }

    private static String fmtSigned(long s) {
        return (s >= 0 ? "+" : "-") + fmt(Math.abs(s));
    }

    private void onToggle() {
        if (!hasTask) return;
        baseSec = curSec(); baseToday = todaySec(); baseTask = taskSec();
        baseTs = System.currentTimeMillis();
        active = !active;
        refreshAll();
        updateNotification();
        MainActivity.evalJs("window.__nativeFloatCmd&&window.__nativeFloatCmd('toggle')");
    }

    // ------------------------------------------------------------------ notification
    private Notification buildNotification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String today = fmt(todaySec()), task = fmt(taskSec());
        Notification.Action toggle = new Notification.Action.Builder(
                Icon.createWithResource(this, active ? R.drawable.ic_pause : R.drawable.ic_play),
                active ? "Pause" : "Resume",
                ActionReceiver.pi(this, ActionReceiver.ACT_TOGGLE, key, taskName, 0)).build();
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(active ? 0xFF16A34A : 0xFFD97706)
                .setContentTitle((active ? "Focusing  •  " : "Paused  •  ") + taskName)
                .setContentText("Today " + today + "   |   Task total " + task)
                .setStyle(new Notification.BigTextStyle().bigText("Today (all tasks): " + today + "\nThis task (overall): " + task))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(open)
                .addAction(toggle)
                .build();
    }

    private void updateNotification() {
        try {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF_ID, buildNotification());
        } catch (Exception ignored) {}
    }

    // ================================================================== overlay
    private int dp(float v) { return Math.round(v * density); }
    private int screenW() { return getResources().getDisplayMetrics().widthPixels; }
    private int screenH() { return getResources().getDisplayMetrics().heightPixels; }
    private int panelW() { return Math.min(dp(310), screenW() - dp(16)); }

    private final class OverlayRoot extends FrameLayout {
        OverlayRoot(Context c) { super(c); }
        @Override public boolean dispatchTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && state != S_DOT) scheduleIdle();
            return super.dispatchTouchEvent(e);
        }
    }

    void showOverlay() {
        if (root != null) { setState(S_BAR, true); return; }
        if (!Settings.canDrawOverlays(this)) return;
        overlayOn = true;
        buildOverlay();
        try {
            wm.addView(root, lp);
        } catch (Exception e) {
            overlayOn = false;
            root = null;
            return;
        }
        setState(S_BAR, false);
    }

    void hideOverlay(boolean userClosed) {
        removeOverlayView();
        overlayOn = false;
        if (userClosed) MainActivity.evalJs("window.__nativeFloatClosed&&window.__nativeFloatClosed()");
    }

    private void removeOverlayView() {
        h.removeCallbacks(idle);
        if (anim != null) anim.cancel();
        try { if (root != null) { hideKeyboard(); wm.removeView(root); } } catch (Exception ignored) {}
        root = null;
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView label(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildOverlay() {
        root = new OverlayRoot(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        // ---- bar: time + toggle + more + move + close
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(4), dp(8), dp(4));
        barBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFF16A34A, 0xFF0D9488});
        barBg.setCornerRadius(dp(28));
        barBg.setStroke(dp(1), 0x55FFFFFF);
        bar.setBackground(barBg);

        timeText = label("00:00:00", 18, Color.WHITE, true);
        timeText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        bar.addView(timeText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btnToggle = new GlyphView(this, GlyphView.PAUSE);
        btnMore = new GlyphView(this, GlyphView.MORE);
        btnMove = new GlyphView(this, GlyphView.MOVE);
        btnClose = new GlyphView(this, GlyphView.CLOSE);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(40), dp(40));
        blp.leftMargin = dp(2);
        bar.addView(btnToggle, blp);
        bar.addView(btnMore, blp);
        bar.addView(btnMove, blp);
        bar.addView(btnClose, blp);
        btnToggle.setOnClickListener(v -> { onToggle(); scheduleIdle(); });
        btnMore.setOnClickListener(v -> setState(state == S_PANEL ? S_BAR : S_PANEL, true));
        btnClose.setOnClickListener(v -> setState(S_CONFIRM, true));
        btnMove.setOnTouchListener(new DragListener(true));
        col.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- panel: search + task list + mini analysis
        panelBox = new LinearLayout(this);
        panelBox.setOrientation(LinearLayout.VERTICAL);
        panelBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        panelBox.setBackground(rounded(0xFF111827, 20));
        search = new EditText(this);
        search.setHint("Search tasks to switch…");
        search.setHintTextColor(0xFF6B7280);
        search.setTextColor(Color.WHITE);
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setPadding(dp(14), dp(8), dp(14), dp(8));
        search.setBackground(rounded(0xFF1F2937, 14));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { renderList(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        search.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) setFocusable(true);
            return false;
        });
        panelBox.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(this);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listBox);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150));
        slp.topMargin = dp(8);
        panelBox.addView(sv, slp);

        TextView head = label("MINI ANALYSIS", 10, 0xFF9CA3AF, true);
        head.setLetterSpacing(0.15f);
        head.setPadding(dp(2), dp(10), 0, dp(4));
        panelBox.addView(head);
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        tvToday = new TextView(this); tvYest = new TextView(this); tvTop = new TextView(this); tvDiff = new TextView(this);
        tvDiffSub = label("", 10, 0xFF9CA3AF, false);
        r1.addView(statCard("Today", tvToday, null), cardLp(true));
        r1.addView(statCard("Yesterday", tvYest, null), cardLp(false));
        r2.addView(statCard("Top day", tvTop, null), cardLp(true));
        r2.addView(statCard("Difference", tvDiff, tvDiffSub), cardLp(false));
        panelBox.addView(r1);
        panelBox.addView(r2);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.topMargin = dp(6);
        col.addView(panelBox, plp);

        // ---- close confirmation
        confirm = new LinearLayout(this);
        confirm.setOrientation(LinearLayout.VERTICAL);
        confirm.setPadding(dp(16), dp(14), dp(16), dp(12));
        confirm.setBackground(rounded(0xFF1F2937, 20));
        confirm.addView(label("Close floating timer?", 15, Color.WHITE, true));
        TextView sub = label("Pause the focus, or keep it going?", 13, 0xFFB6C0D0, false);
        sub.setPadding(0, dp(2), 0, dp(10));
        confirm.addView(sub);
        LinearLayout row = new LinearLayout(this);
        TextView bPause = pill("Pause focus", 0xFFEF4444), bKeep = pill("Keep going", 0xFF10B981);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pl.rightMargin = dp(8);
        row.addView(bPause, pl);
        row.addView(bKeep, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        confirm.addView(row);
        TextView cancel = label("Cancel", 13, 0xFFB6C0D0, false);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, dp(10), 0, dp(2));
        confirm.addView(cancel);
        bPause.setOnClickListener(v -> {
            MainActivity.evalJs("window.__nativeFloatCmd&&window.__nativeFloatCmd('pause')");
            active = false;
            hideOverlay(true);
        });
        bKeep.setOnClickListener(v -> hideOverlay(true));
        cancel.setOnClickListener(v -> setState(S_BAR, true));
        col.addView(confirm);

        // ---- collapsed bubble
        dot = new GlyphView(this, GlyphView.DOT);
        dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setStroke(dp(1), 0x66FFFFFF);
        dot.setBackground(dotBg);
        dot.setOnTouchListener(new DragListener(false));

        root.addView(col);
        root.addView(dot, new FrameLayout.LayoutParams(dp(46), dp(46)));

        lp = new WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING;
        lp.x = edgeLeft ? dp(8) : screenW() - dp(200);
        lp.y = prefs.getInt("y", dp(180));
        refreshAll();
    }

    private LinearLayout statCard(String title, TextView value, TextView sub) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(10), dp(7), dp(10), dp(7));
        c.setBackground(rounded(0xFF1F2937, 12));
        c.addView(label(title, 10, 0xFF9CA3AF, false));
        value.setTextColor(Color.WHITE);
        value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        value.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        c.addView(value);
        if (sub != null) c.addView(sub);
        return c;
    }

    private LinearLayout.LayoutParams cardLp(boolean left) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        l.topMargin = dp(6);
        if (left) l.rightMargin = dp(6);
        return l;
    }

    private TextView pill(String text, int color) {
        TextView t = label(text, 13, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(9), dp(6), dp(9));
        t.setBackground(rounded(color, 20));
        return t;
    }

    // ------------------------------------------------------------------ rendering
    private void refreshAll() {
        if (root == null) return;
        boolean a = active;
        barBg.setColors(a ? new int[]{0xFF16A34A, 0xFF0D9488} : new int[]{0xFFD97706, 0xFFEA580C});
        dotBg.setColor(a ? 0xFF16A34A : 0xFFD97706);
        btnToggle.setType(a ? GlyphView.PAUSE : GlyphView.PLAY);
        btnToggle.setAlpha(hasTask ? 1f : 0.4f);
        btnMore.setType(state == S_PANEL ? GlyphView.CHEVRON : GlyphView.MORE);
        refreshTime();
        refreshStats();
    }

    private void refreshTime() {
        if (timeText != null) timeText.setText(fmt(curSec()));
        if (state == S_PANEL) refreshStats();
    }

    private void refreshStats() {
        if (tvToday == null) return;
        long t = todaySec();
        tvToday.setText(fmt(t));
        tvYest.setText(fmt(yesterdaySec));
        tvTop.setText(fmt(topSec));
        long d = t - yesterdaySec;
        tvDiff.setText((d >= 0 ? "▲ " : "▼ ") + fmtSigned(d));
        tvDiff.setTextColor(d > 0 ? 0xFF34D399 : d < 0 ? 0xFFF87171 : Color.WHITE);
        long dt = t - topSec;
        tvDiffSub.setText("vs top " + fmtSigned(dt) + (topDate.isEmpty() ? "" : "  (" + topDate + ")"));
    }

    private void renderList() {
        if (listBox == null) return;
        listBox.removeAllViews();
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        for (int i = 0; i < panelTasks.length() && shown < 40; i++) {
            final JSONObject o = panelTasks.optJSONObject(i);
            if (o == null) continue;
            String name = o.optString("n");
            if (!q.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(q)) continue;
            final String k = o.optString("k");
            boolean current = k.equals(key);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            row.setBackground(rounded(current ? 0xFF312E81 : 0x00000000, 10));
            TextView tn = label((current ? "● " : "") + name, 13, current ? 0xFFC7D2FE : Color.WHITE, current);
            tn.setSingleLine(true);
            tn.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(tn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(label(fmt(o.optLong("t", 0)).substring(0, 5), 11, 0xFF9CA3AF, false));
            row.setOnClickListener(v -> switchTo(k, o.optString("n")));
            listBox.addView(row);
            shown++;
        }
        if (shown == 0) {
            TextView none = label(panelTasks.length() == 0 ? "Loading tasks…" : "No matching task", 13, 0xFF9CA3AF, false);
            none.setPadding(dp(10), dp(10), dp(10), dp(10));
            listBox.addView(none);
        }
    }

    private void switchTo(String k, String name) {
        if (k.equals(key)) return;
        taskName = name;
        key = k;
        MainActivity.evalJs("window.__nativeSwitch&&window.__nativeSwitch(" + JSONObject.quote(k) + ")");
        hideKeyboard();
        setState(S_BAR, true);
    }

    // ------------------------------------------------------------------ states, positioning, animation
    private final Runnable idle = new Runnable() {
        @Override public void run() {
            if (root == null) return;
            if (state == S_BAR) setState(S_DOT, true);
            else if (state == S_PANEL) setState(S_BAR, true);
        }
    };

    private void scheduleIdle() {
        h.removeCallbacks(idle);
        if (state == S_BAR) h.postDelayed(idle, BAR_IDLE_MS);
        else if (state == S_PANEL) h.postDelayed(idle, PANEL_IDLE_MS);
    }

    private void setState(int s, boolean animate) {
        if (root == null) return;
        int prev = state;
        state = s;
        if (prev == S_PANEL && s != S_PANEL) { setFocusable(false); hideKeyboard(); }
        bar.setVisibility(s == S_BAR || s == S_PANEL ? View.VISIBLE : View.GONE);
        panelBox.setVisibility(s == S_PANEL ? View.VISIBLE : View.GONE);
        confirm.setVisibility(s == S_CONFIRM ? View.VISIBLE : View.GONE);
        col.setVisibility(s == S_DOT ? View.GONE : View.VISIBLE);
        dot.setVisibility(s == S_DOT ? View.VISIBLE : View.GONE);
        root.setAlpha(s == S_DOT ? 0.38f : 1f);
        lp.width = (s == S_PANEL || s == S_CONFIRM) ? panelW() : ViewGroup.LayoutParams.WRAP_CONTENT;
        if (s == S_PANEL) {
            search.setText("");
            renderList();
            MainActivity.evalJs("window.__nativePanelData&&window.__nativePanelData()");
        }
        refreshAll();
        applyPosition(animate);
        scheduleIdle();
    }

    /** puts the window fully on screen, on the chosen side, never half cut */
    private void applyPosition(boolean animate) {
        if (root == null) return;
        int sw = screenW(), sh = screenH(), margin = dp(8), top = dp(40);
        int wSpec = lp.width > 0 ? View.MeasureSpec.makeMeasureSpec(lp.width, View.MeasureSpec.EXACTLY)
                : View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST);
        root.measure(wSpec, View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST));
        int w = lp.width > 0 ? lp.width : root.getMeasuredWidth();
        int hgt = root.getMeasuredHeight();
        int tx = edgeLeft ? margin : sw - w - margin;
        int ty = state == S_PANEL ? top : Math.max(top, Math.min(prefs.getInt("y", dp(180)), sh - hgt - dp(56)));
        if (state == S_PANEL) ty = Math.max(top, Math.min(ty, sh - hgt - dp(24)));
        moveWindow(tx, ty, animate);
    }

    private void moveWindow(final int tx, final int ty, boolean animate) {
        if (anim != null) anim.cancel();
        if (!animate) {
            lp.x = tx; lp.y = ty;
            update();
            return;
        }
        final int sx = lp.x, sy = lp.y;
        try { wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(190);
        anim.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            lp.x = Math.round(sx + (tx - sx) * f);
            lp.y = Math.round(sy + (ty - sy) * f);
            update();
        });
        anim.start();
    }

    private void update() {
        try { if (root != null) wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
    }

    /** after dragging: stick to the nearest side, and to a corner when close to the top / bottom */
    private void snapAfterDrag() {
        int sw = screenW(), sh = screenH(), margin = dp(8), top = dp(40);
        root.measure(View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST));
        int w = root.getMeasuredWidth(), hgt = root.getMeasuredHeight();
        edgeLeft = lp.x + w / 2 < sw / 2;
        int y = Math.max(top, Math.min(lp.y, sh - hgt - dp(56)));
        if (y < sh * 0.2f) y = top;                           // top corner
        else if (y > sh * 0.8f - hgt) y = sh - hgt - dp(56);   // bottom corner
        prefs.edit().putBoolean("left", edgeLeft).putInt("y", y).apply();
        moveWindow(edgeLeft ? margin : sw - w - margin, y, true);
    }

    private void setFocusable(boolean on) {
        if (root == null || focusable == on) return;
        focusable = on;
        if (on) lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        else lp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        update();
        if (on) h.postDelayed(() -> {
            if (search == null) return;
            search.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);
        }, 120);
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null && search != null) imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
            setFocusable(false);
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------------ dragging
    private final class DragListener implements View.OnTouchListener {
        private final boolean alwaysDrag;       // move handle always drags; the bubble: tap = open, drag = move
        private float downX, downY;
        private int startX, startY;
        private boolean dragging;
        private final int slop = ViewConfiguration.get(FocusService.this).getScaledTouchSlop();

        DragListener(boolean alwaysDrag) { this.alwaysDrag = alwaysDrag; }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (anim != null) anim.cancel();
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = lp.x; startY = lp.y;
                    dragging = alwaysDrag;
                    v.setPressed(true);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) dragging = true;
                    if (dragging) {
                        lp.x = startX + Math.round(dx);
                        lp.y = startY + Math.round(dy);
                        update();
                        if (state != S_DOT) scheduleIdle();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    if (dragging) snapAfterDrag();
                    else if (!alwaysDrag && e.getActionMasked() == MotionEvent.ACTION_UP) setState(S_BAR, true);   // tap on bubble
                    return true;
                default:
                    return true;
            }
        }
    }
}
