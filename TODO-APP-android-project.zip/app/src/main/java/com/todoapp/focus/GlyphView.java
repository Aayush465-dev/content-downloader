package com.todoapp.focus;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Tiny icon button drawn with a Canvas (no image files needed). */
final class GlyphView extends View {
    static final int PLAY = 0, PAUSE = 1, MOVE = 2, CLOSE = 3, MORE = 4, CHEVRON = 5, DOT = 6;

    private int type;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pressedBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    GlyphView(Context c, int type) {
        super(c);
        this.type = type;
        float d = c.getResources().getDisplayMetrics().density;
        fill.setColor(0xFFFFFFFF);
        fill.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFFFFFFFF);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2.4f * d);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        pressedBg.setColor(0x33FFFFFF);
        setClickable(true);
    }

    void setType(int t) {
        if (t != type) { type = t; invalidate(); }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, s = Math.min(w, h) * 0.2f;
        if (isPressed()) c.drawCircle(cx, cy, Math.min(w, h) / 2f, pressedBg);
        switch (type) {
            case PLAY:
                path.reset();
                path.moveTo(cx - s * 0.8f, cy - s * 1.2f);
                path.lineTo(cx - s * 0.8f, cy + s * 1.2f);
                path.lineTo(cx + s * 1.3f, cy);
                path.close();
                c.drawPath(path, fill);
                break;
            case PAUSE:
                c.drawRoundRect(cx - s * 1.05f, cy - s * 1.2f, cx - s * 0.2f, cy + s * 1.2f, 3f, 3f, fill);
                c.drawRoundRect(cx + s * 0.2f, cy - s * 1.2f, cx + s * 1.05f, cy + s * 1.2f, 3f, 3f, fill);
                break;
            case MOVE: {
                float a = s * 1.5f, k = s * 0.55f;
                c.drawLine(cx - a, cy, cx + a, cy, stroke);
                c.drawLine(cx, cy - a, cx, cy + a, stroke);
                // arrow heads
                c.drawLine(cx - a, cy, cx - a + k, cy - k, stroke);
                c.drawLine(cx - a, cy, cx - a + k, cy + k, stroke);
                c.drawLine(cx + a, cy, cx + a - k, cy - k, stroke);
                c.drawLine(cx + a, cy, cx + a - k, cy + k, stroke);
                c.drawLine(cx, cy - a, cx - k, cy - a + k, stroke);
                c.drawLine(cx, cy - a, cx + k, cy - a + k, stroke);
                c.drawLine(cx, cy + a, cx - k, cy + a - k, stroke);
                c.drawLine(cx, cy + a, cx + k, cy + a - k, stroke);
                break;
            }
            case CLOSE: {
                float a = s * 1.1f;
                c.drawLine(cx - a, cy - a, cx + a, cy + a, stroke);
                c.drawLine(cx - a, cy + a, cx + a, cy - a, stroke);
                break;
            }
            case MORE: {                       // list icon
                float a = s * 1.25f;
                for (int k = -1; k <= 1; k++) {
                    c.drawCircle(cx - a, cy + k * s * 0.9f, s * 0.2f, fill);
                    c.drawLine(cx - a + s * 0.6f, cy + k * s * 0.9f, cx + a, cy + k * s * 0.9f, stroke);
                }
                break;
            }
            case CHEVRON: {                    // chevron up (collapse panel)
                float a = s * 1.1f;
                c.drawLine(cx - a, cy + a * 0.45f, cx, cy - a * 0.55f, stroke);
                c.drawLine(cx, cy - a * 0.55f, cx + a, cy + a * 0.45f, stroke);
                break;
            }
            case DOT:                          // collapsed bubble: ring + core
                c.drawCircle(cx, cy, Math.min(w, h) * 0.26f, stroke);
                c.drawCircle(cx, cy, Math.min(w, h) * 0.1f, fill);
                break;
            default:
                break;
        }
    }
}
