package com.todoapp.focus;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/** Alarms are stored natively (JSON) so they keep working when the web page is not running. */
final class AlarmStore {
    private AlarmStore() {}

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("alarms", Context.MODE_PRIVATE); }

    static JSONArray all(Context c) {
        try { return new JSONArray(sp(c).getString("list", "[]")); } catch (JSONException e) { return new JSONArray(); }
    }

    static void saveAll(Context c, JSONArray a) { sp(c).edit().putString("list", a.toString()).apply(); }

    static JSONObject find(Context c, String id) {
        JSONArray a = all(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) return o;
        }
        return null;
    }

    /** insert or replace, then re-schedule everything. Returns the new list. */
    static String save(Context c, JSONObject alarm) {
        try {
            if (alarm.optString("id").isEmpty()) alarm.put("id", UUID.randomUUID().toString().substring(0, 8));
            JSONArray a = all(c), out = new JSONArray();
            boolean replaced = false;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                if (o.optString("id").equals(alarm.optString("id"))) { out.put(alarm); replaced = true; } else out.put(o);
            }
            if (!replaced) out.put(alarm);
            saveAll(c, out);
        } catch (JSONException ignored) {}
        AlarmScheduler.rescheduleAll(c);
        return all(c).toString();
    }

    static String delete(Context c, String id) {
        JSONArray a = all(c), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !o.optString("id").equals(id)) out.put(o);
        }
        saveAll(c, out);
        AlarmScheduler.cancel(c, id);
        return out.toString();
    }

    static String update(Context c, String id, String key, Object value) {
        JSONObject o = find(c, id);
        if (o != null) {
            try { o.put(key, value); } catch (JSONException ignored) {}
            return save(c, o);
        }
        return all(c).toString();
    }

    static String dateStr(Calendar cal) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(cal.getTimeInMillis()));
    }

    /** Next time (ms) this alarm should ring after "from", or 0 if never. Honors days, one-off date and "skip next". */
    static long nextTrigger(JSONObject a, long from) {
        int h = a.optInt("hour"), m = a.optInt("minute");
        String date = a.optString("date", ""), skip = a.optString("skipDate", "");
        JSONArray days = a.optJSONArray("days");
        boolean any = days == null || days.length() == 0;
        for (int i = 0; i < 400; i++) {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(from);
            cal.add(Calendar.DAY_OF_YEAR, i);
            cal.set(Calendar.HOUR_OF_DAY, h);
            cal.set(Calendar.MINUTE, m);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() <= from) continue;
            String ds = dateStr(cal);
            if (!date.isEmpty()) {                       // one specific date
                if (ds.equals(date)) return skip.equals(ds) ? 0 : cal.getTimeInMillis();
                if (ds.compareTo(date) > 0) return 0;
                continue;
            }
            boolean ok = any;
            if (!any) {
                int dow = cal.get(Calendar.DAY_OF_WEEK);     // 1 = Sunday ... 7 = Saturday
                for (int k = 0; k < days.length(); k++) if (days.optInt(k) == dow) ok = true;
            }
            if (!ok) continue;
            if (ds.equals(skip)) continue;                  // "skip next" for this occurrence
            return cal.getTimeInMillis();
        }
        return 0;
    }
}
