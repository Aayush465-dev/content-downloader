package com.todoapp.focus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import org.json.JSONObject;

import java.io.File;

/** Rings an alarm (or an "alarm style" task reminder): looping sound, vibration, gradual volume, auto-stop, snooze. */
public class AlarmService extends Service {
    static final String ACT_RING = "com.todoapp.focus.RING";
    static final String ACT_DISMISS = "com.todoapp.focus.DISMISS";
    static final String ACT_SNOOZE = "com.todoapp.focus.SNOOZE_NOW";
    static final String ACT_STOPPED = "com.todoapp.focus.RING_STOPPED";
    private static final String CH_RING = "alarm_ring";
    private static final String CH_MISSED = "alarm_missed";
    private static final int ID_RING = 5101, ID_MISSED = 5102;

    private final Handler h = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private Vibrator vib;
    private JSONObject alarm = new JSONObject();
    private String kind = "alarm";
    private int count = 0;
    private float vol = 1f, targetVol = 1f;
    private boolean ringing = false;

    static void ring(Context c, JSONObject alarm, String kind, int count) {
        Intent i = new Intent(c, AlarmService.class).setAction(ACT_RING)
                .putExtra("json", alarm.toString()).putExtra("kind", kind).putExtra("count", count);
        try { c.startForegroundService(i); } catch (Exception ignored) {}
    }

    static void sendAction(Context c, String action) {
        c.startService(new Intent(c, AlarmService.class).setAction(action));
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        if (ACT_RING.equals(act)) {
            try { alarm = new JSONObject(intent.getStringExtra("json")); } catch (Exception e) { alarm = new JSONObject(); }
            kind = intent.getStringExtra("kind") == null ? "alarm" : intent.getStringExtra("kind");
            count = intent.getIntExtra("count", 0);
            startRinging();
        } else if (ACT_DISMISS.equals(act)) {
            finishRinging(false);
        } else if (ACT_SNOOZE.equals(act)) {
            snooze();
        } else if (!ringing) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------------ ringing
    private void startRinging() {
        stopSound();
        ringing = true;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH_RING, "Alarms", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);

        Intent full = new Intent(this, AlarmActivity.class)
                .putExtra("json", alarm.toString()).putExtra("kind", kind).putExtra("count", count)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullPi = PendingIntent.getActivity(this, 11, full, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent dismiss = PendingIntent.getService(this, 12, new Intent(this, AlarmService.class).setAction(ACT_DISMISS),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent snz = PendingIntent.getService(this, 13, new Intent(this, AlarmService.class).setAction(ACT_SNOOZE),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        String label = alarm.optString("label", "");
        boolean reminder = "reminder".equals(kind);
        Notification.Builder b = new Notification.Builder(this, CH_RING)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(reminder ? "Task reminder" : (label.isEmpty() ? "Alarm" : label))
                .setContentText(reminder ? label : String.format("%02d:%02d", alarm.optInt("hour"), alarm.optInt("minute")))
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(fullPi)
                .addAction(new Notification.Action.Builder(null, "Dismiss", dismiss).build());
        if (canSnooze()) b.addAction(new Notification.Action.Builder(null, "Snooze", snz).build());
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID_RING, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(ID_RING, n);
        try { startActivity(full); } catch (Exception ignored) {}   // works when the screen is on / overlay allowed

        startSound();
        startVibration();
        int auto = alarm.optInt("autoStop", 5);
        if (auto > 0) {
            h.removeCallbacks(autoStop);
            h.postDelayed(autoStop, auto * 60000L);
        }
    }

    private final Runnable autoStop = new Runnable() {
        @Override public void run() { finishRinging(true); }
    };

    private boolean canSnooze() {
        if (!alarm.optBoolean("snoozeOn", true)) return false;
        int max = alarm.optInt("snoozeMax", 3);
        return max <= 0 || count < max;
    }

    private Uri soundUri() {
        JSONObject s = alarm.optJSONObject("sound");
        String type = s == null ? "default" : s.optString("type", "default");
        String uri = s == null ? "" : s.optString("uri", "");
        if (!uri.isEmpty() && !"default".equals(type)) return Uri.parse(uri);
        Uri d = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        return d != null ? d : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
    }

    private void startSound() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
        if (am.getStreamVolume(AudioManager.STREAM_ALARM) == 0) am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(1, (int) (max * 0.6f)), 0);

        targetVol = Math.max(0.05f, Math.min(1f, alarm.optInt("volume", 80) / 100f));
        boolean gradual = alarm.optBoolean("gradual", true);
        vol = gradual ? 0.05f : targetVol;
        Uri uri = soundUri();
        Uri[] tries = {uri, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)};
        for (Uri u : tries) {
            try {
                MediaPlayer mp = new MediaPlayer();
                mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                if ("file".equals(u.getScheme()) && u.getPath() != null && new File(u.getPath()).exists()) mp.setDataSource(u.getPath());
                else mp.setDataSource(this, u);
                mp.setLooping(true);
                mp.setVolume(vol, vol);
                mp.prepare();
                mp.start();
                player = mp;
                break;
            } catch (Exception e) {
                // try the next fallback
            }
        }
        if (gradual) h.postDelayed(ramp, 500);
    }

    private final Runnable ramp = new Runnable() {
        @Override public void run() {
            if (player == null) return;
            vol = Math.min(targetVol, vol + targetVol / 50f);      // ~25 seconds to full volume
            try { player.setVolume(vol, vol); } catch (Exception ignored) {}
            if (vol < targetVol) h.postDelayed(this, 500);
        }
    };

    private void startVibration() {
        if (!alarm.optBoolean("vibrate", true)) return;
        long[] pattern = {0, 700, 450, 700, 900};
        if (Build.VERSION.SDK_INT >= 31) {
            VibratorManager vm = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
            vib = vm.getDefaultVibrator();
        } else {
            vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        }
        if (vib != null) vib.vibrate(VibrationEffect.createWaveform(pattern, 0),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
    }

    private void stopSound() {
        h.removeCallbacks(ramp);
        h.removeCallbacks(autoStop);
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        if (vib != null) { try { vib.cancel(); } catch (Exception ignored) {} vib = null; }
    }

    private void snooze() {
        if (canSnooze()) {
            int min = Math.max(1, alarm.optInt("snoozeMin", 10));
            AlarmScheduler.scheduleSnooze(this, alarm, kind, min, count + 1);
            FileStore.toast(this, "Snoozed for " + min + " min");
        }
        finishRinging(false);
    }

    private void finishRinging(boolean missed) {
        ringing = false;
        stopSound();
        stopForeground(true);
        sendBroadcast(new Intent(ACT_STOPPED).setPackage(getPackageName()));
        if (missed) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CH_MISSED, "Missed alarms", NotificationManager.IMPORTANCE_DEFAULT));
            String label = alarm.optString("label", "");
            nm.notify(ID_MISSED, new Notification.Builder(this, CH_MISSED).setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("Missed " + ("reminder".equals(kind) ? "reminder" : "alarm"))
                    .setContentText(label.isEmpty() ? String.format("%02d:%02d", alarm.optInt("hour"), alarm.optInt("minute")) : label)
                    .setAutoCancel(true).build());
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        stopSound();
        super.onDestroy();
    }
}
