package com.todoapp.focus;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONException;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String act = intent.getAction();
        if (AlarmScheduler.ACT_ALARM.equals(act)) {
            JSONObject a = AlarmStore.find(c, intent.getStringExtra("id") == null ? "" : intent.getStringExtra("id"));
            if (a == null || !a.optBoolean("enabled", true)) return;
            AlarmService.ring(c, a, "alarm", 0);
            try {
                a.put("skipDate", "");
                boolean repeats = a.optJSONArray("days") != null && a.optJSONArray("days").length() > 0;
                if (!repeats) a.put("enabled", false);           // one-time alarm switches itself off
                AlarmStore.save(c, a);
            } catch (JSONException ignored) {}
        } else if (AlarmScheduler.ACT_SNOOZE.equals(act)) {
            try {
                AlarmService.ring(c, new JSONObject(intent.getStringExtra("json")),
                        intent.getStringExtra("kind") == null ? "alarm" : intent.getStringExtra("kind"),
                        intent.getIntExtra("count", 1));
            } catch (Exception ignored) {}
        }
    }

}
