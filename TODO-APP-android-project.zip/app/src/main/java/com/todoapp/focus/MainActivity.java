package com.todoapp.focus;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    static MainActivity instance;
    static volatile boolean resumed = false;

    private static final int REQ_FILE = 101;
    private static final int REQ_PERMS = 102;
    private static final int REQ_RINGTONE = 103;
    private static final int REQ_AUDIO = 104;
    private String pickTarget = "";
    private android.media.MediaPlayer preview;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    /** Runs JavaScript in the main page (used by the floating controller). Safe to call from any thread. */
    static void evalJs(final String js) {
        final MainActivity a = instance;
        if (a == null || a.web == null) return;
        a.runOnUiThread(new Runnable() {
            @Override public void run() {
                try { a.web.evaluateJavascript(js, null); } catch (Throwable ignored) {}
            }
        });
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0d1020"));
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setDatabaseEnabled(true);
        st.setAllowFileAccess(false);
        st.setMediaPlaybackRequiresUserGesture(false);   // timer beeps / alarms
        st.setJavaScriptCanOpenWindowsAutomatically(false);
        st.setTextZoom(100);

        // ---- "Desktop site" mode, like the browser option: desktop user agent + wide layout viewport + zoom out to fit
        st.setUserAgentString(desktopUserAgent(st.getUserAgentString()));
        st.setUseWideViewPort(true);
        st.setLoadWithOverviewMode(true);
        st.setSupportZoom(true);
        st.setBuiltInZoomControls(true);
        st.setDisplayZoomControls(false);

        // keep the page alive (timers, JS calls from the floating button) while the app is in the background
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        web.addJavascriptInterface(new JsBridge(this), "AndroidBridge");
        web.setWebViewClient(new AppClient());
        web.setWebChromeClient(new AppChrome());
        web.setDownloadListener(new android.webkit.DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                // blob:/data: downloads are handled in JavaScript (native-bridge.js); real links open in the browser
                if (url != null && url.startsWith("http")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
                }
            }
        });

        web.loadUrl(AssetServer.ORIGIN + "/index.html");
        askPermissions();
    }

    /** Build a desktop Chrome user agent that keeps the WebView's real Chrome version. */
    private static String desktopUserAgent(String mobileUa) {
        String chrome = "124.0.0.0";
        if (mobileUa != null) {
            Matcher m = Pattern.compile("Chrome/([0-9.]+)").matcher(mobileUa);
            if (m.find()) chrome = m.group(1);
        }
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + chrome + " Safari/537.36";
    }

    private void askPermissions() {
        java.util.ArrayList<String> need = new java.util.ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    // ------------------------------------------------------------------ WebViewClient
    private class AppClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return AssetServer.intercept(MainActivity.this, request);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            String scheme = u.getScheme() == null ? "" : u.getScheme();
            if (AssetServer.HOST.equalsIgnoreCase(u.getHost())) return false;
            if (scheme.equals("http") || scheme.equals("https") || scheme.equals("mailto") || scheme.equals("tel")) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ WebChromeClient (alert / confirm / prompt / file picker)
    private class AppChrome extends WebChromeClient {
        @Override
        public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                    .show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                    .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                    .show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
            final EditText input = new EditText(MainActivity.this);
            input.setInputType(InputType.TYPE_CLASS_TEXT);
            input.setText(defaultValue == null ? "" : defaultValue);
            new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setView(input)
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm(input.getText().toString()))
                    .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                    .show();
            return true;
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
            return true;
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage cm) {
            android.util.Log.d("TodoApp-JS", cm.message() + " (" + cm.sourceId() + ":" + cm.lineNumber() + ")");
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_RINGTONE || requestCode == REQ_AUDIO) { handlePicked(requestCode, resultCode, data); return; }
        if (requestCode != REQ_FILE) return;
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        // every PDF given to the website is also copied into the app's private storage (never auto-deleted)
        if (result != null) FileStore.copyPdfsAsync(getApplicationContext(), result);
        if (fileCallback != null) {
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    // ------------------------------------------------------------------ ringtone / audio pickers
    void pickRingtone(final String target, final String currentUri) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                pickTarget = target;
                Intent i = new Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER);
                i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE,
                        android.media.RingtoneManager.TYPE_ALARM | android.media.RingtoneManager.TYPE_NOTIFICATION | android.media.RingtoneManager.TYPE_RINGTONE);
                i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
                i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
                if (currentUri != null && !currentUri.isEmpty() && !currentUri.startsWith("file:"))
                    i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(currentUri));
                try { startActivityForResult(i, REQ_RINGTONE); } catch (Exception ignored) {}
            }
        });
    }

    void pickAudioFile(final String target) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                pickTarget = target;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*");
                try { startActivityForResult(i, REQ_AUDIO); } catch (Exception ignored) {}
            }
        });
    }

    private void handlePicked(int req, int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) return;
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            if (req == REQ_RINGTONE) {
                Uri u = data.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (u == null) { o.put("type", "default").put("uri", "").put("title", "Default"); }
                else {
                    String title = "Ringtone";
                    try { title = android.media.RingtoneManager.getRingtone(this, u).getTitle(this); } catch (Exception ignored) {}
                    o.put("type", "system").put("uri", u.toString()).put("title", title);
                }
            } else {
                Uri u = data.getData();
                if (u == null) return;
                String name = "ringtone";
                android.database.Cursor c = getContentResolver().query(u, null, null, null, null);
                if (c != null) {
                    int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (c.moveToFirst() && idx >= 0) name = c.getString(idx);
                    c.close();
                }
                java.io.File dir = new java.io.File(getFilesDir(), "ringtones");
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                java.io.File out = new java.io.File(dir, System.currentTimeMillis() + "_" + FileStore.safeName(name, "ringtone.mp3"));
                java.io.InputStream in = getContentResolver().openInputStream(u);
                if (in == null) return;
                java.io.OutputStream os = new java.io.FileOutputStream(out);
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                os.close();
                in.close();
                o.put("type", "file").put("uri", Uri.fromFile(out).toString()).put("title", name);
            }
            evalJs("window.__nativeRingtonePicked&&window.__nativeRingtonePicked(" + org.json.JSONObject.quote(pickTarget) + "," + o.toString() + ")");
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "Could not use that sound", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    void previewSound(final String type, final String uri) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    if (preview != null) { preview.release(); preview = null; }
                    Uri u = (uri == null || uri.isEmpty() || "default".equals(type))
                            ? android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM) : Uri.parse(uri);
                    android.media.MediaPlayer mp = new android.media.MediaPlayer();
                    mp.setAudioAttributes(new android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ALARM).build());
                    if ("file".equals(u.getScheme())) mp.setDataSource(u.getPath()); else mp.setDataSource(MainActivity.this, u);
                    mp.prepare();
                    mp.start();
                    preview = mp;
                    web.postDelayed(new Runnable() {
                        @Override public void run() { if (preview == mp) { try { mp.release(); } catch (Exception ignored) {} preview = null; } }
                    }, 4000);
                } catch (Exception ignored) {}
            }
        });
    }

    // ------------------------------------------------------------------ lifecycle
    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        // back in the app: the floating controller is not needed on top of it
        if (FocusService.isOverlayOn()) {
            FocusService.setOverlay(getApplicationContext(), false, null);
            evalJs("window.__nativeFloatClosed&&window.__nativeFloatClosed()");
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // leaving the app while a task is being focused: show the floating controller automatically
        boolean auto = getSharedPreferences("float", MODE_PRIVATE).getBoolean("auto", true);
        if (auto && FocusService.isRunning() && android.provider.Settings.canDrawOverlays(this)) {
            FocusService.setOverlay(getApplicationContext(), true, null);
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String k = Cmd.takePending(getApplicationContext());
        if (!k.isEmpty()) evalJs("window.__nativeStartTask&&window.__nativeStartTask(" + org.json.JSONObject.quote(k) + ")");
    }

    @Override
    public void onBackPressed() {
        // behave like leaving a browser: keep the timer running in the background
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        FocusService.requestStop(getApplicationContext());
        if (instance == this) instance = null;
        if (web != null) {
            web.removeJavascriptInterface("AndroidBridge");
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
