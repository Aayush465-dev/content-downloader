package com.todoapp.focus;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Exposed to JavaScript as window.AndroidBridge */
public class JsBridge {
    private static final String TAG = "TodoApp";

    private static class Session {
        String category, name, mime;
        File part;
        FileOutputStream out;
    }

    private final MainActivity act;
    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<Integer, Session> sessions = new ConcurrentHashMap<>();
    private final AtomicInteger ids = new AtomicInteger(1);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    JsBridge(MainActivity activity) {
        this.act = activity;
        this.app = activity.getApplicationContext();
    }

    // ------------------------------------------------------------------ misc
    @JavascriptInterface
    public boolean isAndroidApp() { return true; }

    @JavascriptInterface
    public void toast(final String msg) {
        main.post(new Runnable() {
            @Override public void run() { Toast.makeText(app, msg, Toast.LENGTH_SHORT).show(); }
        });
    }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        main.post(new Runnable() {
            @Override public void run() {
                if (on) act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
    }

    // ------------------------------------------------------------------ focus state / floating controller
    @JavascriptInterface
    public boolean hasOverlayPermission() { return Settings.canDrawOverlays(app); }

    @JavascriptInterface
    public boolean isForeground() { return MainActivity.resumed; }

    /** Called by the page every second while a task is focused (and once when focus ends). */
    @JavascriptInterface
    public void focusState(final String stateJson) {
        boolean has = false;
        try { has = new org.json.JSONObject(stateJson).optBoolean("hasTask", false); } catch (Exception ignored) {}
        if (!has) { FocusService.pushState(stateJson); return; }
        if (FocusService.isRunning()) FocusService.pushState(stateJson);
        else main.post(new Runnable() {
            @Override public void run() { FocusService.ensureRunning(app, stateJson, false); }
        });
    }

    /** @return "ok", "permission" or "error" */
    @JavascriptInterface
    public String startFloat(final String stateJson) {
        if (!Settings.canDrawOverlays(app)) {
            main.post(new Runnable() {
                @Override public void run() {
                    Toast.makeText(app, "Allow \"Display over other apps\" for TODO APP, then tap Float again",
                            Toast.LENGTH_LONG).show();
                    try {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + app.getPackageName()));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        act.startActivity(i);
                    } catch (Exception e) { Log.w(TAG, "overlay settings", e); }
                }
            });
            return "permission";
        }
        main.post(new Runnable() {
            @Override public void run() {
                try {
                    FocusService.setOverlay(app, true, stateJson);
                    // go to the home screen so the user can open any other app; the floating timer stays on top
                    main.postDelayed(new Runnable() {
                        @Override public void run() { act.moveTaskToBack(true); }
                    }, 450);
                } catch (Exception e) { Log.w(TAG, "start float", e); }
            }
        });
        return "ok";
    }

    @JavascriptInterface
    public void stopFloat() {
        main.post(new Runnable() { @Override public void run() { FocusService.setOverlay(app, false, null); } });
    }

    @JavascriptInterface
    public void panelData(String json) { FocusService.setPanelData(json); }

    @JavascriptInterface
    public void setLandscape(final boolean on) {
        main.post(new Runnable() {
            @Override public void run() {
                act.setRequestedOrientation(on ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            }
        });
    }

    @JavascriptInterface
    public String takePendingCommand() { return Cmd.takePending(app); }

    // ------------------------------------------------------------------ alarms
    @JavascriptInterface
    public String alarmsGet() { return AlarmStore.all(app).toString(); }

    @JavascriptInterface
    public String alarmSave(String json) {
        try { return AlarmStore.save(app, new org.json.JSONObject(json)); } catch (Exception e) { return AlarmStore.all(app).toString(); }
    }

    @JavascriptInterface
    public String alarmDelete(String id) { return AlarmStore.delete(app, id); }

    @JavascriptInterface
    public String alarmToggle(String id, boolean on) { return AlarmStore.update(app, id, "enabled", on); }

    /** skip (or un-skip) the next ring of a repeating alarm */
    @JavascriptInterface
    public String alarmSkipNext(String id) {
        org.json.JSONObject a = AlarmStore.find(app, id);
        if (a == null) return AlarmStore.all(app).toString();
        boolean has = !a.optString("skipDate", "").isEmpty();
        String value = "";
        if (!has) {
            long t = AlarmStore.nextTrigger(a, System.currentTimeMillis());
            if (t > 0) {
                java.util.Calendar c = java.util.Calendar.getInstance();
                c.setTimeInMillis(t);
                value = AlarmStore.dateStr(c);
            }
        }
        return AlarmStore.update(app, id, "skipDate", value);
    }

    @JavascriptInterface
    public void alarmTest(String json) {
        try { AlarmService.ring(app, new org.json.JSONObject(json), "alarm", 0); } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void pickRingtone(String target, String currentUri) { act.pickRingtone(target, currentUri); }

    @JavascriptInterface
    public void pickAudioFile(String target) { act.pickAudioFile(target); }

    @JavascriptInterface
    public void previewSound(String type, String uri) { act.previewSound(type, uri); }

    @JavascriptInterface
    public void openFullScreenSettings() {
        main.post(new Runnable() {
            @Override public void run() {
                try {
                    Intent i = android.os.Build.VERSION.SDK_INT >= 34
                            ? new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + app.getPackageName()))
                            : new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, app.getPackageName());
                    act.startActivity(i);
                } catch (Exception e) { Log.w(TAG, "fullscreen settings", e); }
            }
        });
    }

    @JavascriptInterface
    public void requestBatteryExemption() {
        main.post(new Runnable() {
            @Override public void run() {
                try {
                    act.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + app.getPackageName())));
                } catch (Exception e) {
                    try { act.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception ignored) {}
                }
            }
        });
    }

    // ------------------------------------------------------------------ task reminders
    @JavascriptInterface
    public void setReminderSettings(String json) { ReminderCenter.setSettings(app, json); }

    @JavascriptInterface
    public void syncReminders(String json) { ReminderCenter.sync(app, json); }

    @JavascriptInterface
    public void testReminder(final String name) {
        main.post(new Runnable() { @Override public void run() { ReminderCenter.test(app, name); } });
    }

    // ------------------------------------------------------------------ saving files (chunked)
    @JavascriptInterface
    public int saveBegin(String category, String name, String mime) {
        try {
            Session s = new Session();
            s.category = category == null ? "other" : category;
            s.name = name == null ? "file" : name;
            s.mime = mime;
            int id = ids.getAndIncrement();
            s.part = new File(app.getCacheDir(), "save_" + id + ".part");
            s.out = new FileOutputStream(s.part);
            sessions.put(id, s);
            return id;
        } catch (IOException e) {
            Log.w(TAG, "saveBegin", e);
            return -1;
        }
    }

    @JavascriptInterface
    public void saveChunk(int id, String base64) {
        Session s = sessions.get(id);
        if (s == null || s.out == null) return;
        try {
            s.out.write(Base64.decode(base64, Base64.DEFAULT));
        } catch (Exception e) { Log.w(TAG, "saveChunk", e); }
    }

    @JavascriptInterface
    public void saveEnd(int id) {
        final Session s = sessions.remove(id);
        if (s == null) return;
        try { s.out.close(); } catch (IOException ignored) {}
        worker.execute(new Runnable() {
            @Override public void run() { finish(s); }
        });
    }

    private void finish(final Session s) {
        try {
            String name = FileStore.safeName(s.name, "file");
            if ("report_html".equals(s.category)) {
                renderReport(s, name);
                return;
            }
            String sub = "reports".equals(s.category) ? FileStore.DIR_REPORTS
                    : "questions".equals(s.category) ? FileStore.DIR_QUESTIONS : FileStore.DIR_OTHER;
            String mime = FileStore.mimeFor(name);
            if ("application/octet-stream".equals(mime) && s.mime != null && !s.mime.isEmpty()) mime = s.mime;
            announce(FileStore.saveToDownloads(app, s.part, sub, name, mime));
        } catch (Throwable t) {
            Log.w(TAG, "save failed", t);
            FileStore.toast(app, "Could not save file: " + t.getMessage());
        } finally {
            if (!"report_html".equals(s.category)) //noinspection ResultOfMethodCallIgnored
                s.part.delete();
        }
    }

    private void announce(String result) {
        if (result.startsWith("EXISTS:")) FileStore.toast(app, "Already saved in " + result.substring(7));
        else FileStore.toast(app, "Saved in " + result);
    }

    private void renderReport(final Session s, final String name) throws IOException {
        final StringBuilder html = new StringBuilder();
        FileInputStream in = new FileInputStream(s.part);
        try {
            byte[] buf = new byte[64 * 1024];
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            html.append(bos.toString("UTF-8"));
        } finally { in.close(); }
        //noinspection ResultOfMethodCallIgnored
        s.part.delete();

        final String pdfName = name.toLowerCase().endsWith(".pdf") ? name : name + ".pdf";
        final File tmpPdf = new File(app.getCacheDir(), "report_" + System.nanoTime() + ".pdf");
        main.post(new Runnable() {
            @Override public void run() {
                ReportPdf.render(act, html.toString(), pdfName, tmpPdf, new ReportPdf.Done() {
                    @Override public void onFinished(final File pdf, final String error) {
                        if (pdf == null) {
                            if (!"FALLBACK".equals(error)) FileStore.toast(app, "Report PDF failed: " + error);
                            return;
                        }
                        worker.execute(new Runnable() {
                            @Override public void run() {
                                try {
                                    announce(FileStore.saveToDownloads(app, pdf, FileStore.DIR_REPORTS, pdfName, "application/pdf"));
                                } catch (Throwable t) {
                                    FileStore.toast(app, "Could not save report: " + t.getMessage());
                                } finally {
                                    //noinspection ResultOfMethodCallIgnored
                                    pdf.delete();
                                }
                            }
                        });
                    }
                });
            }
        });
    }
}
