package com.todoapp.focus;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.print.PdfWriter;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;

/** Renders report HTML (sent from the test website) in a hidden WebView and writes it as a PDF file. */
final class ReportPdf {
    interface Done {
        void onFinished(File pdf, String error);
    }

    private ReportPdf() {}

    /** Must be called on the main thread. */
    static void render(final Activity act, final String html, final String jobName, final File outPdf, final Done done) {
        final WebView wv = new WebView(act);
        wv.getSettings().setJavaScriptEnabled(false);
        wv.getSettings().setAllowFileAccess(false);
        wv.getSettings().setLoadWithOverviewMode(false);
        wv.layout(0, 0, 794, 1123);
        final boolean[] started = {false};
        final Handler h = new Handler(Looper.getMainLooper());

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return AssetServer.intercept(act, request);
            }

            @Override
            public void onPageFinished(final WebView view, String url) {
                if (started[0]) return;
                started[0] = true;
                // small delay so images / fonts are decoded before the pages are laid out
                h.postDelayed(new Runnable() {
                    @Override public void run() { writePdf(act, view, jobName, outPdf, done); }
                }, 900);
            }
        });
        wv.loadDataWithBaseURL(AssetServer.ORIGIN + "/", html, "text/html", "UTF-8", null);
    }

    private static void writePdf(final Activity act, final WebView wv, final String jobName, final File outPdf, final Done done) {
        final PrintDocumentAdapter adapter;
        try {
            adapter = wv.createPrintDocumentAdapter(jobName);
        } catch (Throwable t) {
            finish(wv, done, null, String.valueOf(t));
            return;
        }
        PdfWriter.write(adapter, outPdf, new PdfWriter.Callback() {
            @Override
            public void onDone(final boolean ok, final String error) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override public void run() {
                        if (ok) {
                            finish(wv, done, outPdf, null);
                        } else {
                            // fallback: system print dialog -> "Save as PDF"
                            try {
                                PrintManager pm = (PrintManager) act.getSystemService(Activity.PRINT_SERVICE);
                                pm.print(jobName, wv.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
                                FileStore.toast(act, "Choose \"Save as PDF\" in the print screen");
                                done.onFinished(null, "FALLBACK");
                            } catch (Throwable t) {
                                finish(wv, done, null, error + " / " + t);
                            }
                        }
                    }
                });
            }
        });
    }

    private static void finish(WebView wv, Done done, File pdf, String error) {
        try { wv.destroy(); } catch (Throwable ignored) {}
        done.onFinished(pdf, error);
    }
}
