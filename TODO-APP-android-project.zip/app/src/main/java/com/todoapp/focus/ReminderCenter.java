package com.todoapp.focus;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Task reminders. The web page computes the upcoming reminders (task + time) and syncs them here;
 * Android alarms fire them even when the app is closed.
 */
final class ReminderCenter {
    static final String ACT_FIRE = "com.todoapp.focus.REMINDER_FIRE";
    private ReminderCenter() {}

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("reminders", Context.MODE_PRIVATE); }

    static JSONObject settings(Context c) {
        try { return new JSONObject(sp(c).getString("settings", "{}")); } catch (JSONException e) { return new JSONObject(); }
    }

    static void setSettings(Context c, String json) { sp(c).edit().putString("settings", json).apply(); }

    private static JSONArray list(Context c) {
        try { return new JSONArray(sp(c).getString("list", "[]")); } catch (JSONException e) { return new JSONArray(); }
    }

    static void sync(Context c, String json) {
        JSONArray fresh;
        try { fresh = new JSONArray(json); } catch (JSONException e) { return; }
        // keep reminders that were snoozed on the phone (the web page does not know about them)
        JSONArray old = list(c);
        long now = System.currentTimeMillis();
        for (int i = 0; i < old.length(); i++) {
            JSONObject o = old.optJSONObject(i);
            if (o != null && o.optBoolean("snz", false) && o.optLong("at") > now) fresh.put(o);
        }
        sp(c).edit().putString("list", fresh.toString()).apply();
        scheduleNext(c);
    }

    static void scheduleNext(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 31, new Intent(c, ReminderReceiver.class).setAction(ACT_FIRE),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        JSONArray l = list(c);
        long next = Long.MAX_VALUE;
        for (int i = 0; i < l.length(); i++) {
            JSONObject o = l.optJSONObject(i);
            if (o != null) next = Math.min(next, o.optLong("at"));
        }
        am.cancel(pi);
        if (next == Long.MAX_VALUE) return;
        long when = Math.max(next, System.currentTimeMillis() + 1000);
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    /** called by the alarm: deliver everything that is due, then schedule the next one */
    static void fireDue(Context c) {
        JSONArray l = list(c), rest = new JSONArray();
        long now = System.currentTimeMillis();
        for (int i = 0; i < l.length(); i++) {
            JSONObject o = l.optJSONObject(i);
            if (o == null) continue;
            if (o.optLong("at") <= now + 1500) {
                if (o.optLong("at") > now - 6 * 3600 * 1000L) deliver(c, o.optString("key"), o.optString("name"));
            } else rest.put(o);
        }
        sp(c).edit().putString("list", rest.toString()).apply();
        scheduleNext(c);
    }

    static void snooze(Context c, String key, String name, int minutes) {
        JSONArray l = list(c);
        try {
            l.put(new JSONObject().put("key", key).put("name", name).put("snz", true).put("at", System.currentTimeMillis() + minutes * 60000L));
        } catch (JSONException ignored) {}
        sp(c).edit().putString("list", l.toString()).apply();
        scheduleNext(c);
    }

    // ------------------------------------------------------------------ decide how to deliver
    static void deliver(Context c, String key, String name) {
        JSONObject st = settings(c);
        if (!st.optBoolean("enabled", true)) return;

        boolean focusing = FocusService.isFocusing();
        if (focusing && key.equals(FocusService.focusKey())) return;            // already focusing this task -> no reminder

        String other = st.optString("otherMode", "notify");                     // silent | notify | screen
        if (focusing) {
            if ("screen".equals(other) && FocusService.isMaximized() && MainActivity.resumed) {
                MainActivity.evalJs("window.__showReminderPopup&&window.__showReminderPopup(" + JSONObject.quote(key) + "," + JSONObject.quote(name) + ")");
                return;
            }
            notifyTask(c, key, name, "silent".equals(other), st);
            return;
        }
        if ("alarm".equals(st.optString("style", "notification"))) {
            try {
                JSONObject a = new JSONObject().put("id", "rem_" + key).put("label", name).put("key", key)
                        .put("snoozeOn", true).put("snoozeMin", st.optInt("snooze", 10)).put("snoozeMax", 3)
                        .put("autoStop", 1).put("vibrate", st.optBoolean("vibrate", true)).put("volume", 85).put("gradual", false)
                        .put("sound", st.optJSONObject("sound") == null ? new JSONObject() : st.optJSONObject("sound"));
                AlarmService.ring(c, a, "reminder", 0);
                return;
            } catch (JSONException ignored) {}
        }
        notifyTask(c, key, name, false, st);
    }

    private static String channelFor(Context c, boolean silent, JSONObject st) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (silent) {
            NotificationChannel ch = new NotificationChannel("rem_silent", "Silent reminders", NotificationManager.IMPORTANCE_LOW);
            ch.setSound(null, null);
            ch.enableVibration(false);
            nm.createNotificationChannel(ch);
            return "rem_silent";
        }
        JSONObject s = st.optJSONObject("sound");
        String uri = s == null ? "" : s.optString("uri", "");
        String type = s == null ? "default" : s.optString("type", "default");
        boolean vib = st.optBoolean("vibrate", true);
        boolean custom = !uri.isEmpty() && "system".equals(type);
        String id = "rem_" + (custom ? Integer.toHexString(uri.hashCode()) : "default") + (vib ? "_v" : "_n");
        NotificationChannel ch = new NotificationChannel(id, "Task reminders", NotificationManager.IMPORTANCE_HIGH);
        if (custom) ch.setSound(Uri.parse(uri), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).build());
        ch.enableVibration(vib);
        nm.createNotificationChannel(ch);
        return id;
    }

    private static void notifyTask(Context c, String key, String name, boolean silent, JSONObject st) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        int id = 6000 + (key.hashCode() & 0xFFFF);
        PendingIntent open = PendingIntent.getActivity(c, id, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        boolean focusing = FocusService.isFocusing();
        Notification.Builder b = new Notification.Builder(c, channelFor(c, silent, st))
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xFF6366F1)
                .setContentTitle("⏰ " + name)
                .setContentText(focusing ? "You are focusing on another task - switch now?" : "Time to start this task")
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, focusing ? "Switch" : "Start focus",
                        ActionReceiver.pi(c, ActionReceiver.ACT_START, key, name, id)).build())
                .addAction(new Notification.Action.Builder(null, "Snooze " + st.optInt("snooze", 10) + "m",
                        ActionReceiver.pi(c, ActionReceiver.ACT_SNOOZE, key, name, id)).build());
        nm.notify(id, b.build());
    }

    static void test(Context c, String name) {
        deliver(c, "test|" + System.currentTimeMillis(), name == null || name.isEmpty() ? "Test reminder" : name);
    }
}
