package com.todoapp.focus;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Re-creates alarms and reminders after a reboot, app update, or time / time-zone change. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        AlarmScheduler.rescheduleAll(c);
        ReminderCenter.scheduleNext(c);
    }
}
