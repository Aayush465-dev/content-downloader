package com.todoapp.focus;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * 1) Keeps a private copy of every PDF the user gives to the test website (never deleted by the app).
 * 2) Saves output files into  Download/PDFs/Reports , Download/PDFs/Questions  (and Download/TODO APP for other files).
 */
final class FileStore {
    private static final String TAG = "TodoApp";
    private static final Object LOCK = new Object();

    static final String DIR_REPORTS = "PDFs/Reports";
    static final String DIR_QUESTIONS = "PDFs/Questions";
    static final String DIR_OTHER = "TODO APP";

    private FileStore() {}

    static void toast(final Context c, final String msg) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override public void run() { Toast.makeText(c.getApplicationContext(), msg, Toast.LENGTH_LONG).show(); }
        });
    }

    static String safeName(String name, String fallback) {
        if (name == null) name = "";
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+", " ").replaceAll("\\s+", " ").trim();
        if (name.length() > 150) {
            int dot = name.lastIndexOf('.');
            String ext = (dot > 0 && name.length() - dot <= 8) ? name.substring(dot) : "";
            name = name.substring(0, 150 - ext.length()) + ext;
        }
        return name.isEmpty() ? fallback : name;
    }

    static String mimeFor(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".zip")) return "application/zip";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    // ------------------------------------------------------------------ private copy of given PDFs
    /** App-private folder (not visible to other apps / file managers). Files here are never deleted by the app. */
    static File privateDir(Context c) {
        File d = new File(c.getFilesDir(), "test_pdfs");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    static void copyPdfsAsync(final Context ctx, final Uri[] uris) {
        if (uris == null || uris.length == 0) return;
        new Thread(new Runnable() {
            @Override public void run() {
                int saved = 0;
                for (Uri u : uris) {
                    try { if (copyPdf(ctx, u)) saved++; } catch (Throwable t) { Log.w(TAG, "private copy failed", t); }
                }
                if (saved > 0) toast(ctx, "Saved a private copy of " + saved + " PDF" + (saved > 1 ? "s" : ""));
            }
        }, "pdf-private-copy").start();
    }

    private static boolean copyPdf(Context ctx, Uri uri) throws Exception {
        ContentResolver cr = ctx.getContentResolver();
        String name = null;
        Cursor q = null;
        try {
            q = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (q != null && q.moveToFirst()) name = q.getString(0);
        } catch (Exception ignored) {
        } finally { if (q != null) q.close(); }
        if (name == null) name = uri.getLastPathSegment() == null ? "file.pdf" : uri.getLastPathSegment();
        String mime = cr.getType(uri);
        boolean isPdf = "application/pdf".equals(mime) || name.toLowerCase(Locale.ROOT).matches(".*\\.pdf?$");
        if (!isPdf) return false;

        File dir = privateDir(ctx);
        File tmp = new File(ctx.getCacheDir(), "incoming_" + System.nanoTime() + ".pdf");
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        InputStream in = cr.openInputStream(uri);
        if (in == null) return false;
        try {
            OutputStream out = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) { md.update(buf, 0, n); out.write(buf, 0, n); }
            } finally { out.close(); }
        } finally { in.close(); }

        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format(Locale.ROOT, "%02x", b));
        String hash = sb.toString();

        synchronized (LOCK) {
            File index = new File(dir, "index.tsv");
            if (index.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(index));
                try {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if (line.startsWith(hash + "\t") && new File(dir, line.substring(hash.length() + 1)).exists()) {
                            //noinspection ResultOfMethodCallIgnored
                            tmp.delete();
                            return false; // identical copy already stored
                        }
                    }
                } finally { br.close(); }
            }
            String base = safeName(name, "file.pdf");
            File target = new File(dir, base);
            int k = 2;
            while (target.exists()) {
                int dot = base.lastIndexOf('.');
                String stem = dot > 0 ? base.substring(0, dot) : base;
                String ext = dot > 0 ? base.substring(dot) : "";
                target = new File(dir, stem + " (" + k++ + ")" + ext);
            }
            if (!tmp.renameTo(target)) { copyFile(tmp, target); //noinspection ResultOfMethodCallIgnored
                tmp.delete(); }
            FileWriter fw = new FileWriter(index, true);
            try { fw.write(hash + "\t" + target.getName() + "\n"); } finally { fw.close(); }
        }
        return true;
    }

    static void copyFile(File from, File to) throws IOException {
        InputStream in = new FileInputStream(from);
        try {
            OutputStream out = new FileOutputStream(to);
            try {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally { out.close(); }
        } finally { in.close(); }
    }

    // ------------------------------------------------------------------ save into Download/<sub>/
    /** @return the readable location, prefixed with "EXISTS:" when an identical file was already there. */
    static String saveToDownloads(Context ctx, File src, String sub, String name, String mime) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = ctx.getContentResolver();
            String rel = Environment.DIRECTORY_DOWNLOADS + "/" + sub;
            Uri coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Cursor q = null;
            try {
                q = cr.query(coll, new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.SIZE},
                        MediaStore.MediaColumns.DISPLAY_NAME + "=? AND (" + MediaStore.MediaColumns.RELATIVE_PATH + "=? OR "
                                + MediaStore.MediaColumns.RELATIVE_PATH + "=?)",
                        new String[]{name, rel, rel + "/"}, null);
                while (q != null && q.moveToNext()) {
                    if (q.getLong(1) == src.length()) return "EXISTS:" + rel + "/" + name;
                }
            } catch (Exception ignored) {
            } finally { if (q != null) q.close(); }

            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(coll, cv);
            if (uri == null) throw new IOException("Could not create file in Downloads");
            try {
                OutputStream out = cr.openOutputStream(uri);
                if (out == null) throw new IOException("Could not open output stream");
                InputStream in = new FileInputStream(src);
                try {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } finally { in.close(); out.close(); }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(uri, done, null, null);
            } catch (IOException e) {
                cr.delete(uri, null, null);
                throw e;
            }
            return rel + "/" + name;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), sub);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File out = new File(dir, name);
            if (out.exists()) {
                if (out.length() == src.length()) return "EXISTS:Download/" + sub + "/" + name;
                int dot = name.lastIndexOf('.');
                String stem = dot > 0 ? name.substring(0, dot) : name;
                String ext = dot > 0 ? name.substring(dot) : "";
                int k = 1;
                while (out.exists()) out = new File(dir, stem + " (" + k++ + ")" + ext);
            }
            copyFile(src, out);
            MediaScannerConnection.scanFile(ctx, new String[]{out.getAbsolutePath()}, null, null);
            return "Download/" + sub + "/" + out.getName();
        }
    }
}
