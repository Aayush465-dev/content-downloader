/* TODO APP extras: floating controller + persistent focus notification bridge, task reminders, alarms UI. */
(function () {
  'use strict';
  var B = window.AndroidBridge || null;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var pad = function (n) { return String(n).padStart(2, '0'); };
  var toast = function (m) { try { showToast(m); } catch (e) { console.log(m); } };

  /* ====================================================== settings */
  var DEF_REMIND = { enabled: true, auto: true, time: '09:00', style: 'notification', otherMode: 'notify', vibrate: true, snooze: 10, sound: { type: 'default', uri: '', title: 'Default' } };
  var DEF_ALARM = { snoozeOn: true, snoozeMin: 10, snoozeMax: 3, volume: 80, gradual: true, vibrate: true, autoStop: 5, sound: { type: 'default', uri: '', title: 'Default alarm sound' } };
  var MODE_LABEL = { all_today: "today's total of all tasks", task_today: "today's total of the running task", task_total: 'total of the running task' };

  function cfg() {
    appSettings.remind = Object.assign({}, DEF_REMIND, appSettings.remind || {});
    appSettings.alarmDef = Object.assign({}, DEF_ALARM, appSettings.alarmDef || {});
    if (appSettings.rotateMax === undefined) appSettings.rotateMax = true;
    if (appSettings.autoFloat === undefined) appSettings.autoFloat = true;
    return appSettings;
  }
  function pushRemSettings() { if (B) { try { B.setReminderSettings(JSON.stringify(cfg().remind)); B.setAutoFloat(cfg().autoFloat !== false); } catch (e) {} } }
  function saveCfg() {
    localStorage.setItem('utmxSettings', JSON.stringify(appSettings));
    pushRemSettings();
    syncReminders(true);
  }

  window.syncFloatSettingsUI = function () {
    $$('.float-mode-select').forEach(function (s) { s.value = appSettings.floatMode || 'all_today'; });
  };
  window.saveFloatSettings = function (v) {
    appSettings.floatMode = MODE_LABEL[v] ? v : 'all_today';
    localStorage.setItem('utmxSettings', JSON.stringify(appSettings));
    window.syncFloatSettingsUI();
    pushFocus();
    toast('Floating button shows ' + MODE_LABEL[appSettings.floatMode]);
  };

  /* ====================================================== task reminder field / tag */
  window.__parseRemind = function (s) {
    s = String(s || '').trim().toLowerCase();
    if (/^(off|none|no|false)$/.test(s)) return 'off';
    var m = s.match(/(\d{1,2})\s*[:.]\s*(\d{2})\s*(am|pm)?/);
    if (!m) return undefined;
    var h = +m[1], mi = +m[2];
    if (m[3] === 'pm' && h < 12) h += 12;
    if (m[3] === 'am' && h === 12) h = 0;
    if (h > 23 || mi > 59) return undefined;
    return pad(h) + ':' + pad(mi);
  };
  window.__readRemindField = function () {
    var mode = $('#task-remind-mode');
    if (!mode) return undefined;
    if (mode.value === 'off') return 'off';
    if (mode.value === 'custom') return $('#task-remind-time').value || '09:00';
    return undefined;
  };
  window.__setRemindField = function (v) {
    var mode = $('#task-remind-mode'), tm = $('#task-remind-time');
    if (!mode) return;
    if (v === 'off') mode.value = 'off';
    else if (v && /^\d{1,2}:\d{2}$/.test(v)) { mode.value = 'custom'; tm.value = v.padStart(5, '0'); }
    else mode.value = 'auto';
    tm.classList.toggle('hidden', mode.value !== 'custom');
  };
  window.__remindModeChange = function () {
    $('#task-remind-time').classList.toggle('hidden', $('#task-remind-mode').value !== 'custom');
  };
  function injectTaskField() {
    var tags = $('#task-tags');
    if (!tags || $('#task-remind-wrap')) return;
    var lab = tags.closest('label') || tags;
    lab.insertAdjacentHTML('afterend',
      '<div id="task-remind-wrap" style="margin:8px 0"><label>⏰ Reminder' +
      '<div style="display:flex;gap:8px;align-items:center">' +
      '<select id="task-remind-mode" onchange="__remindModeChange()"><option value="auto">Auto (default time)</option><option value="custom">Custom time</option><option value="off">No reminder</option></select>' +
      '<input type="time" id="task-remind-time" value="09:00" class="hidden" style="max-width:150px"></div></label></div>');
  }

  /* ====================================================== focus state -> native (notification + floating controller) */
  var floatOn = false;
  function hasTask() { return typeof currentFocus !== 'undefined' && !!(currentFocus && (currentFocus.taskId || currentFocus.spId)); }
  function keyOf() { return currentFocus.type === 'regular' ? 'reg|' + currentFocus.taskId : 'sp|' + currentFocus.spId + '|' + currentFocus.subId; }

  function taskDay(day) {   /* seconds of the running task on a given day (or all days when day == null) */
    if (!hasTask()) return 0;
    if (currentFocus.type === 'regular') {
      var t = tasks.find(function (x) { return x.id === currentFocus.taskId; });
      if (!t || !t.dailyFocus) return 0;
      if (day) return t.dailyFocus[day] || 0;
      return Object.values(t.dailyFocus).reduce(function (a, b) { return a + b; }, 0);
    }
    var sp = specialTasks.find(function (x) { return x.id === currentFocus.spId; });
    if (!sp || !sp.focus) return 0;
    if (day) return (sp.focus[day] && sp.focus[day][currentFocus.subId]) || 0;
    var sum = 0;
    Object.values(sp.focus).forEach(function (d) { sum += (d && d[currentFocus.subId]) || 0; });
    return sum;
  }
  function floatSeconds() {
    var mode = appSettings.floatMode || 'all_today', today = getLocalToday();
    if (mode === 'all_today' || !hasTask()) return getTotalFocus(today);
    return mode === 'task_today' ? taskDay(today) : taskDay(null);
  }
  function focusState() {
    var nameEl = $('#active-task-name'), fs = $('#modal-focus-fullscreen'), today = getLocalToday();
    return {
      name: hasTask() && nameEl ? nameEl.innerText : 'No task',
      key: hasTask() ? keyOf() : '',
      active: !!currentFocus.active,
      hasTask: hasTask(),
      maximized: !!fs && !fs.classList.contains('hidden'),
      sec: floatSeconds(),
      todaySec: getTotalFocus(today),
      taskSec: taskDay(null),
      ts: Date.now()
    };
  }
  function pushFocus() { if (B) { try { B.focusState(JSON.stringify(focusState())); } catch (e) {} } }
  function refreshFloatButtons() {
    $$('.float-btn').forEach(function (b) {
      b.innerText = floatOn ? '🪟 Float: ON' : '🪟 Float';
      b.style.background = floatOn ? '#10b981' : '#f59e0b';
    });
  }

  window.toggleFloat = function () {
    if (!B) return;
    if (floatOn) { try { B.stopFloat(); } catch (e) {} floatOn = false; refreshFloatButtons(); toast('Floating timer closed'); return; }
    if (!hasTask()) { toast('Start focusing on a task first, then tap Float.'); return; }
    var r = 'error';
    try { r = B.startFloat(JSON.stringify(focusState())); } catch (e) {}
    if (r === 'ok') { floatOn = true; refreshFloatButtons(); }
    else if (r === 'permission') toast('Turn on "Display over other apps" for TODO APP, then tap Float again.');
    else toast('Could not start the floating timer.');
  };

  function startByKey(k, minimizeIfBackground) {
    try {
      var p = String(k).split('|');
      if (p[0] === 'reg') startFocus('regular', p[1]);
      else if (p[0] === 'sp') startFocus('special', p[1], p[2]);
      if (minimizeIfBackground && B && !B.isForeground()) { var m = $('#btn-focus-minimize'); if (m) m.click(); }
    } catch (e) { console.error(e); toast('Task not found'); }
    pushFocus();
  }

  function setupFocusBridge() {
    if (!B) return;
    var _ufi = window.updateFocusUI;
    window.updateFocusUI = function () { var r = _ufi.apply(this, arguments); pushFocus(); return r; };
    var _cf = window.completeFocus;
    window.completeFocus = function () { var r = _cf.apply(this, arguments); pushFocus(); return r; };

    window.__nativeTick = function () {
      try { if (currentFocus.active && typeof focusTickFn === 'function') focusTickFn(); } catch (e) { console.error(e); }
      pushFocus();
    };
    window.__nativeFloatCmd = function (cmd) {
      try {
        if (cmd === 'toggle') toggleMainFocus();
        else if (cmd === 'pause') pauseFocus();
        else if (cmd === 'resume') resumeFocus();
      } catch (e) { console.error(e); }
      pushFocus();
    };
    window.__nativeFloatClosed = function () { floatOn = false; refreshFloatButtons(); };
    window.__nativeSwitch = function (k) { startByKey(k, true); };
    window.__nativeStartTask = function (k) { startByKey(k, false); };

    /* mini analysis + task list for the floating panel */
    window.__nativePanelData = function () {
      var today = getLocalToday(), yest = addDays(today, -1), dates = {};
      tasks.forEach(function (t) { Object.keys(t.dailyFocus || {}).forEach(function (d) { dates[d] = 1; }); });
      specialTasks.forEach(function (sp) { Object.keys(sp.focus || {}).forEach(function (d) { dates[d] = 1; }); });
      var top = 0, topDate = '';
      Object.keys(dates).forEach(function (d) { if (d === today) return; var v = getTotalFocus(d); if (v > top) { top = v; topDate = d; } });
      var list = [];
      tasks.filter(function (t) { return !t.completed; }).forEach(function (t) {
        list.push({ k: 'reg|' + t.id, n: t.description, t: (t.dailyFocus && t.dailyFocus[today]) || 0, d: t.date });
      });
      specialTasks.filter(function (sp) { return sp.status === 'active'; }).forEach(function (sp) {
        (sp.subtasks || []).filter(function (s) { return s.status === 'active'; }).forEach(function (s) {
          list.push({ k: 'sp|' + sp.id + '|' + s.id, n: '★ ' + sp.name + ' - ' + s.name, t: (sp.focus && sp.focus[today] && sp.focus[today][s.id]) || 0, d: today });
        });
      });
      list.sort(function (a, b) {
        var pa = a.d === today ? 0 : 1, pb = b.d === today ? 0 : 1;
        return pa - pb || (a.d < b.d ? -1 : a.d > b.d ? 1 : 0);
      });
      try { B.panelData(JSON.stringify({ yesterday: getTotalFocus(yest), top: top, topDate: topDate.slice(5), tasks: list.slice(0, 300) })); } catch (e) {}
    };

    /* rotate to landscape while the focus screen is maximized */
    var fs = $('#modal-focus-fullscreen');
    if (fs) {
      var last = null;
      var apply = function () {
        var open = !fs.classList.contains('hidden');
        var want = open && cfg().rotateMax !== false;
        if (want !== last) { last = want; try { B.setLandscape(want); } catch (e) {} }
        pushFocus();
      };
      new MutationObserver(apply).observe(fs, { attributes: true, attributeFilter: ['class'] });
    }

    /* reminder popup on the maximized focus screen (Cancel / Switch) */
    window.__showReminderPopup = function (key, name) {
      var host = $('#modal-focus-fullscreen');
      if (!host) return;
      var old = $('#rem-popup'); if (old) old.remove();
      var el = document.createElement('div');
      el.id = 'rem-popup';
      el.innerHTML = '<div class="rp-ic">⏰</div><div class="rp-body"><div class="rp-t">Reminder</div><div class="rp-n">' + esc(name) +
        '</div><div class="rp-s">You are focusing on another task.</div></div><div class="rp-b"><button class="rp-cancel">Cancel</button><button class="rp-switch">Switch</button></div>';
      host.appendChild(el);
      $('.rp-cancel', el).onclick = function () { el.remove(); };
      $('.rp-switch', el).onclick = function () { el.remove(); startByKey(key, false); };
      setTimeout(function () { if (el.parentNode) el.remove(); }, 60000);
    };
  }

  /* ====================================================== task reminders -> native */
  var lastRemSig = '';
  function buildReminders() {
    var R = cfg().remind;
    if (!R.enabled) return [];
    var now = Date.now(), horizon = now + 30 * 864e5, out = [];
    tasks.forEach(function (t) {
      if (t.completed || !t.date) return;
      var tm = t.remind;
      if (tm === 'off') return;
      if (!tm) { if (!R.auto) return; tm = R.time; }
      if (!/^\d{1,2}:\d{2}$/.test(tm)) return;
      var hm = tm.split(':').map(Number), ymd = t.date.split('-').map(Number);
      var at = new Date(ymd[0], ymd[1] - 1, ymd[2], hm[0], hm[1], 0, 0).getTime();
      if (!(at > now) || at > horizon) return;
      out.push({ key: 'reg|' + t.id, id: t.id, name: t.description, at: at, custom: !!t.remind });
    });
    out.sort(function (a, b) { return a.at - b.at; });
    return out.slice(0, 200);
  }
  function syncReminders(force) {
    if (!B) return;
    try {
      var list = buildReminders();
      var sig = JSON.stringify(list.map(function (r) { return [r.key, r.at, r.name]; }));
      if (!force && sig === lastRemSig) return;
      lastRemSig = sig;
      B.syncReminders(JSON.stringify(list.map(function (r) { return { key: r.key, name: r.name, at: r.at }; })));
    } catch (e) { console.error(e); }
  }

  /* ====================================================== alarms UI */
  var DAYS = [[2, 'Mon'], [3, 'Tue'], [4, 'Wed'], [5, 'Thu'], [6, 'Fri'], [7, 'Sat'], [1, 'Sun']];
  var alarms = [];
  var edit = null;      /* alarm being edited */

  function loadAlarms() { try { alarms = JSON.parse(B.alarmsGet()); } catch (e) { alarms = []; } }
  function dayStr(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function nextRing(a) {
    if (a.enabled === false) return 0;
    var now = Date.now(), days = a.days || [];
    for (var i = 0; i < 400; i++) {
      var d = new Date(); d.setDate(d.getDate() + i); d.setHours(a.hour, a.minute, 0, 0);
      if (d.getTime() <= now) continue;
      var ds = dayStr(d);
      if (a.date) { if (ds === a.date) return a.skipDate === ds ? 0 : d.getTime(); if (ds > a.date) return 0; continue; }
      if (days.length && days.indexOf(d.getDay() + 1) < 0) continue;
      if (a.skipDate === ds) continue;
      return d.getTime();
    }
    return 0;
  }
  function relTime(ms) {
    var m = Math.round((ms - Date.now()) / 60000);
    if (m < 1) return 'less than a minute';
    var d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), mi = m % 60;
    return (d ? d + 'd ' : '') + (h ? h + 'h ' : '') + (mi ? mi + 'm' : '').trim();
  }
  function repeatText(a) {
    var d = a.days || [];
    if (a.date) return a.date;
    if (!d.length) return 'Once';
    if (d.length === 7) return 'Every day';
    var s = d.slice().sort().join(',');
    if (s === '2,3,4,5,6') return 'Weekdays';
    if (s === '1,7') return 'Weekends';
    return DAYS.filter(function (x) { return d.indexOf(x[0]) >= 0; }).map(function (x) { return x[1]; }).join(' ');
  }

  function renderAlarms() {
    loadAlarms();
    var box = $('#am-list');
    if (!alarms.length) {
      box.innerHTML = '<div class="am-empty"><b>⏰</b>No alarms yet.<br>Tap “New alarm” to create one with your own ringtone.</div>';
      return;
    }
    alarms.sort(function (a, b) { return a.hour * 60 + a.minute - (b.hour * 60 + b.minute); });
    box.innerHTML = alarms.map(function (a) {
      var nx = nextRing(a), on = a.enabled !== false;
      var snd = a.sound && a.sound.title ? a.sound.title : 'Default';
      return '<div class="am-card ' + (on ? '' : 'off') + '">' +
        '<div class="am-main" onclick="amEdit(\'' + a.id + '\')">' +
        '<div class="am-time">' + pad(a.hour) + ':' + pad(a.minute) + '</div>' +
        '<div class="am-label">' + esc(a.label || 'Alarm') + '</div>' +
        '<div class="am-meta"><span>🔁 ' + esc(repeatText(a)) + '</span><span>🎵 ' + esc(snd) + '</span>' +
        (a.vibrate !== false ? '<span>📳</span>' : '') + (a.snoozeOn !== false ? '<span>💤 ' + a.snoozeMin + 'm</span>' : '') +
        (a.math ? '<span>🧮 math</span>' : '') + (a.skipDate ? '<span>⏭ skipping ' + esc(a.skipDate) + '</span>' : '') + '</div>' +
        (on && nx ? '<div class="am-next">Rings in ' + relTime(nx) + '</div>' : '') + '</div>' +
        '<div class="am-side"><label class="sw"><input type="checkbox" ' + (on ? 'checked' : '') + ' onchange="amToggle(\'' + a.id + '\',this.checked)"><span class="knob"></span></label>' +
        ((a.days && a.days.length && on) ? '<button class="am-mini" onclick="amSkip(\'' + a.id + '\')">' + (a.skipDate ? 'Undo skip' : 'Skip next') + '</button>' : '') +
        '</div></div>';
    }).join('');
  }

  function newAlarm() {
    var d = cfg().alarmDef, now = new Date();
    var m = (now.getMinutes() + 1) % 60, h = now.getHours() + (now.getMinutes() + 1 >= 60 ? 1 : 0);
    return { id: '', hour: h % 24, minute: m, label: '', days: [], date: '', enabled: true, vibrate: d.vibrate, volume: d.volume, gradual: d.gradual,
      snoozeOn: d.snoozeOn, snoozeMin: d.snoozeMin, snoozeMax: d.snoozeMax, autoStop: d.autoStop, math: false,
      sound: Object.assign({}, d.sound), skipDate: '' };
  }
  function opt(vals, cur, fmt) { return vals.map(function (v) { return '<option value="' + v + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + (fmt ? fmt(v) : v) + '</option>'; }).join(''); }
  function sw(id, checked) { return '<label class="sw"><input type="checkbox" id="' + id + '" ' + (checked ? 'checked' : '') + '><span class="knob"></span></label>'; }

  function renderEditor() {
    var a = edit;
    var chips = DAYS.map(function (x) { return '<button type="button" class="am-chip ' + (a.days.indexOf(x[0]) >= 0 ? 'on' : '') + '" data-d="' + x[0] + '">' + x[1] + '</button>'; }).join('');
    $('#am-editor').innerHTML =
      '<input type="time" id="ae-time" class="am-bigtime" value="' + pad(a.hour) + ':' + pad(a.minute) + '">' +
      '<input type="text" id="ae-label" placeholder="Label (e.g. Wake up, Study session)" value="' + esc(a.label) + '">' +
      '<div class="am-sec"><h4>Repeat</h4><div class="am-days">' +
      '<button type="button" class="am-chip" data-p="once">Once</button><button type="button" class="am-chip" data-p="daily">Daily</button>' +
      '<button type="button" class="am-chip" data-p="weekdays">Weekdays</button><button type="button" class="am-chip" data-p="weekends">Weekends</button></div>' +
      '<div class="am-days" id="ae-days">' + chips + '</div>' +
      '<div class="am-row"><div class="am-rl"><b>Specific date</b><small>Only for one-time alarms (leave empty for “next time”)</small></div><input type="date" id="ae-date" value="' + esc(a.date) + '"></div></div>' +
      '<div class="am-sec"><h4>Ringtone</h4><div class="am-snd"><div class="name" id="ae-snd">🎵 ' + esc(a.sound.title || 'Default') + '</div>' +
      '<button type="button" class="am-mini" id="ae-snd-def">Default</button><button type="button" class="am-mini" id="ae-snd-sys">Ringtones…</button>' +
      '<button type="button" class="am-mini" id="ae-snd-file">My audio file…</button><button type="button" class="am-mini" id="ae-snd-play">▶ Preview</button></div>' +
      '<div class="am-row"><div class="am-rl"><b>Volume</b></div><input type="range" id="ae-vol" min="10" max="100" value="' + a.volume + '" style="width:55%"></div>' +
      '<div class="am-row"><div class="am-rl"><b>Gradually increase volume</b><small>Starts quiet, reaches full volume in ~25 s</small></div>' + sw('ae-grad', a.gradual) + '</div>' +
      '<div class="am-row"><div class="am-rl"><b>Vibrate</b></div>' + sw('ae-vib', a.vibrate) + '</div></div>' +
      '<div class="am-sec"><h4>Snooze & dismiss</h4>' +
      '<div class="am-row"><div class="am-rl"><b>Allow snooze</b></div>' + sw('ae-snz', a.snoozeOn) + '</div>' +
      '<div class="am-row"><div class="am-rl"><b>Snooze length</b></div><select id="ae-snzmin">' + opt([1, 3, 5, 10, 15, 20, 30], a.snoozeMin, function (v) { return v + ' min'; }) + '</select></div>' +
      '<div class="am-row"><div class="am-rl"><b>Max snoozes</b></div><select id="ae-snzmax">' + opt([1, 2, 3, 5, 0], a.snoozeMax, function (v) { return v === 0 ? 'Unlimited' : v; }) + '</select></div>' +
      '<div class="am-row"><div class="am-rl"><b>Stop ringing after</b></div><select id="ae-auto">' + opt([1, 2, 5, 10, 15, 30], a.autoStop, function (v) { return v + ' min'; }) + '</select></div>' +
      '<div class="am-row"><div class="am-rl"><b>Solve a math problem to dismiss</b><small>Helps you wake up properly</small></div>' + sw('ae-math', a.math) + '</div></div>' +
      '<div class="am-foot"><button type="button" onclick="amSave()">💾 Save alarm</button>' +
      '<button type="button" style="background:#0ea5e9" onclick="amTest()">🔔 Test</button>' +
      (a.id ? '<button type="button" style="background:var(--priority-high)" onclick="amDelete()">🗑 Delete</button>' : '') +
      '<button type="button" style="background:gray" onclick="amBack()">Cancel</button></div>';

    var ed = $('#am-editor');
    $$('#ae-days .am-chip', ed).forEach(function (c) {
      c.onclick = function () {
        var d = +c.dataset.d, i = a.days.indexOf(d);
        if (i >= 0) a.days.splice(i, 1); else a.days.push(d);
        a.date = ''; $('#ae-date').value = '';
        c.classList.toggle('on');
      };
    });
    $$('[data-p]', ed).forEach(function (c) {
      c.onclick = function () {
        var p = c.dataset.p;
        a.days = p === 'daily' ? [1, 2, 3, 4, 5, 6, 7] : p === 'weekdays' ? [2, 3, 4, 5, 6] : p === 'weekends' ? [1, 7] : [];
        $$('#ae-days .am-chip', ed).forEach(function (x) { x.classList.toggle('on', a.days.indexOf(+x.dataset.d) >= 0); });
      };
    });
    $('#ae-date').onchange = function () { if (this.value) { a.days = []; $$('#ae-days .am-chip', ed).forEach(function (x) { x.classList.remove('on'); }); } };
    $('#ae-snd-def').onclick = function () { a.sound = { type: 'default', uri: '', title: 'Default alarm sound' }; $('#ae-snd').innerText = '🎵 ' + a.sound.title; };
    $('#ae-snd-sys').onclick = function () { B.pickRingtone('alarm-editor', a.sound.uri || ''); };
    $('#ae-snd-file').onclick = function () { B.pickAudioFile('alarm-editor'); };
    $('#ae-snd-play').onclick = function () { B.previewSound(a.sound.type, a.sound.uri || ''); };
  }

  function readEditor() {
    var a = edit, t = ($('#ae-time').value || '07:00').split(':');
    a.hour = +t[0]; a.minute = +t[1];
    a.label = $('#ae-label').value.trim();
    a.date = $('#ae-date').value || '';
    a.volume = +$('#ae-vol').value;
    a.gradual = $('#ae-grad').checked; a.vibrate = $('#ae-vib').checked;
    a.snoozeOn = $('#ae-snz').checked; a.snoozeMin = +$('#ae-snzmin').value; a.snoozeMax = +$('#ae-snzmax').value;
    a.autoStop = +$('#ae-auto').value; a.math = $('#ae-math').checked;
    a.enabled = true; a.skipDate = '';
    return a;
  }

  window.amNew = function () { edit = newAlarm(); showPane('editor'); renderEditor(); };
  window.amEdit = function (id) {
    var a = alarms.filter(function (x) { return x.id === id; })[0];
    if (!a) return;
    edit = JSON.parse(JSON.stringify(a)); edit.days = edit.days || []; edit.sound = edit.sound || { type: 'default', uri: '', title: 'Default' };
    showPane('editor'); renderEditor();
  };
  window.amSave = function () {
    var a = readEditor();
    try { alarms = JSON.parse(B.alarmSave(JSON.stringify(a))); } catch (e) { toast('Could not save alarm'); return; }
    var nx = nextRing(a);
    toast(nx ? 'Alarm set for ' + relTime(nx) + ' from now' : 'Alarm saved');
    window.amBack();
  };
  window.amDelete = function () { if (!edit || !edit.id) return; if (!confirm('Delete this alarm?')) return; B.alarmDelete(edit.id); window.amBack(); };
  window.amTest = function () { B.alarmTest(JSON.stringify(readEditor())); };
  window.amBack = function () { showPane('alarms'); renderAlarms(); };
  window.amToggle = function (id, on) { B.alarmToggle(id, on); renderAlarms(); };
  window.amSkip = function (id) { B.alarmSkipNext(id); renderAlarms(); };

  /* result of the ringtone / file pickers */
  window.__nativeRingtonePicked = function (target, snd) {
    if (target === 'alarm-editor' && edit) { edit.sound = snd; var n = $('#ae-snd'); if (n) n.innerText = '🎵 ' + snd.title; }
    else if (target === 'reminder') { cfg().remind.sound = snd; saveCfg(); renderSettings(); }
    else if (target === 'alarm-default') { cfg().alarmDef.sound = snd; saveCfg(); renderSettings(); }
  };

  /* ====================================================== reminders tab */
  function renderReminders() {
    var list = buildReminders(), R = cfg().remind, today = getLocalToday();
    var todayN = list.filter(function (r) { return dayStr(new Date(r.at)) === today; }).length;
    var customN = list.filter(function (r) { return r.custom; }).length;
    var html = '<div class="rm-stats"><div class="rm-stat"><b>' + list.length + '</b><span>upcoming (30 days)</span></div>' +
      '<div class="rm-stat"><b>' + todayN + '</b><span>today</span></div><div class="rm-stat"><b>' + customN + '</b><span>with custom time</span></div></div>';
    html += '<div class="am-note">Every task gets a reminder automatically at <b>' + esc(R.time) + '</b> on its date' + (R.auto ? '' : ' (auto-reminders are OFF)') +
      '. Set your own time with the tag <code>[remind: 18:30]</code> in Plan-by-AI / TXT import, or turn one off with <code>[remind: off]</code>. ' +
      'No reminder fires while you are already focusing on that same task.</div>';
    if (!list.length) html += '<div class="am-empty"><b>✅</b>No upcoming reminders.</div>';
    html += list.slice(0, 60).map(function (r) {
      var d = new Date(r.at), isToday = dayStr(d) === today;
      var tm = new Date(); tm.setDate(tm.getDate() + 1);
      var when = (isToday ? 'Today' : dayStr(d) === dayStr(tm) ? 'Tomorrow' : d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' })) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
      return '<div class="rm-item" onclick="amOpenTask(\'' + r.id + '\')"><div class="when">' + when + '</div><div class="nm">' + esc(r.name) + '</div><div class="in">' + (r.custom ? '⏰ custom' : 'auto') + ' · in ' + relTime(r.at) + '</div></div>';
    }).join('');
    $('#am-tab-reminders').innerHTML = html;
  }
  window.amOpenTask = function (id) { closeModal('modal-alarms'); try { editTask(id); } catch (e) {} };

  /* ====================================================== settings tab */
  function row(title, sub, control) { return '<div class="am-row"><div class="am-rl"><b>' + title + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</div>' + control + '</div>'; }
  function bsw(path, v) { return '<label class="sw"><input type="checkbox" data-k="' + path + '" ' + (v ? 'checked' : '') + '><span class="knob"></span></label>'; }
  function bsel(path, vals, cur, labels) {
    return '<select data-k="' + path + '">' + vals.map(function (v, i) { return '<option value="' + v + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + labels[i] + '</option>'; }).join('') + '</select>';
  }
  function sndBlock(target, snd, withFile) {
    return '<div class="am-snd"><div class="name">🎵 ' + esc(snd.title || 'Default') + '</div>' +
      '<button class="am-mini" data-snd="' + target + ':def">Default</button><button class="am-mini" data-snd="' + target + ':sys">Ringtones…</button>' +
      (withFile ? '<button class="am-mini" data-snd="' + target + ':file">My audio file…</button>' : '') +
      '<button class="am-mini" data-snd="' + target + ':play">▶ Preview</button></div>';
  }

  function renderSettings() {
    var R = cfg().remind, D = cfg().alarmDef, el = $('#am-tab-settings');
    el.innerHTML =
      '<div class="am-sec"><h4>Task reminders</h4>' +
      row('Task reminders', 'Master switch for all task reminders', bsw('remind.enabled', R.enabled)) +
      row('Auto-remind every task', 'No need to type a date & time: reminds on the task date at the default time. Override per task with <code>[remind: HH:MM]</code>', bsw('remind.auto', R.auto)) +
      row('Default reminder time', '', '<input type="time" data-k="remind.time" value="' + esc(R.time) + '">') +
      row('Reminder style', 'Notification, or a full alarm-style ring', bsel('remind.style', ['notification', 'alarm'], R.style, ['Notification', 'Alarm ring'])) +
      row('Vibrate', '', bsw('remind.vibrate', R.vibrate)) +
      row('Snooze length', '', bsel('remind.snooze', [5, 10, 15, 30], R.snooze, ['5 min', '10 min', '15 min', '30 min'])) +
      '<div class="am-row" style="display:block"><div class="am-rl"><b>Reminder sound</b><small>System ringtones for notifications; your own audio file works with “Alarm ring” style</small></div>' + sndBlock('reminder', R.sound, true) + '</div>' +
      '</div>' +
      '<div class="am-sec"><h4>When I am already focusing</h4>' +
      row('Same task', 'Reminder is skipped automatically (you are already on it)', '<b style="color:var(--priority-low)">Skipped</b>') +
      row('Another task', 'What should a reminder do while you focus on a different task?',
        bsel('remind.otherMode', ['silent', 'notify', 'screen'], R.otherMode, ['Silent notification', 'Normal notification', 'Show on focus screen'])) +
      '<div class="am-note">“Show on focus screen” shows a card with <b>Cancel</b> and <b>Switch</b> buttons while the focus screen is maximized (a normal notification if the app is in the background).</div></div>' +
      '<div class="am-sec"><h4>Alarm defaults</h4>' +
      row('Volume', '', '<input type="range" min="10" max="100" data-k="alarmDef.volume" data-num="1" value="' + D.volume + '" style="width:50%">') +
      row('Gradually increase volume', '', bsw('alarmDef.gradual', D.gradual)) +
      row('Vibrate', '', bsw('alarmDef.vibrate', D.vibrate)) +
      row('Allow snooze', '', bsw('alarmDef.snoozeOn', D.snoozeOn)) +
      row('Snooze length', '', bsel('alarmDef.snoozeMin', [1, 3, 5, 10, 15, 20, 30], D.snoozeMin, ['1 min', '3 min', '5 min', '10 min', '15 min', '20 min', '30 min'])) +
      row('Stop ringing after', '', bsel('alarmDef.autoStop', [1, 2, 5, 10, 15, 30], D.autoStop, ['1 min', '2 min', '5 min', '10 min', '15 min', '30 min'])) +
      '<div class="am-row" style="display:block"><div class="am-rl"><b>Default alarm ringtone</b></div>' + sndBlock('alarm-default', D.sound, true) + '</div></div>' +
      '<div class="am-sec"><h4>Focus screen & floating controller</h4>' +
      row('Auto-show floating controller', 'Appears by itself when you leave the app while a task is being focused (needs "Display over other apps")', bsw('autoFloat', cfg().autoFloat !== false)) +
      row('Rotate to landscape when maximized', 'The focus screen turns sideways when you press Maximize', bsw('rotateMax', cfg().rotateMax !== false)) +
      row('Floating button shows', '', '<select class="float-mode-select" onchange="saveFloatSettings(this.value)"><option value="all_today">Today – all tasks</option><option value="task_today">Today – running task</option><option value="task_total">Task total</option></select>') +
      '</div>' +
      '<div class="am-sec"><h4>Reliability</h4><div class="am-foot" style="margin-top:0">' +
      '<button style="background:#0ea5e9" id="as-test">🔔 Test reminder</button>' +
      '<button style="background:#8b5cf6" id="as-fs">Allow full-screen alarms</button>' +
      '<button style="background:#f59e0b" id="as-bat">Ignore battery limits</button></div>' +
      '<div class="am-note">On some phones, “Ignore battery limits” keeps alarms and reminders exact when the app is closed.</div></div>';
    window.syncFloatSettingsUI();

    $$('[data-k]', el).forEach(function (inp) {
      inp.onchange = inp.oninput = function () {
        var path = inp.dataset.k.split('.'), o = cfg(), v;
        v = inp.type === 'checkbox' ? inp.checked : (inp.dataset.num || (inp.tagName === 'SELECT' && /^\d+$/.test(inp.value))) ? +inp.value : inp.value;
        for (var i = 0; i < path.length - 1; i++) o = o[path[i]];
        o[path[path.length - 1]] = v;
        saveCfg();
      };
    });
    $$('[data-snd]', el).forEach(function (b) {
      b.onclick = function () {
        var p = b.dataset.snd.split(':'), target = p[0], act = p[1];
        var cur = target === 'reminder' ? cfg().remind.sound : cfg().alarmDef.sound;
        if (act === 'def') { var d = { type: 'default', uri: '', title: target === 'reminder' ? 'Default' : 'Default alarm sound' }; window.__nativeRingtonePicked(target, d); }
        else if (act === 'sys') B.pickRingtone(target, cur.uri || '');
        else if (act === 'file') B.pickAudioFile(target);
        else B.previewSound(cur.type, cur.uri || '');
      };
    });
    $('#as-test').onclick = function () { B.testReminder('Test reminder'); };
    $('#as-fs').onclick = function () { B.openFullScreenSettings(); };
    $('#as-bat').onclick = function () { B.requestBatteryExemption(); };
  }

  /* ====================================================== modal shell */
  function showPane(name) {
    ['alarms', 'reminders', 'settings', 'editor'].forEach(function (p) {
      var el = p === 'editor' ? $('#am-editor') : $('#am-tab-' + p);
      if (el) el.classList.toggle('hidden', p !== name);
    });
    $('#am-tabs').classList.toggle('hidden', name === 'editor');
    $$('#am-tabs button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === name); });
    if (name === 'reminders') renderReminders();
    if (name === 'settings') renderSettings();
  }

  window.openAlarms = function () {
    if (!B) return;
    openModal('modal-alarms');
    showPane('alarms');
    renderAlarms();
  };

  function buildModal() {
    if ($('#modal-alarms')) return;
    var m = document.createElement('div');
    m.id = 'modal-alarms';
    m.className = 'modal hidden am-modal';
    m.innerHTML =
      '<div class="am-head"><div><div class="am-title">⏰ Alarms & Reminders</div><div class="am-sub">Alarms and task reminders work even when the app is closed</div></div>' +
      '<button class="am-x" onclick="closeModal(\'modal-alarms\')">✕</button></div>' +
      '<div class="am-tabs" id="am-tabs"><button data-tab="alarms" class="on">Alarms</button><button data-tab="reminders">Reminders</button><button data-tab="settings">Settings</button></div>' +
      '<div class="am-pane" id="am-tab-alarms"><button class="am-add" onclick="amNew()">＋ New alarm</button><div id="am-list"></div></div>' +
      '<div class="am-pane hidden" id="am-tab-reminders"></div><div class="am-pane hidden" id="am-tab-settings"></div>' +
      '<div class="am-pane hidden" id="am-editor"></div>';
    document.body.appendChild(m);
    $$('#am-tabs button').forEach(function (b) { b.onclick = function () { showPane(b.dataset.tab); }; });
  }

  function addHeaderButton() {
    var grp = $('.controls-group');
    if (!grp || $('#btn-alarms')) return;
    var b = document.createElement('button');
    b.id = 'btn-alarms';
    b.className = 'android-only';
    b.style.background = 'linear-gradient(120deg,#f59e0b,#ef4444)';
    b.innerHTML = '⏰ Alarms & Reminders';
    b.onclick = window.openAlarms;
    grp.appendChild(b);
  }

  /* ====================================================== init */
  function init() {
    cfg();
    injectTaskField();
    window.syncFloatSettingsUI();
    refreshFloatButtons();
    if (!B) return;
    buildModal();
    addHeaderButton();
    setupFocusBridge();
    pushRemSettings();
    setTimeout(function () { syncReminders(true); }, 1500);
    setInterval(function () { syncReminders(false); }, 15000);
    document.addEventListener('visibilitychange', function () { if (document.hidden) syncReminders(false); });
    /* command waiting from a notification (e.g. "Start focus") */
    setTimeout(function () {
      try { var k = B.takePendingCommand(); if (k) window.__nativeStartTask(k); } catch (e) {}
    }, 1200);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
