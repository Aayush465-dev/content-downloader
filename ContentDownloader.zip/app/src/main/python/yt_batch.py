#!/usr/bin/env python3
"""
Tube to Drive  -  LOCAL edition
================================
Same web interface as the Colab version, but everything runs on YOUR device:
search, playlists, quality list, downloads, merging, MP3 conversion, queue,
cancel / resume / retry.  Nothing is sent to Colab, Google Drive or any other
server except YouTube itself.

Install once (Termux):
    pkg update && pkg upgrade
    pkg install python ffmpeg
    python -m pip install -U "yt-dlp[default]"
    termux-setup-storage

Install once (Windows / macOS / Linux):
    install Python 3 and ffmpeg, then:  python -m pip install -U "yt-dlp[default]"

Run:
    python yt_batch.py
The page opens by itself; if not, open the address printed in the terminal.

Everything else (save folder, auto-delete, notifications,
reinstalling yt-dlp) is changed from the Settings button on the page.

Options (all optional):
    --out DIR               where finished files go (also editable in Settings)
    --port 8765             port of the local page
    --host 127.0.0.1        use 0.0.0.0 to open the page from another device
    --no-browser            do not open the browser automatically
    --keep-video-hours N    auto-delete finished videos after N hours (0 = never)
    --keep-audio-hours N    auto-delete finished audio after N hours (0 = never)
"""

import argparse
import base64
import importlib
import hashlib
import json
import random
import mimetypes
import os
import re
import shutil
import string
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse as up
import urllib.request as ureq
import signal
import traceback
from collections import deque
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

YTDLP_DIR = os.environ.get("CD_YTDLP_DIR", "")
if YTDLP_DIR and YTDLP_DIR not in sys.path:
    sys.path.insert(0, YTDLP_DIR)

try:
    import yt_dlp
except ImportError:
    yt_dlp = None          # the page can install it from Settings

# ----------------------------------------------------------------------------
# configuration (can be changed with the options above or in Settings)
# ----------------------------------------------------------------------------
HOME = Path.home()
HERE = Path(__file__).resolve().parent
TERMUX_DL = HOME / "storage" / "downloads"
# Same folder as the old script on Termux; ~/Downloads/YouTube everywhere else.
DEFAULT_OUT = Path(os.environ["CD_OUT"]) if os.environ.get("CD_OUT") else (
    TERMUX_DL / "Content Downloader" if TERMUX_DL.exists() else HOME / "Downloads" / "Content Downloader")

CONFIG_DIR = HOME / ".tube_local"          # settings + queue live here, whatever the save folder is
SETTINGS_FILE = CONFIG_DIR / "settings.json"
LEGACY_WORK = CONFIG_DIR / "work"      # where older versions kept temporary files
WORK_DIR = LEGACY_WORK                   # becomes <save folder>/.tube_work (hidden) once settings are applied
JOBS_FILE = CONFIG_DIR / "jobs.json"
DATA_FILE = CONFIG_DIR / "data.json"       # everything in one file: settings, queue, progress of every stream

OUTPUT_DIR = DEFAULT_OUT
KEEP_VIDEO = 0.0          # hours, 0 = keep forever
KEEP_AUDIO = 0.0
SET = {"out": "", "keep_video": 0.0, "keep_audio": 0.0,
       "smart": True, "min_mb": 1.0, "wait_s": 10.0,
       "par_dl": False, "par_n": 2, "dl_merge": True, "par_merge": False, "merge_n": 2,
       "second_kb": 300.0, "extra_kb": 400.0, "merge_pct": 25.0}
SMART = {"go": False, "info": None}     # True = the monitor allows a second video to start (the first one is too slow)
MAINT = {"on": False}     # True while yt-dlp is being reinstalled
YT = {"state": "idle", "log": []}

# running totals used for AVERAGE speeds (ETA only; the screen shows live speed)
STAT = {"dl_b": 0.0, "dl_s": 0.0, "enc_m": 0.0, "enc_s": 0.0}


def avg_bps():
    """average download speed over everything downloaded so far (bytes/second)"""
    if STAT["dl_s"] > 3 and STAT["dl_b"] > 2e5:
        return max(2e5, STAT["dl_b"] / STAT["dl_s"])
    return 8e6


def enc_rate():
    """average H.264 re-encode speed: seconds of video per second of work"""
    if STAT["enc_s"] > 3:
        return max(0.2, STAT["enc_m"] / STAT["enc_s"])
    return 2.8


LIVE = ("downloading", "merging", "uploading", "cancelling")
END = ("done", "error", "cancelled", "expired", "deleted")
CLEARABLE = ("done", "cancelled", "expired", "deleted")

JOBS = {}
CV = threading.Condition(threading.RLock())     # protects JOBS
NEXT_Q = [1]
PERSIST_LOCK = threading.Lock()


class Either:
    """acts like one Event that is set when any of the given events is set"""

    def __init__(self, *ev):
        self.ev = ev

    def is_set(self):
        return any(e.is_set() for e in self.ev)


def _up(j):
    e = j.get("_upause")
    return bool(e and e.is_set())


class JobCancelled(Exception):
    pass


class PauseAbort(Exception):
    """raised inside yt-dlp's progress hook to stop a transfer on purpose while the video is paused"""


class ApiError(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.code = code


# ----------------------------------------------------------------------------
# settings
# ----------------------------------------------------------------------------
def read_data():
    """data.json (or its backup copy); the older settings.json + jobs.json are still read once so nothing is lost"""
    for f in (DATA_FILE, DATA_FILE.with_suffix(".bak")):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            if isinstance(d, dict):
                return d
        except Exception:
            pass
    d = {"settings": {}, "jobs": []}
    try:
        d["settings"] = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        d["jobs"] = json.loads(JOBS_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return d


def load_history():
    h = read_data().get("history")
    if isinstance(h, list):
        HISTORY[:] = [str(x)[:120] for x in h if x][:60]


def load_settings():
    d = read_data().get("settings")
    if not isinstance(d, dict) or not d:
        return
    if isinstance(d.get("out"), str):
        SET["out"] = d["out"]
    for k in ("keep_video", "keep_audio"):
        try:
            SET[k] = max(0.0, float(d.get(k) or 0))
        except (TypeError, ValueError):
            pass
    SET["smart"] = bool(d.get("smart", True))
    for k in ("par_dl", "dl_merge", "par_merge"):
        if k in d:
            SET[k] = bool(d[k])
    for k in ("par_n", "merge_n"):
        try:
            SET[k] = min(8, max(1, int(d.get(k) if d.get(k) is not None else SET[k])))
        except (TypeError, ValueError):
            pass
    for k in ("second_kb", "extra_kb"):
        try:
            SET[k] = max(1.0, float(d.get(k) if d.get(k) is not None else SET[k]))    # old "0 = pause" becomes 1 KB/s
        except (TypeError, ValueError):
            pass
    try:
        SET["merge_pct"] = min(100.0, max(5.0, float(d.get("merge_pct") if d.get("merge_pct") is not None else SET["merge_pct"])))
    except (TypeError, ValueError):
        pass
    for k, lo in (("min_mb", 0.0), ("wait_s", 1.0)):
        try:
            SET[k] = max(lo, float(d.get(k) if d.get(k) is not None else SET[k]))
        except (TypeError, ValueError):
            pass


def save_settings():
    persist()


def apply_settings():
    global OUTPUT_DIR, KEEP_VIDEO, KEEP_AUDIO
    OUTPUT_DIR = Path(os.path.abspath(os.path.expanduser(SET["out"]))) if SET["out"] else DEFAULT_OUT
    KEEP_VIDEO, KEEP_AUDIO = SET["keep_video"], SET["keep_audio"]
    global WORK_DIR
    WORK_DIR = OUTPUT_DIR / ".tube_work"


def ensure_work():
    """temporary download folder: a hidden folder inside the default save folder"""
    global WORK_DIR
    try:
        WORK_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        WORK_DIR = LEGACY_WORK            # save folder not writable: fall back to the old place
        WORK_DIR.mkdir(parents=True, exist_ok=True)
        return
    if os.name == "nt":
        try:
            subprocess.run(["attrib", "+h", str(WORK_DIR)], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, check=False)
        except Exception:
            pass


def job_work(j):
    """temporary folder of one job (the folder it started in, so resuming after a restart still finds it)"""
    return Path(j["work"]) if j.get("work") else LEGACY_WORK / j["id"]


# ----------------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------------
ANSI = re.compile(r"\x1b\[[0-9;]*m")


def clean_err(exc):
    s = ANSI.sub("", str(exc)).strip()
    s = re.sub(r"^(ERROR:\s*)+", "", s)
    s = re.sub(r"^\[youtube\]\s*[\w-]+:\s*", "", s)
    return s[:400] or exc.__class__.__name__


def trunc_bytes(s, n):
    b = s.encode("utf-8")[:n]
    return b.decode("utf-8", "ignore")


def safe_name(s, n=120):
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]', " ", s or "")
    s = re.sub(r"\s+", " ", s).strip(" .")
    return trunc_bytes(s, n).rstrip(" .") or "video"


def unique_path(p):
    p = Path(p)
    if not p.exists():
        return p
    for i in range(2, 10000):
        q = p.with_name(f"{p.stem} ({i}){p.suffix}")
        if not q.exists():
            return q
    return p


def free_bytes():
    try:
        return shutil.disk_usage(OUTPUT_DIR).free
    except Exception:
        return None


FF = {"ok": None, "msg": "", "t": 0.0}


def ffmpeg_check(force=False):
    """really starts ffmpeg once (cached 20 s) so Settings can show why it does not work"""
    if not force and FF["ok"] is not None and time.time() - FF["t"] < 20:
        return FF["ok"]
    exe = shutil.which("ffmpeg")
    if not exe:
        FF.update(ok=False, msg="ffmpeg file not found")
    else:
        try:
            r = subprocess.run([exe, "-version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, errors="replace", timeout=20)
            first = (r.stdout or "").strip().splitlines()[:2]
            if r.returncode == 0:
                FF.update(ok=True, msg=" ".join(first)[:80])
            else:
                FF.update(ok=False, msg=("exit %s: " % r.returncode + " | ".join(first))[:300])
        except Exception as e:
            FF.update(ok=False, msg="%s: %s" % (type(e).__name__, e))
    if not FF["ok"]:
        try:
            dg = open(os.environ.get("CD_FFDIAG", ""), encoding="utf-8").read().strip()
            if dg:
                FF["msg"] = (FF["msg"] + " || " + dg)[:900]
        except Exception:
            pass
    FF["t"] = time.time()
    return FF["ok"]


def have_ffmpeg():
    return ffmpeg_check()


def thumb_of(vid):
    return f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"


VID_OK = re.compile(r"[\w-]{11}|x~[\w-]{4,1800}")


def is_ext(vid):
    """True for a video of any other site (its link is packed into the id)"""
    return str(vid).startswith("x~")


def ext_id(url):
    return "x~" + base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")


def vid_url(vid):
    if is_ext(vid):
        t = vid[2:]
        t += "=" * (-len(t) % 4)
        return base64.urlsafe_b64decode(t.encode("ascii")).decode("utf-8")
    return "https://www.youtube.com/watch?v=" + vid


def ytdlp_version():
    try:
        return yt_dlp.version.__version__ if yt_dlp else ""
    except Exception:
        return ""


def need_ytdlp():
    if MAINT["on"]:
        raise RuntimeError("yt-dlp is being reinstalled. Please wait a minute.")
    if yt_dlp is None:
        raise RuntimeError("yt-dlp is not installed yet. It installs automatically, please wait a minute or restart the app.")


def check_dir(s):
    """folder path -> Path that exists and can be written to (created if needed)"""
    s = (s or "").strip()
    if not s:
        raise ApiError("The folder path is empty")
    p = Path(os.path.abspath(os.path.expanduser(s)))
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ApiError("Cannot create that folder: " + str(e)[:200])
    try:
        fd, tmp = tempfile.mkstemp(dir=str(p), prefix=".w")
        os.close(fd)
        os.remove(tmp)
    except OSError:
        raise ApiError("That folder is not writable: " + str(p))
    return p


def resolve_dest(base, sub):
    if base:
        p = check_dir(base)
    else:
        try:
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise ApiError("Cannot create the save folder: " + str(e)[:200])
        p = OUTPUT_DIR
    if sub:
        p = check_dir(str(p / safe_name(sub, 100)))
    return p


# ----------------------------------------------------------------------------
# yt-dlp wrapper
# ----------------------------------------------------------------------------
class Y:
    """One YoutubeDL per call."""

    def __init__(self, extra=None, country=""):
        need_ytdlp()
        self.tmp = None
        o = {
            "quiet": True,
            "no_warnings": True,
            "noprogress": True,
            "socket_timeout": 25,
            "retries": 5,
        }
        if country:
            o["geo_bypass_country"] = country
        if extra:
            o.update(extra)
        try:
            self.ydl = yt_dlp.YoutubeDL(o)
        except BaseException:
            self._rm()
            raise

    def _rm(self):
        if self.tmp:
            try:
                os.remove(self.tmp)
            except OSError:
                pass

    def __enter__(self):
        return self.ydl.__enter__()

    def __exit__(self, *a):
        try:
            self.ydl.__exit__(*a)
        finally:
            self._rm()
        return False


# ----------------------------------------------------------------------------
# reinstall yt-dlp from the page
# ----------------------------------------------------------------------------
def _say(s):
    YT["log"].append(s)
    del YT["log"][:-200]


def run_pip(args):
    cmd = [sys.executable, "-m", "pip"] + args + ["--disable-pip-version-check"]

    def once(extra):
        p = subprocess.Popen(cmd + extra, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors="replace")
        out = []
        for line in p.stdout:
            line = line.rstrip()
            if line:
                out.append(line)
                _say(line[:300])
        return p.wait(), "\n".join(out)

    rc, txt = once([])
    if rc != 0 and "externally-managed" in txt.lower():
        _say("Retrying with --break-system-packages ...")
        rc, txt = once(["--break-system-packages"])
    return rc


INSTALL_PROGRESS = {"stage": "", "done": 0, "total": 0}


def ytdlp_latest_info():
    req = ureq.Request("https://pypi.org/pypi/yt-dlp/json", headers={"User-Agent": "ContentDownloader"})
    with ureq.urlopen(req, timeout=30) as r:
        j = json.loads(r.read().decode("utf-8"))
    for f in j.get("urls", []):
        if f.get("packagetype") == "bdist_wheel" and str(f.get("url", "")).endswith(".whl"):
            return {"version": j["info"]["version"], "size": int(f.get("size") or 0), "url": f["url"]}
    raise RuntimeError("Could not find the yt-dlp download on PyPI.")


def install_wheel(info=None):
    """download the newest yt-dlp wheel and unpack it into YTDLP_DIR (replaces the old one)"""
    import zipfile
    if not YTDLP_DIR:
        raise RuntimeError("No install folder for yt-dlp.")
    info = info or ytdlp_latest_info()
    INSTALL_PROGRESS.update(stage="Downloading yt-dlp " + info["version"], done=0, total=info["size"])
    tmp = Path(YTDLP_DIR + ".tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    whl = tmp / "yt_dlp.whl"
    req = ureq.Request(info["url"], headers={"User-Agent": "ContentDownloader"})
    with ureq.urlopen(req, timeout=60) as r, open(whl, "wb") as f:
        while True:
            b = r.read(65536)
            if not b:
                break
            f.write(b)
            INSTALL_PROGRESS["done"] += len(b)
    INSTALL_PROGRESS["stage"] = "Unpacking yt-dlp"
    ex = tmp / "pkg"
    with zipfile.ZipFile(whl) as z:
        z.extractall(ex)
    shutil.rmtree(YTDLP_DIR, ignore_errors=True)
    os.replace(ex, YTDLP_DIR)
    shutil.rmtree(tmp, ignore_errors=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    (CONFIG_DIR / "ytdlp_last.txt").write_text(str(time.time()))
    INSTALL_PROGRESS["stage"] = "done"


def auto_update_loop():
    """reinstall yt-dlp every 4 days (also if it is missing)"""
    while True:
        time.sleep(60)
        try:
            last = float((CONFIG_DIR / "ytdlp_last.txt").read_text())
        except Exception:
            last = 0.0
        if yt_dlp is None or time.time() - last >= 4 * 86400:
            try:
                start_reinstall()
                time.sleep(1800)       # after an attempt, wait before trying again
            except Exception:
                pass                   # a download is running: try again in a minute


def _reinstall():
    global yt_dlp
    try:
        _say("Stopping yt-dlp ...")
        yt_dlp = None
        for m in [m for m in list(sys.modules)
                  if m in ("yt_dlp", "yt_dlp_plugins") or m.startswith(("yt_dlp.", "yt_dlp_plugins."))]:
            sys.modules.pop(m, None)
        _say("Installing the newest yt-dlp ...")
        install_wheel()
        importlib.invalidate_caches()
        import yt_dlp                      # binds the module-level name (declared global above)
        with FORMATS_LOCK:
            FORMATS.clear()
        with LISTS_LOCK:
            LISTS.clear()
        _say(f"Done. yt-dlp {ytdlp_version()} is ready.")
        YT["state"] = "ok"
    except Exception as e:
        _say("ERROR: " + clean_err(e))
        YT["state"] = "error"
        if yt_dlp is None:
            try:
                importlib.invalidate_caches()
                import yt_dlp
            except Exception:
                pass
    finally:
        with CV:
            MAINT["on"] = False
            CV.notify_all()


def start_reinstall():
    with CV:
        if YT["state"] == "running":
            raise ApiError("Already running")
        if any(j["stage"] in LIVE for j in JOBS.values()):
            raise ApiError("Wait for the running download to finish, or cancel it, then try again.")
        MAINT["on"] = True
        YT["state"] = "running"
        YT["log"] = []
    threading.Thread(target=_reinstall, daemon=True).start()
    return {"ok": True}


def ytdlp_status():
    return {"state": YT["state"], "log": YT["log"][-80:], "version": ytdlp_version(),
            "installed": yt_dlp is not None}


# ----------------------------------------------------------------------------
# folder browser (works like a small file manager)
# ----------------------------------------------------------------------------
def browse_roots():
    seen, out = set(), []

    def add(name, p):
        p = Path(p)
        try:
            ok = p.is_dir()
        except OSError:
            ok = False
        k = str(p)
        if ok and k not in seen:
            seen.add(k)
            out.append({"name": name, "path": k})
            return True
        return False

    add("Default folder", OUTPUT_DIR)
    add("Downloads", TERMUX_DL)
    add("Internal storage", "/storage/emulated/0") or add("Internal storage", "/sdcard")
    add("Home", HOME)
    if os.name == "nt":
        for L in string.ascii_uppercase:
            add(L + ":", L + ":\\")
    else:
        add("Root", "/")
    return out


def api_browse(qs):
    want_files = qs.get("files") == "1"
    ext = (qs.get("ext") or "").lower()
    p = (qs.get("path") or "").strip()
    path = Path(os.path.abspath(os.path.expanduser(p))) if p else OUTPUT_DIR
    try:
        while not path.is_dir() and path != path.parent:
            path = path.parent
        if not path.is_dir():
            path = HOME
    except OSError:
        path = HOME
    dirs, files, err = [], [], ""
    try:
        with os.scandir(path) as it:
            for e in it:
                if e.name.startswith("."):
                    continue
                try:
                    if e.is_dir():
                        dirs.append({"name": e.name, "path": str(Path(path) / e.name)})
                    elif want_files and e.is_file() and (not ext or e.name.lower().endswith(ext)):
                        files.append({"name": e.name, "path": str(Path(path) / e.name)})
                except OSError:
                    continue
    except OSError as ex:
        err = "Cannot open this folder: " + str(ex)[:150]
    dirs.sort(key=lambda x: x["name"].lower())
    files.sort(key=lambda x: x["name"].lower())
    return {
        "path": str(path),
        "parent": str(path.parent) if path.parent != path else "",
        "dirs": dirs[:3000],
        "files": files[:3000],
        "roots": browse_roots(),
        "writable": os.access(path, os.W_OK),
        "error": err,
    }


def api_mkdir(b):
    base = Path(os.path.abspath(os.path.expanduser(str(b.get("path") or ""))))
    if not base.is_dir():
        raise ApiError("The parent folder does not exist")
    name = str(b.get("name") or "").strip()
    if not name:
        raise ApiError("Type a folder name")
    p = base / safe_name(name, 100)
    try:
        p.mkdir(exist_ok=True)
    except OSError as e:
        raise ApiError("Cannot create the folder: " + str(e)[:200])
    return {"path": str(p)}


def api_settings_get():
    return {
        "out": str(OUTPUT_DIR), "out_default": str(DEFAULT_OUT), "out_custom": bool(SET["out"]),
        "keep_video": KEEP_VIDEO, "keep_audio": KEEP_AUDIO,
        "smart": bool(SET["smart"]), "min_mb": SET["min_mb"], "wait_s": SET["wait_s"],
        "par_dl": bool(SET["par_dl"]), "par_n": SET["par_n"], "dl_merge": bool(SET["dl_merge"]),
        "par_merge": bool(SET["par_merge"]), "merge_n": SET["merge_n"],
        "second_kb": SET["second_kb"], "extra_kb": SET["extra_kb"], "merge_pct": SET["merge_pct"],
        "ffmpeg": have_ffmpeg(), "ffmpeg_msg": FF["msg"], "yt": ytdlp_status(),
    }


def api_settings_set(b):
    new = dict(SET)
    if "out" in b:
        o = str(b["out"] or "").strip()
        new["out"] = "" if (not o or Path(os.path.abspath(os.path.expanduser(o))) == DEFAULT_OUT) \
            else str(check_dir(o))
        if not new["out"]:
            check_dir(str(DEFAULT_OUT))
    for k in ("keep_video", "keep_audio"):
        if k in b:
            try:
                new[k] = max(0.0, float(b[k] or 0))
            except (TypeError, ValueError):
                raise ApiError("Hours must be a number")
    if "smart" in b:
        new["smart"] = bool(b["smart"])
    for k in ("par_dl", "dl_merge", "par_merge"):
        if k in b:
            new[k] = bool(b[k])
    for k, lo, nm in (("second_kb", 1.0, "Second video speed"), ("extra_kb", 1.0, "Extra videos speed")):
        if k in b:
            try:
                new[k] = max(lo, float(b[k]))
            except (TypeError, ValueError):
                raise ApiError(nm + " must be a number")
    if "merge_pct" in b:
        try:
            new["merge_pct"] = min(100.0, max(5.0, float(b["merge_pct"])))
        except (TypeError, ValueError):
            raise ApiError("Merge speed must be a number")
    for k, nm in (("par_n", "Number of parallel downloads"), ("merge_n", "Number of parallel merges")):
        if k in b:
            try:
                new[k] = min(8, max(1, int(float(b[k]))))
            except (TypeError, ValueError):
                raise ApiError(nm + " must be a number")
    for k, lo, nm in (("min_mb", 0.0, "Minimum speed"), ("wait_s", 1.0, "Wait seconds")):
        if k in b:
            try:
                new[k] = max(lo, float(b[k]))
            except (TypeError, ValueError):
                raise ApiError(nm + " must be a number")
    SET.update(new)
    apply_settings()
    ensure_work()
    save_settings()
    return api_settings_get()


# ----------------------------------------------------------------------------
# search / playlists
# ----------------------------------------------------------------------------
DATE_CODE = {"hour": 1, "today": 2, "week": 3, "month": 4, "year": 5}
TYPE_CODE = {"video": 1, "channel": 2, "playlist": 3}
DUR_CODE = {"short": 1, "long": 2, "medium": 3}


def search_url(q, typ, date, dur):
    """YouTube results page with the same filters as the website."""
    f = b""
    if date in DATE_CODE:
        f += bytes([0x08, DATE_CODE[date]])
    if typ in TYPE_CODE:
        f += bytes([0x10, TYPE_CODE[typ]])
    if dur in DUR_CODE:
        f += bytes([0x18, DUR_CODE[dur]])
    url = "https://www.youtube.com/results?search_query=" + up.quote_plus(q)
    if f:
        sp = base64.b64encode(bytes([0x12, len(f)]) + f).decode()
        url += "&sp=" + up.quote(sp, safe="")
    return url


PL_PREFIX = ("PL", "OL", "RD", "UU", "FL", "LL")


def parse_entry(e, allow_playlist):
    """flat yt-dlp entry -> card for the page (or None)"""
    if not e:
        return None
    eid = str(e.get("id") or "")
    title = e.get("title") or ""
    url = e.get("url") or e.get("webpage_url") or ""
    if len(eid) == 11 and re.fullmatch(r"[\w-]{11}", eid):
        if title in ("[Private video]", "[Deleted video]"):
            return None
        card = {
            "type": "video",
            "id": eid,
            "title": title or "Video " + eid,
            "thumb": thumb_of(eid),
            "duration": e.get("duration"),
            "channel": e.get("channel") or e.get("uploader") or "",
        }
        if str(e.get("channel_id") or "").startswith("UC"):
            card["chid"] = str(e["channel_id"])
        return card
    if allow_playlist and len(eid) > 11 and not eid.startswith("UC") and (
            eid.startswith(PL_PREFIX) or "/playlist?list=" in url):
        th = ""
        tl = e.get("thumbnails") or []
        if tl:
            th = tl[-1].get("url") or ""
        return {
            "type": "playlist",
            "id": eid,
            "title": title or "Playlist",
            "thumb": th,
            "channel": e.get("channel") or e.get("uploader") or "",
            "count": e.get("playlist_count") or e.get("n_entries"),
        }
    return None


LISTS = {}
LISTS_LOCK = threading.Lock()


def get_list(key, url, need, country, allow_playlist):
    """Flat list of cards for a search or playlist. need=None -> everything.
    Results are cached for 10 minutes so 'Load more' is instant."""
    ck = (key, country)
    with LISTS_LOCK:
        ent = LISTS.get(ck)
    if ent and time.time() - ent["t"] < 600 and (
        ent["done"] or (need is not None and len(ent["items"]) >= need)
    ):
        return ent
    n = None if need is None else max(need + 12, 36)
    while True:
        extra = {"extract_flat": "in_playlist", "skip_download": True}
        if n:
            extra["playlistend"] = n
        try:
            with Y(extra, country) as ydl:
                info = ydl.extract_info(url, download=False)
        except Exception as exc:
            raise ApiError(clean_err(exc))
        info = info or {}
        raw = [e for e in (info.get("entries") or []) if e]
        seen, items = set(), []
        for e in raw:
            c = parse_entry(e, allow_playlist)
            if c and c["id"] not in seen:
                seen.add(c["id"])
                items.append(c)
        done = n is None or len(raw) < n
        ent = {
            "t": time.time(),
            "items": items,
            "done": done,
            "title": info.get("title") or "",
            "channel": info.get("channel") or info.get("uploader") or "",
            "count": info.get("playlist_count") or (len(items) if done else None),
            "logo": avatar_of(info),
            "subs": info.get("channel_follower_count"),
        }
        if done or need is None or len(items) >= need or n >= 400:
            break
        n += 60
    if ent["items"]:                    # never cache an empty answer
        with LISTS_LOCK:
            LISTS[ck] = ent
    return ent


def page_of(ent, offset, n):
    items = ent["items"]
    page = items[offset: offset + n]
    return {
        "results": page,
        "next": offset + len(page),
        "more": offset + n < len(items) or not ent["done"],
    }


VID_RES = [
    re.compile(r"youtu\.be/([\w-]{11})", re.I),
    re.compile(r"[?&]v=([\w-]{11})"),
    re.compile(r"/(?:shorts|live|embed|v|e)/([\w-]{11})"),
]
LINK_RE = re.compile(r"(?:youtu\.be/|youtube\.com/|youtube-nocookie\.com/)", re.I)


def parse_link(q):
    if not LINK_RE.search(q):
        return None
    vid = None
    for r in VID_RES:
        m = r.search(q)
        if m:
            vid = m.group(1)
            break
    m = re.search(r"[?&]list=([\w-]+)", q)
    lst = m.group(1) if m and m.group(1) not in ("WL", "LL") else None
    if not vid and not lst:
        return None
    return vid, lst


def dur_ok(c, dur):
    d = c.get("duration")
    if not dur or d is None:
        return True
    return d < 240 if dur == "short" else d > 1200 if dur == "long" else 240 <= d <= 1200


def search_with_fallback(q, typ, date, dur, need, country):
    """Results page first (supports every filter). If YouTube gives nothing for a
    term, try the search API with the original and then a cleaned-up query."""
    key = "s:" + json.dumps([q, typ, date, dur])
    err = None
    try:
        ent = get_list(key, search_url(q, typ, date, dur), need, country, True)
        if ent["items"]:
            return ent
    except ApiError as e:
        err = e
    if typ != "playlist" and not date:
        tries = [re.sub(r"\s+", " ", q).strip()]
        cleaned = re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", q)).strip()
        if cleaned and cleaned not in tries:
            tries.append(cleaned)
        for qq in tries:
            try:
                ent = get_list("ys:" + json.dumps([qq]), "ytsearch200:" + qq, need, country, False)
            except ApiError as e:
                err = err or e
                continue
            items = [c for c in ent["items"] if dur_ok(c, dur)]
            if items:
                return dict(ent, items=items, done=ent["done"] and not dur)
    if err:
        raise err
    return {"items": [], "done": True, "title": "", "channel": "", "count": 0}


def _int(v, d):
    try:
        return int(v)
    except (TypeError, ValueError):
        return d



# ----------------------------------------------------------------------------
# every other site that yt-dlp supports
# ----------------------------------------------------------------------------
SITES = []
EXT_LISTS = {}
EXT_LOCK = threading.Lock()


def sites_list():
    if SITES:
        return SITES
    need_ytdlp()
    from yt_dlp.extractor import gen_extractor_classes
    seen = {}
    for ie in gen_extractor_classes():
        try:
            name = str(getattr(ie, "IE_NAME", "") or "")
            if not name or name == "generic" or getattr(ie, "IE_DESC", None) is False:
                continue
            base = name.split(":")[0]
            ent = seen.setdefault(base, {"n": base, "k": ""})
            key = getattr(ie, "SEARCH_KEY", None)
            if key and not ent["k"]:
                ent["k"] = str(key)
        except Exception:
            continue
    SITES[:] = sorted(seen.values(), key=lambda x: x["n"].lower())
    return SITES


IES = []


def site_of_url(url):
    """name of the site a link belongs to (yt-dlp knows it), or its host name"""
    try:
        if not IES:
            need_ytdlp()
            from yt_dlp.extractor import gen_extractor_classes
            IES.extend(gen_extractor_classes())
        for ie in IES:
            name = str(getattr(ie, "IE_NAME", "") or "")
            if not name or name == "generic" or getattr(ie, "IE_DESC", None) is False:
                continue
            try:
                if ie.suitable(url):
                    return name.split(":")[0]
            except Exception:
                continue
    except Exception:
        pass
    return (up.urlsplit(url).hostname or "").replace("www.", "")


def _ext_card(e):
    if not isinstance(e, dict):
        return None
    url = e.get("webpage_url") or e.get("original_url") or e.get("url") or ""
    if not re.match(r"https?://", str(url), re.I):
        return None
    th = e.get("thumbnail") or ""
    if not th:
        tl = e.get("thumbnails") or []
        if tl:
            th = (tl[-1] or {}).get("url") or ""
    card = {"type": "video", "id": ext_id(str(url)), "title": e.get("title") or str(url),
            "thumb": th if str(th).startswith("http") else "", "duration": e.get("duration"),
            "channel": e.get("channel") or e.get("uploader") or ""}
    cu = e.get("channel_url") or e.get("uploader_url") or ""
    if re.match(r"https?://", str(cu), re.I):
        card["churl"] = str(cu)
    return card


def _ext_entries(url, country, limit):
    key = (url, country)
    with EXT_LOCK:
        c = EXT_LISTS.get(key)
    if c and time.time() - c[0] < 600:
        return c[1]
    try:
        with Y({"extract_flat": "in_playlist", "skip_download": True, "playlistend": limit}, country) as ydl:
            info = ydl.extract_info(url, download=False) or {}
    except Exception as exc:
        raise ApiError(clean_err(exc))
    ents = info.get("entries")
    cards = [_ext_card(info)] if ents is None else [_ext_card(e) for e in list(ents)]
    cards = [x for x in cards if x]
    if not cards:
        raise ApiError("Nothing to download was found there.")
    with EXT_LOCK:
        if len(EXT_LISTS) > 30:
            EXT_LISTS.clear()
        EXT_LISTS[key] = (time.time(), cards)
    return cards


def _ext_page(cards, offset, n, **extra):
    page = cards[offset:offset + n]
    out = {"results": page, "next": offset + len(page), "more": offset + len(page) < len(cards)}
    out.update(extra)
    return out


def api_ext_link(url, offset, n, country):
    return _ext_page(_ext_entries(url, country, 100), offset, n, site=site_of_url(url), link=True)


def api_ext_channel(qs, country):
    """a channel / profile page of another site: its videos, newest first"""
    url = (qs.get("url") or "").strip()
    if not re.match(r"https?://", url, re.I):
        raise ApiError("Bad channel link")
    offset = max(0, _int(qs.get("offset"), 0))
    n = max(1, min(50, _int(qs.get("n"), 12)))
    key = ("chx", url, country)
    with EXT_LOCK:
        c = EXT_LISTS.get(key)
    if c and time.time() - c[0] < 600:
        cards, head = c[1]
    else:
        try:
            with Y({"extract_flat": "in_playlist", "skip_download": True, "playlistend": 120}, country) as ydl:
                info = ydl.extract_info(url, download=False) or {}
        except Exception as exc:
            raise ApiError(clean_err(exc))
        ents = info.get("entries")
        raw = [info] if ents is None else [e for e in list(ents) if e]

        def stamp(e):
            if e.get("timestamp"):
                return e["timestamp"]
            ud = str(e.get("upload_date") or "")
            return int(ud) if ud.isdigit() else 0

        if raw and sum(1 for e in raw if stamp(e)) * 2 >= len(raw):
            raw.sort(key=lambda e: -stamp(e))                      # newest first
        head = {"id": url, "name": info.get("channel") or info.get("uploader") or info.get("title") or "",
                "logo": avatar_of(info) or info.get("thumbnail") or ((info.get("thumbnails") or [{}])[-1].get("url") or ""),
                "subs": info.get("channel_follower_count")}
        cards = [x for x in (_ext_card(e) for e in raw) if x]
        for x in cards:
            if not x.get("channel"):
                x["channel"] = head["name"]
        if not cards:
            raise ApiError("No videos were found on that page.")
        with EXT_LOCK:
            if len(EXT_LISTS) > 30:
                EXT_LISTS.clear()
            EXT_LISTS[key] = (time.time(), (cards, head))
    return _ext_page(cards, offset, n, channel=head, site=site_of_url(url))


def api_ext_search(site, q, offset, n, country):
    key = next((x["k"] for x in sites_list() if x["n"] == site), "")
    if not key:
        raise ApiError("This site has no search here. Paste a link from it instead.")
    return _ext_page(_ext_entries(f"{key}50:{q}", country, 50), offset, n, site=site)


def get_formats_ext(vid, country):
    ck = (vid, country)
    with FORMATS_LOCK:
        c = FORMATS.get(ck)
    if c and time.time() - c[0] < 900:
        return c[1]
    try:
        with Y({"noplaylist": True, "skip_download": True}, country) as ydl:
            info = ydl.extract_info(vid_url(vid), download=False) or {}
    except Exception as exc:
        raise ApiError(clean_err(exc))
    if info.get("entries") is not None:
        ents = [e for e in list(info["entries"]) if e]
        if not ents:
            raise ApiError("Nothing to download was found there.")
        info = ents[0]
    dur = info.get("duration") or 0
    heights = {}
    for f in info.get("formats") or []:
        if (f.get("vcodec") or "none") == "none" or not f.get("height"):
            continue
        h = int(f["height"])
        heights[h] = max(heights.get(h, 0), f.get("filesize") or f.get("filesize_approx") or 0)
    if not heights and info.get("height") and (info.get("vcodec") or "x") != "none":
        heights[int(info["height"])] = info.get("filesize") or info.get("filesize_approx") or 0
    videos = [{"id": f"x{h}", "label": f"{h}p", "fam": "h264", "h": h, "fps": 30, "size": heights[h], "x": 1}
              for h in sorted(heights, reverse=True)]
    audios = [{"id": "xa-m4a", "src": "xa-m4a", "conv": False, "br": None, "label": "AAC 128k", "ext": "m4a",
               "abr": 128, "size": int(dur * 128000 / 8) if dur else 0, "x": 1}]
    for br in MP3_RATES:
        audios.append({"id": f"xa-mp3-{br}", "src": "xa", "conv": True, "br": br, "label": f"MP3 {br}k",
                       "ext": "mp3", "abr": br, "size": int(dur * br * 1000 / 8) if dur else 0, "dsize": 0, "x": 1})
    th = info.get("thumbnail") or ""
    if not th and info.get("thumbnails"):
        th = (info["thumbnails"][-1] or {}).get("url") or ""
    out = {"title": info.get("title") or "Video", "thumb": th, "duration": dur,
           "channel": info.get("channel") or info.get("uploader") or "", "videos": videos, "audios": audios}
    with FORMATS_LOCK:
        FORMATS[ck] = (time.time(), out)
    return out


def run_ext_job(j):
    """download from any other site: yt-dlp picks and merges the streams, we show progress and save the file"""
    cancel = j["_cancel"]
    ensure_work()
    work = job_work(j) if j.get("work") else WORK_DIR / j["id"]
    j["work"] = str(work)
    work.mkdir(parents=True, exist_ok=True)
    kind = j["kind"]
    v = j.get("v") or {}
    a = j.get("a") or {}
    final = None
    try:
        with CV:
            j["steps"] = {}
        step_init(j, "v", "Downloading: waiting", 40)
        if kind == "video" or (kind == "audio" and a.get("conv")):
            step_init(j, "m", "Finishing: waiting", 4)
        step_init(j, "s", "Save to folder: waiting", 2)
        step(j, "v", "downloading", "Downloading...", pct=0)
        m = re.fullmatch(r"x(\d{2,5})", str(v.get("id") or ""))
        h = int(m.group(1)) if m else 0
        if kind == "audio":
            fmt = "bestaudio/best"
        elif kind == "vonly":
            fmt = (f"bv*[height<={h}]/b[height<={h}]/" if h else "") + "bv*/b"
        else:
            fmt = (f"bv*[height<={h}]+ba/b[height<={h}]/" if h else "") + "bv*+ba/b"
        prog = {}
        t0 = time.time()

        def hook(d):
            if cancel.is_set():
                raise JobCancelled()
            while _up(j):
                if cancel.is_set():
                    raise JobCancelled()
                time.sleep(0.3)
            fn = d.get("filename") or ""
            if d.get("status") == "downloading":
                done = d.get("downloaded_bytes") or 0
                tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                prog[fn] = [done, tot]
                dn = sum(p[0] for p in prog.values())
                tt = sum(max(p[0], p[1]) for p in prog.values())
                inst = d.get("speed") or 0
                lim = int(j.get("_limit") or 0)
                if lim and inst > lim:
                    time.sleep(min(1.0, (inst / lim - 1) * 0.15))
                rate = dn / max(1.0, time.time() - t0)
                pct = min(99.0, dn * 100 / tt) if tt else 0
                step(j, "v", "downloading", "Downloading...", pct=pct, spd=inst,
                     eta=(time.time() + max(0, tt - dn) / max(rate, 1e4)) if tt else None)
                upd(j, dl=pct, done_b=dn, total_b=tt, speed=inst)
            elif d.get("status") == "finished":
                done = d.get("total_bytes") or d.get("downloaded_bytes") or 0
                prog[fn] = [done, done]

        def pp(d):
            if d.get("status") == "started":
                step(j, "v", "done", "Downloaded \u2713")
                if "m" in j["steps"]:
                    step(j, "m", "downloading", "Finishing...", pct=50)
                upd(j, stage="merging", speed=0, dl=100)

        opts = {"format": fmt, "outtmpl": str(work / "dl.%(ext)s"), "noplaylist": True, "continuedl": True,
                "retries": 8, "fragment_retries": 8, "concurrent_fragment_downloads": 8,
                "overwrites": True, "progress_hooks": [hook], "postprocessor_hooks": [pp]}
        if kind == "video":
            opts["merge_output_format"] = "mp4"
        if kind == "audio":
            br = int(a.get("br") or 192)
            opts["postprocessors"] = [{"key": "FFmpegExtractAudio",
                                       "preferredcodec": "mp3" if a.get("conv") else "m4a",
                                       "preferredquality": str(br if a.get("conv") else 128)}]
        with Y(opts, "") as ydl:
            ydl.download([vid_url(j["vid"])])
        if cancel.is_set():
            raise JobCancelled()
        files = [p for p in work.glob("dl.*")
                 if p.is_file() and p.suffix.lower() not in (".part", ".ytdl", ".json", ".jpg", ".png", ".webp")]
        if not files:
            raise RuntimeError("The download finished but no file was produced.")
        out = max(files, key=lambda p: p.stat().st_size)
        if "m" in j["steps"]:
            step(j, "m", "done", "Finishing \u2713")
        dest = Path(j.get("dest") or OUTPUT_DIR)
        try:
            dest.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(f"Cannot use the folder {dest}: {e}")
        final = unique_path(dest / f"{safe_name(j['title'], 150)}{out.suffix}")
        post_gate(j)
        upd(j, stage="uploading", up=0, speed=0, dl=100)
        step(j, "s", "downloading", "Save to folder: working...", pct=0)
        copy_with_progress(out, final, j)
        step(j, "s", "done", "Save to folder: finished \u2713")
        shutil.rmtree(work, ignore_errors=True)
        keep = KEEP_AUDIO if kind == "audio" else KEEP_VIDEO
        now = time.time()
        upd(j, stage="done", finished=now, file=str(final), path=str(final), note="",
            dl=100, merge=100, up=100, speed=0, expires_at=(now + keep * 3600) if keep else None)
    except JobCancelled:
        if final:
            try:
                Path(final).unlink()
            except OSError:
                pass
        shutil.rmtree(work, ignore_errors=True)
        upd(j, stage="cancelled", note="", speed=0)
    except Exception as exc:
        for k, st_ in list(j["steps"].items()):
            if st_["status"] == "downloading":
                step(j, k, "error", st_["text"])
        upd(j, stage="error", note=clean_err(exc), speed=0)
    finally:
        j["_proc"] = None
        persist()


def api_search(qs, country):
    q = (qs.get("q") or "").strip()
    typ = qs.get("type") or "all"
    date = qs.get("date") or ""
    dur = qs.get("dur") or ""
    offset = max(0, _int(qs.get("offset"), 0))
    n = max(1, min(50, _int(qs.get("n"), 12)))
    if not q:
        return {"results": [], "next": 0, "more": False}
    site = (qs.get("site") or "youtube").strip().lower()
    if re.match(r"https?://", q, re.I) and not parse_link(q):
        return api_ext_link(q, offset, n, country)
    if site not in ("", "youtube"):
        return api_ext_search(site, q, offset, n, country)
    link = parse_link(q)
    if link:
        if offset:
            return {"results": [], "next": offset, "more": False}
        vid, lst = link
        res = []
        if vid:
            try:
                f = get_formats(vid, country)
                res.append({"type": "video", "id": vid, "title": f["title"], "thumb": f["thumb"],
                            "duration": f["duration"], "channel": f["channel"]})
            except Exception:
                res.append({"type": "video", "id": vid, "title": "Video " + vid,
                            "thumb": thumb_of(vid), "duration": None, "channel": ""})
        if lst:
            ent = get_list("pl:" + lst, "https://www.youtube.com/playlist?list=" + lst, 1, country, False)
            res.append({"type": "playlist", "id": lst, "title": ent["title"] or "Playlist",
                        "thumb": thumb_of(ent["items"][0]["id"]) if ent["items"] else "",
                        "channel": ent["channel"], "count": ent["count"]})
        return {"results": res, "next": len(res), "more": False, "site": "youtube", "link": True}
    ent = search_with_fallback(q, typ, date, dur, offset + n, country)
    res = page_of(ent, offset, n)
    res["site"] = "youtube"
    return res


def api_playlist(qs, country):
    pid = qs.get("id") or ""
    if not re.fullmatch(r"[\w-]{10,60}", pid):
        raise ApiError("Bad playlist id")
    url = "https://www.youtube.com/playlist?list=" + pid
    if qs.get("all"):
        ent = get_list("pl:" + pid, url, None, country, False)
        return {"results": ent["items"], "title": ent["title"]}
    offset = max(0, _int(qs.get("offset"), 0))
    n = max(1, min(50, _int(qs.get("n"), 12)))
    ent = get_list("pl:" + pid, url, offset + n, country, False)
    return page_of(ent, offset, n)



# ----------------------------------------------------------------------------
# channels, search history, library on the phone, availability check
# ----------------------------------------------------------------------------
def avatar_of(info):
    th = info.get("thumbnails") or []
    for t in th:
        if str(t.get("id")) == "avatar_uncropped" and t.get("url"):
            return t["url"]
    for t in th:
        u = t.get("url") or ""
        if "/ytc/" in u or ("yt3.g" in u and "fcrop" not in u and "banner" not in str(t.get("id"))):
            return u
    return ""


def parse_channel(e):
    cid = str(e.get("channel_id") or "")
    eid = str(e.get("id") or "")
    url = str(e.get("url") or e.get("webpage_url") or "")
    if len(eid) == 11:
        return None                         # a video, not a channel
    if not cid.startswith("UC"):
        m = re.search(r"/channel/(UC[\w-]{20,24})", url) or re.fullmatch(r"(UC[\w-]{20,24})", eid)
        cid = m.group(1) if m else ""
    if not cid:
        return None
    logo = ""
    tl = e.get("thumbnails") or []
    if tl:
        logo = tl[-1].get("url") or ""
        if logo.startswith("//"):
            logo = "https:" + logo
    return {"id": cid, "name": e.get("channel") or e.get("uploader") or e.get("title") or "Channel",
            "handle": e.get("uploader_id") or "", "subs": e.get("channel_follower_count"), "logo": logo,
            "desc": str(e.get("description") or "")[:140]}


CHS = {}


def api_channels(qs, country):
    q = (qs.get("q") or "").strip()
    if not q:
        return {"results": []}
    key = (q.lower(), country)
    ent = CHS.get(key)
    if ent and time.time() - ent[0] < 600:
        return {"results": ent[1]}
    out, seen = [], set()
    err = None
    try:
        with Y({"extract_flat": "in_playlist", "skip_download": True, "playlistend": 24}, country) as ydl:
            info = ydl.extract_info(search_url(q, "channel", "", ""), download=False) or {}
        for e in info.get("entries") or []:
            c = parse_channel(e or {})
            if c and c["id"] not in seen:
                seen.add(c["id"])
                out.append(c)
    except Exception as exc:
        err = ApiError(clean_err(exc))
    if not out:                                 # fallback: channels of the first video results
        try:
            with Y({"extract_flat": "in_playlist", "skip_download": True, "playlistend": 40}, country) as ydl:
                info = ydl.extract_info("ytsearch40:" + q, download=False) or {}
            for e in info.get("entries") or []:
                cid = str((e or {}).get("channel_id") or "")
                if cid.startswith("UC") and cid not in seen:
                    seen.add(cid)
                    out.append({"id": cid, "name": e.get("channel") or e.get("uploader") or "Channel",
                                "handle": e.get("uploader_id") or "", "subs": None, "logo": "", "desc": ""})
            err = None
        except Exception as exc:
            err = err or ApiError(clean_err(exc))
    if not out and err:
        raise err
    if out:
        CHS[key] = (time.time(), out)
    return {"results": out}


def api_channel(qs, country):
    if (qs.get("url") or "").strip():
        return api_ext_channel(qs, country)
    cid = qs.get("id") or ""
    if not re.fullmatch(r"UC[\w-]{20,24}", cid):
        raise ApiError("Bad channel")
    tab = qs.get("tab") if qs.get("tab") in ("videos", "playlists", "live") else "videos"
    q = (qs.get("q") or "").strip() if tab == "videos" else ""
    offset = max(0, _int(qs.get("offset"), 0))
    n = max(1, min(50, _int(qs.get("n"), 12)))
    if q:
        url = "https://www.youtube.com/channel/%s/search?query=%s" % (cid, up.quote_plus(q))
        key = "ch:%s:%s" % (cid, q.lower())
    else:
        path = {"videos": "videos", "playlists": "playlists", "live": "streams"}[tab]
        url = "https://www.youtube.com/channel/%s/%s" % (cid, path)
        key = "ch:%s:%s" % (cid, tab)
    ent = get_list(key, url, offset + n, country, tab == "playlists")
    res = page_of(ent, offset, n)
    res["channel"] = {"id": cid, "name": ent.get("channel") or ent.get("title") or "",
                      "logo": ent.get("logo") or "", "subs": ent.get("subs")}
    res["site"] = "youtube"
    return res


HISTORY = []          # newest first, kept in data.json


def hist_add(q):
    q = re.sub(r"\s+", " ", str(q or "")).strip()[:120]
    if not q:
        return
    HISTORY[:] = [h for h in HISTORY if h.lower() != q.lower()]
    HISTORY.insert(0, q)
    del HISTORY[60:]
    persist()


def hist_del(q=None):
    if q is None:
        HISTORY.clear()
    else:
        HISTORY[:] = [h for h in HISTORY if h != q]
    persist()


MEDIA_EXT = {".mp4", ".mkv", ".webm", ".mov", ".m4v", ".mp3", ".m4a", ".opus", ".ogg", ".aac", ".wav", ".flac"}
AUDIO_EXT = {".mp3", ".m4a", ".opus", ".ogg", ".aac", ".wav", ".flac"}
LIBMAP = {}
LIBINDEX = []


def scan_library():
    """every video / audio file in the save folder (finished downloads and files from before)"""
    with CV:
        known = {}
        for j in JOBS.values():
            for k in ("file", "path"):
                if j.get(k) and j.get("stage") == "done":
                    try:
                        known[os.path.realpath(str(j[k]))] = j
                    except OSError:
                        pass
    items = []
    roots = [OUTPUT_DIR] + ([DEFAULT_OUT] if DEFAULT_OUT != OUTPUT_DIR else [])
    for j in known.values():                 # folders chosen for single downloads count too
        d = os.path.dirname(str(j.get("file") or j.get("path") or ""))
        if d and Path(d) not in roots:
            roots.append(Path(d))
    seen = set()
    for root in roots:
        for dp, dn, fn in os.walk(str(root)):
            dn[:] = [d for d in dn if not d.startswith(".")]
            for f in fn:
                ext = os.path.splitext(f)[1].lower()
                if f.startswith(".") or ext not in MEDIA_EXT:
                    continue
                p = os.path.join(dp, f)
                try:
                    rp = os.path.realpath(p)
                    if rp in seen:
                        continue
                    seen.add(rp)
                    st = os.stat(p)
                except OSError:
                    continue
                iid = hashlib.md5(rp.encode("utf-8", "replace")).hexdigest()[:12]
                LIBMAP[iid] = p
                it = {"id": iid, "name": os.path.splitext(f)[0], "ext": ext[1:], "size": st.st_size,
                      "mtime": st.st_mtime, "kind": "audio" if ext in AUDIO_EXT else "video",
                      "dir": dp, "path": p}
                j = known.get(rp)
                if j:
                    it.update(title=j.get("title") or it["name"], thumb=j.get("thumb") or "", jid=j["id"])
                items.append(it)
    items.sort(key=lambda x: -x["mtime"])
    items = items[:500]
    LIBINDEX[:] = items
    return items


def lib_delete(iid):
    p = LIBMAP.get(iid)
    if not p or not os.path.isfile(p):
        raise ApiError("File not found", 404)
    os.remove(p)
    LIBMAP.pop(iid, None)
    persist()


PROBE_IDS = ["jNQXAC9IVRw", "dQw4w9WgXcQ", "kJQP7kiw5Fk", "9bZkp7q19f0", "RgKAFK5djSk",
             "JGwWNGJdvx8", "OPf0YbXqDm0", "fJ9rUzIMcZQ", "YQHsXMglC9A", "CevxZvSJLk8"]
HEALTH = {"state": "idle", "t": 0.0}           # idle | checking | ok | busy | offline
NET_WORDS = ("name or service", "temporary failure", "network is unreachable", "no address associated",
             "getaddrinfo", "failed to resolve", "no route to host", "unable to connect")


def health_probe():
    """try the sample videos in random order: the first one that gives qualities means everything works"""
    if HEALTH["state"] == "checking":
        return
    HEALTH["state"] = "checking"
    fails = net = 0
    try:
        for vid in random.sample(PROBE_IDS, len(PROBE_IDS)):
            try:
                f = get_formats(vid, "")
                if f and (f.get("videos") or f.get("audios")):
                    HEALTH.update(state="ok", t=time.time())
                    return
                raise RuntimeError("no qualities")
            except Exception as exc:
                fails += 1
                if any(w in str(exc).lower() for w in NET_WORDS):
                    net += 1
                if fails >= 4:
                    break
        HEALTH.update(state="offline" if net >= fails else "busy", t=time.time())
    except Exception:
        HEALTH.update(state="busy", t=time.time())


def health_loop():
    while yt_dlp is None:
        time.sleep(3)
    while True:
        health_probe()
        wait = 300 if HEALTH["state"] in ("busy", "offline") else 3600
        for _ in range(wait):
            time.sleep(1)
            if HEALTH["state"] == "idle":       # a retry was asked for
                break
        if HEALTH["state"] != "idle":
            HEALTH["state"] = "idle"


# ----------------------------------------------------------------------------
# formats
# ----------------------------------------------------------------------------
FAM = {"h264": "H.264", "vp9": "VP9", "av1": "AV1"}
FORMATS = {}
FORMATS_LOCK = threading.Lock()
MP3_RATES = (320, 192, 128)


def fam_of(vcodec):
    v = (vcodec or "").lower()
    if v.startswith("avc"):
        return "h264"
    if v.startswith("vp09") or v.startswith("vp9"):
        return "vp9"
    if v.startswith("av01") or v.startswith("av1"):
        return "av1"
    return None


def get_formats(vid, country):
    if is_ext(vid):
        return get_formats_ext(vid, country)
    ck = (vid, country)
    with FORMATS_LOCK:
        c = FORMATS.get(ck)
    if c and time.time() - c[0] < 900:
        return c[1]
    try:
        with Y({"noplaylist": True, "skip_download": True}, country) as ydl:
            info = ydl.extract_info("https://www.youtube.com/watch?v=" + vid, download=False)
    except Exception as exc:
        raise ApiError(clean_err(exc))
    dur = info.get("duration") or 0
    vids, auds = {}, {}
    for f in info.get("formats") or []:
        if f.get("has_drm") or (f.get("protocol") or "").startswith(("m3u8", "mhtml")):
            continue
        note = (f.get("format_note") or "") + " " + str(f.get("format_id") or "")
        if "Premium" in note or "drc" in note.lower() or "storyboard" in note.lower():
            continue
        vc = f.get("vcodec") or "none"
        ac = f.get("acodec") or "none"
        tbr = f.get("tbr") or f.get("abr") or 0
        size = f.get("filesize") or f.get("filesize_approx") or (
            int(tbr * 1000 / 8 * dur) if tbr and dur else 0)
        fid = str(f["format_id"])
        if vc != "none" and ac == "none" and f.get("height"):
            fam = fam_of(vc)
            if not fam:
                continue
            h = int(f["height"])
            fps = int(round(f.get("fps") or 30))
            label = f"{h}p{fps if fps > 30 else ''} {FAM[fam]}"
            e = {"id": fid, "label": label, "fam": fam, "h": h, "fps": fps, "size": size}
            if label not in vids or (tbr, size) > vids[label][0]:
                vids[label] = ((tbr, size), e)
        elif ac != "none" and vc == "none":
            ext = f.get("ext")
            if ext not in ("m4a", "webm"):
                continue
            abr = int(round(f.get("abr") or tbr or 0))
            if not abr:
                continue
            if ext == "m4a":                       # AAC: normalise 129.5 -> 128 so every video shares one label
                abr = 48 if abr <= 80 else 128 if abr <= 190 else 256
                label = f"AAC {abr}k"
            else:
                label = f"WEBM {abr}k"
            e = {"id": fid, "src": fid, "conv": False, "br": None, "label": label,
                 "ext": ext, "abr": abr, "size": size}
            rank = (f.get("language_preference") or 0, size)
            if label not in auds or rank > auds[label][0]:
                auds[label] = (rank, e)
    videos = sorted((x[1] for x in vids.values()), key=lambda e: (-e["h"], -e["fps"]))
    audios = [x[1] for x in auds.values()]
    if audios:
        best = max(audios, key=lambda e: (e["abr"], e["ext"] == "m4a"))
        for br in MP3_RATES:
            audios.append({"id": f"{best['src']}-mp3-{br}", "src": best["src"], "conv": True,
                           "br": br, "label": f"MP3 {br}k", "ext": "mp3", "abr": br,
                           "size": int(dur * br * 1000 / 8) if dur else 0,
                           "dsize": best["size"]})
    if not videos and not audios:
        raise ApiError("No downloadable formats were found for this video.")
    out = {
        "title": info.get("title") or "Video " + vid,
        "thumb": thumb_of(vid),
        "duration": dur,
        "channel": info.get("channel") or info.get("uploader") or "",
        "videos": videos,
        "audios": audios,
    }
    with FORMATS_LOCK:
        FORMATS[ck] = (time.time(), out)
    return out


# ----------------------------------------------------------------------------
# job store
# ----------------------------------------------------------------------------
def public(j):
    return {k: v for k, v in j.items() if not k.startswith("_")}


BAK = {"t": 0.0}


def persist():
    """writes data.json: settings + every video (stage, progress, which pieces of each stream are finished)"""
    flush_all()
    with PERSIST_LOCK:
        try:
            with CV:
                data = []
                for j in JOBS.values():
                    p = public(j)
                    p["steps"] = {k: dict(v) for k, v in (j.get("steps") or {}).items()}
                    if j.get("stage") in ("done", "cancelled", "expired", "deleted"):
                        p.pop("parts", None)
                    data.append(p)
            blob = {"version": 3, "saved": time.time(), "settings": dict(SET), "jobs": data,
                    "stat": dict(STAT), "traffic": (globals().get("SPEED") or {}).get("total", 0),
                    "history": list(HISTORY), "library": list(LIBINDEX)}
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            tmp = DATA_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(blob), encoding="utf-8")
            if DATA_FILE.exists() and time.time() - BAK["t"] > 60:      # a second copy, in case a crash cuts a write
                shutil.copyfile(DATA_FILE, DATA_FILE.with_suffix(".bak"))
                BAK["t"] = time.time()
            os.replace(tmp, DATA_FILE)
        except Exception:
            pass


def upd(j, **kw):
    with CV:
        j.update(kw)
        j["updated"] = time.time()


def step_init(j, key, text, est):
    with CV:
        j["steps"][key] = {"status": "pending", "text": text, "est": round(est, 1), "pct": 0, "spd": 0}


def step(j, key, status, text, eta=None, pct=None, spd=None):
    """update one step; remembers when it started / finished (separate time and % per step)"""
    now = time.time()
    with CV:
        s = j["steps"].get(key) or {}
        if status == "downloading" and not s.get("t0"):
            s["t0"] = now
        if status in ("done", "error") and not s.get("t1"):
            s["t1"] = now
        s["status"], s["text"] = status, text
        if eta is not None:
            s["eta"] = eta
        if pct is not None:
            s["pct"] = round(pct, 1)
        if spd is not None:
            s["spd"] = spd
        if status == "done":
            s["pct"], s["spd"] = 100, 0
        j["steps"][key] = s
        j["updated"] = now


def step_pct(j, key, pct):
    with CV:
        s = (j.get("steps") or {}).get(key)
        if s is not None:
            s["pct"] = round(pct, 1)


def load_jobs():
    dd = read_data()
    for k, v in (dd.get("stat") or {}).items():
        if k in STAT and isinstance(v, (int, float)):
            STAT[k] = float(v)
    try:
        SPEED["total"] = int(dd.get("traffic") or 0)
    except (TypeError, ValueError):
        pass
    data = dd.get("jobs") or []
    if not isinstance(data, list) or not data:
        return
    top = 0
    for j in data:
        j["_cancel"] = threading.Event()
        j["_pause"] = threading.Event()
        j["_upause"] = threading.Event()
        j["paused"] = False
        j["_limit"] = 0
        j["_phase"] = None
        j["_proc"] = None
        top = max(top, j.get("qseq") or 0)
        st = j.get("stage")
        if st == "cancelling":
            j["stage"] = "cancelled"
            shutil.rmtree(job_work(j), ignore_errors=True)
        elif st in LIVE or st == "queued":
            j["stage"] = "confirm"
            j["note"] = "Stopped when the program closed. What is already downloaded is saved: press Continue to carry on from there"
        elif st == "done" and not (j.get("file") and Path(j["file"]).exists()):
            j["stage"] = "deleted"
        JOBS[j["id"]] = j
    NEXT_Q[0] = top + 1


def _n(x):
    try:
        return max(0, int(x or 0))
    except (TypeError, ValueError):
        return 0


def make_job(it, compat, playlist, dest):
    vid = str(it.get("id") or "")
    if not VID_OK.fullmatch(vid):
        raise ApiError("Bad video id")
    kind = it.get("kind")
    if kind not in ("video", "vonly", "audio"):
        raise ApiError("Bad download type")
    ok_id = re.compile(r"[\w.\-]{1,40}")
    v, a = it.get("v"), it.get("a")
    if kind in ("video", "vonly"):
        if not isinstance(v, dict) or not ok_id.fullmatch(str(v.get("id", ""))):
            raise ApiError("Bad video format")
        v = {"id": str(v["id"]), "label": str(v.get("label") or ""),
             "fam": str(v.get("fam") or ""), "h": v.get("h")}
    else:
        v = None
    if kind in ("video", "audio"):
        if not isinstance(a, dict) or not ok_id.fullmatch(str(a.get("src", ""))):
            raise ApiError("Bad audio format")
        a = {"id": str(a.get("id") or a["src"]), "src": str(a["src"]), "conv": bool(a.get("conv")),
             "br": _n(a.get("br")) or 192, "label": str(a.get("label") or ""),
             "ext": str(a.get("ext") or "")}
    else:
        a = None
    with CV:
        q = NEXT_Q[0]
        NEXT_Q[0] += 1
    return {
        "id": uuid.uuid4().hex[:12],
        "vid": vid,
        "title": str(it.get("title") or vid)[:300],
        "thumb": (thumb_of(vid) if not is_ext(vid) else (str(it.get("thumb") or "")[:600] if str(it.get("thumb") or "").startswith("http") else "")),
        "duration": it.get("duration") or 0,
        "channel": str(it.get("channel") or "")[:200],
        "kind": kind, "v": v, "a": a,
        "compat": bool(compat),
        "playlist": str(playlist)[:300] if playlist else None,
        "dest": str(dest),
        "fallback": (str(it.get("fb"))[:300] if it.get("fb") else None),
        "v_bytes": _n(it.get("v_bytes")), "a_bytes": _n(it.get("a_bytes")),
        "est_bytes": _n(it.get("est_bytes")),
        "stage": "queued", "note": "", "qseq": q, "updated": time.time(),
        "steps": {}, "dl": 0, "merge": 0, "up": 0, "done_b": 0, "total_b": 0, "speed": 0,
        "started": None, "finished": None, "start_at": 0, "eta_at": 0,
        "expires_at": None, "file": None, "path": None,
        "_cancel": threading.Event(), "_pause": threading.Event(), "_upause": threading.Event(), "paused": False,
        "work": "", "_limit": 0, "_phase": None, "_proc": None,
    }


def plan(j):
    """estimated seconds of every step, from AVERAGE speeds"""
    kind = j["kind"]
    bps = avg_bps()
    dur = j.get("duration") or 0
    vb, ab = j.get("v_bytes") or 0, j.get("a_bytes") or 0
    if not (vb or ab) and j.get("est_bytes"):
        vb, ab = (j["est_bytes"], 0) if kind == "vonly" else (0, j["est_bytes"]) if kind == "audio" \
            else (j["est_bytes"] * 0.85, j["est_bytes"] * 0.15)
    p = {"p": 4.0}
    if kind in ("video", "vonly"):
        p["v"] = vb / bps
    if kind in ("video", "audio"):
        p["a"] = ab / bps
    if kind == "video":
        enc = j.get("compat") and (j.get("v") or {}).get("fam") != "h264"
        p["m"] = dur / enc_rate() if enc else 2 + (vb + ab) / 8e7
    if kind == "audio" and (j.get("a") or {}).get("conv"):
        p["c"] = 2 + dur / 40
    p["s"] = 1 + (vb + ab) / 1e8
    return p


def est_seconds(j):
    return sum(plan(j).values())


def remaining(j, now):
    """seconds left for a running job = what is left of each step"""
    pl = plan(j)
    steps = j.get("steps") or {}
    if not steps:
        return sum(pl.values())
    r = 0.0
    for k, s in steps.items():
        if s["status"] == "done":
            continue
        if s["status"] == "downloading":
            r += max(1.0, (s.get("eta") or now + pl.get(k, 1)) - now)
        else:
            r += s.get("est") or pl.get(k, 1)
    return r


def schedule(now):
    """Fills start_at / eta_at of every job and returns (active, queued, finish_at)."""
    with CV:
        act = [j for j in JOBS.values() if j["stage"] in LIVE]
        que = sorted((j for j in JOBS.values() if j["stage"] == "queued"), key=lambda x: x["qseq"])
        cur = now
        for j in act:
            rem = remaining(j, now)
            j["eta_at"] = now + rem
            cur = max(cur, now + rem)
        for j in que:
            j["start_at"] = cur
            cur += est_seconds(j)
            j["eta_at"] = cur
        return len(act), len(que), cur


def _rank(j):
    st = j["stage"]
    return 0 if st in LIVE else 1 if st in ("confirm", "error") else 2 if st == "queued" else 3


def jobs_payload(host, limit=80):
    now = time.time()
    a, q, fin = schedule(now)
    with CV:
        allj = list(JOBS.values())
        stopped = sum(1 for j in allj if j["stage"] in ("confirm", "error"))
        speed = sum((j.get("speed") or 0) for j in allj if j["stage"] == "downloading")
        allj.sort(key=lambda j: (_rank(j), j["qseq"] if _rank(j) < 3 else -(j.get("updated") or 0)))
        order = sorted((j for j in allj if j["stage"] in ("downloading", "queued")), key=lambda x: x["qseq"])
        pos = {j["id"]: i + 1 for i, j in enumerate(order)}
        out = []
        for j in allj[:limit]:
            p = public(j)
            p.pop("parts", None)
            p["pos"] = pos.get(j["id"], 0)
            p["steps"] = {k: dict(v) for k, v in (j.get("steps") or {}).items()}
            if j["stage"] == "done" and j.get("file"):
                p["direct"] = f"http://{host}/files/{j['id']}"
            out.append(p)
    return {"now": now, "jobs": out,
            "summary": {"active": a, "queued": q, "stopped": stopped, "speed": speed, "finish_at": fin,
                        "smart": SMART.get("info")}}


# ----------------------------------------------------------------------------
# worker
# ----------------------------------------------------------------------------
RECOVER_FACTOR = 0.5            # while the second video runs, the first one only needs 50% of the minimum speed to take over again
FAST_CONN = 8                  # connections used for ONE file (jobs still run one after another)
FAST_CHUNK = 4 * 1024 * 1024   # every request asks for 4 MB, so each one starts at full speed


FLUSHERS = set()      # running fast downloads: each writes its list of finished pieces when asked


def flush_all():
    for f in list(FLUSHERS):
        try:
            f()
        except Exception:
            pass


def fast_ok(f):
    return bool(f.get("url")) and (f.get("protocol") or "") in ("https", "http") \
        and not f.get("fragments") and not f.get("has_drm")


def fast_download(f, path, cancel, report, pause=None, limit=None, state=None, save=None):
    """Downloads ONE stream over several connections at once (ranged requests written into one file).
    `state` (kept in data.json) remembers which 4 MB pieces are finished, so after a stop, a restart or days
    later only the missing pieces are downloaded. Raises on any problem. Returns the file size."""
    state = state if state is not None else {}
    path = str(path)
    if state.get("complete") and state.get("path") == path and os.path.exists(path) \
            and os.path.getsize(path) == state.get("total"):
        report(state["total"], state["total"], 0)
        return state["total"]
    url = f["url"]
    hdrs = {str(k): str(v) for k, v in (f.get("http_headers") or {}).items()}
    req = ureq.Request(url, headers=dict(hdrs, Range="bytes=0-0"))
    with ureq.urlopen(req, timeout=20) as r:
        cr = r.headers.get("Content-Range") or ""
        r.read(1)
    if "/" not in cr or not cr.split("/")[-1].isdigit():
        raise RuntimeError("server does not support ranges")
    total = int(cr.split("/")[-1])
    if total <= 0:
        raise RuntimeError("unknown size")
    chunks = [(a, min(a + FAST_CHUNK, total) - 1) for a in range(0, total, FAST_CHUNK)]
    done_set = set()
    partial = {}                         # piece number -> next byte to fetch (pieces that are already part-way)
    if (state.get("total") == total and state.get("chunk") == FAST_CHUNK and state.get("path") == path
            and os.path.exists(path) and os.path.getsize(path) == total):
        try:
            raw = bytes.fromhex(state.get("done") or "")
        except ValueError:
            raw = b""
        done_set = {i for i in range(len(chunks)) if i // 8 < len(raw) and (raw[i // 8] >> (i % 8)) & 1}
        for k, v in (state.get("partial") or {}).items():       # a half-finished piece carries on where it stopped
            try:
                i, v = int(k), int(v)
            except (TypeError, ValueError):
                continue
            if 0 <= i < len(chunks) and i not in done_set and chunks[i][0] < v <= chunks[i][1]:
                partial[i] = v
    else:
        with open(path, "wb") as fo:
            fo.truncate(total)
    state.update(total=total, chunk=FAST_CHUNK, path=path, complete=False)
    lock = threading.Lock()
    stop = threading.Event()
    todo = deque(i for i in range(len(chunks)) if i not in done_set)
    st = {"done": sum(chunks[i][1] - chunks[i][0] + 1 for i in done_set)
          + sum(v - chunks[i][0] for i, v in partial.items()), "err": None}

    def flush():                         # called by persist(): the saved list of finished pieces is always current
        with lock:
            snapshot()

    def snapshot():                      # called with `lock` held
        ba = bytearray((len(chunks) + 7) // 8)
        for i in done_set:
            ba[i // 8] |= 1 << (i % 8)
        state["done"] = ba.hex()
        state["partial"] = {str(i): v for i, v in partial.items() if i not in done_set}

    tl = threading.Lock()
    tst = {"t": 0.0}

    def throttle(n):
        """shared speed limit of this file (all connections together); limit() gives bytes/s, 0 = none"""
        rate = limit() if limit else 0
        if not rate:
            tst["t"] = 0.0
            return
        with tl:
            now = time.time()
            tst["t"] = max(tst["t"], now - 0.25) + n / rate
            dead = tst["t"] - 0.25
        while time.time() < dead and not stop.is_set() and not cancel.is_set() and limit():
            time.sleep(0.1)

    def hold():
        while pause is not None and pause.is_set() and not stop.is_set() and not cancel.is_set():
            time.sleep(0.3)

    def worker(fd):
        while not stop.is_set() and not cancel.is_set():
            hold()
            with lock:
                if not todo:
                    return
                idx = todo.popleft()
            a, b = chunks[idx]
            pos, tries = max(a, partial.get(idx, a)), 0
            while pos <= b and not stop.is_set() and not cancel.is_set():
                hold()                                   # paused: no connection is open while waiting
                try:
                    rq = ureq.Request(url, headers=dict(hdrs, Range=f"bytes={pos}-{b}"))
                    paused_out = False
                    with ureq.urlopen(rq, timeout=20) as r:
                        if r.status != 206:
                            raise RuntimeError("range not honoured")
                        while pos <= b:
                            if pause is not None and pause.is_set():
                                paused_out = True        # close this connection; reopen from `pos` after the pause
                                break
                            n = min(1 << 18, b - pos + 1)
                            lim = limit() if limit else 0
                            if lim:
                                n = min(n, max(1024, int(lim / 4)))
                                throttle(n)
                            buf = r.read(n)
                            if stop.is_set() or cancel.is_set():
                                return
                            if not buf:
                                break
                            with lock:
                                fd.seek(pos)
                                fd.write(buf)
                                st["done"] += len(buf)
                                partial[idx] = pos + len(buf)
                            pos += len(buf)
                            tries = 0
                    if paused_out:
                        continue
                    if pos <= b:
                        raise RuntimeError("connection closed early")
                except Exception as e:
                    if getattr(e, "code", None) in (401, 403, 404, 410):     # the link expired: needs fresh links
                        st["err"] = e
                        stop.set()
                        return
                    tries += 1
                    if tries > 8:
                        st["err"] = e
                        stop.set()
                        return
                    time.sleep(min(4, tries))
            if pos > b:
                with lock:
                    done_set.add(idx)
                    partial.pop(idx, None)

    FLUSHERS.add(flush)
    with open(path, "r+b", buffering=0) as fd:       # unbuffered: a piece marked finished really is on disk
        ths = [threading.Thread(target=worker, args=(fd,), daemon=True) for _ in range(min(FAST_CONN, max(1, len(todo))))]
        for t in ths:
            t.start()
        samples = deque([(time.time(), st["done"])])
        last_save = time.time()
        try:
            while any(t.is_alive() for t in ths):
                time.sleep(0.5)
                now = time.time()
                with lock:
                    done = st["done"]
                if pause is not None and pause.is_set():
                    samples.clear()
                    samples.append((now, done))
                    report(done, total, 0)
                else:
                    samples.append((now, done))
                    while len(samples) > 2 and now - samples[0][0] > 3:
                        samples.popleft()
                    t0, b0 = samples[0]
                    report(done, total, (done - b0) / (now - t0) if now > t0 else 0)
                if save and now - last_save >= 2:
                    last_save = now
                    with lock:
                        snapshot()
                    save()
        finally:
            stop.set()
            for t in ths:
                t.join(timeout=5)
            FLUSHERS.discard(flush)
            with lock:
                snapshot()
            if save:
                save()
    if cancel.is_set():
        raise JobCancelled()
    if st["err"]:
        raise st["err"]
    if len(done_set) != len(chunks):
        raise RuntimeError("incomplete download")
    state["complete"] = True
    if save:
        save()
    return total


def find_file(work, fid):
    for n in sorted(os.listdir(work)):
        if n.startswith(fid + ".") and not n.endswith((".part", ".ytdl", ".temp", ".tmp")):
            return str(Path(work) / n)
    return None


def _proc_suspend(p, on):
    """freeze / unfreeze a running process (Linux, macOS, Termux, Windows)"""
    try:
        if os.name == "nt":
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x0800, False, p.pid)
            if h:
                (ctypes.windll.ntdll.NtSuspendProcess if on else ctypes.windll.ntdll.NtResumeProcess)(h)
                ctypes.windll.kernel32.CloseHandle(h)
        else:
            os.kill(p.pid, signal.SIGSTOP if on else signal.SIGCONT)
    except Exception:
        pass


def _merge_governor(p, j, stop):
    """Runs next to ffmpeg. j["_mlimit"] = allowed share of full speed in percent (0 = no limit)."""
    frozen = False
    try:
        while not stop.is_set():
            if _up(j):                                   # paused by you: freeze ffmpeg completely
                if not frozen:
                    _proc_suspend(p, True)
                    frozen = True
                stop.wait(0.3)
                continue
            pct = int(j.get("_mlimit") or 0)
            if pct <= 0 or pct >= 100:
                if frozen:
                    _proc_suspend(p, False)
                    frozen = False
                stop.wait(0.3)
                continue
            run = 0.3 * pct / 100.0
            if frozen:
                _proc_suspend(p, False)
                frozen = False
            if stop.wait(run):
                break
            _proc_suspend(p, True)
            frozen = True
            stop.wait(0.3 - run)
    finally:
        if frozen:
            _proc_suspend(p, False)


def run_ffmpeg(j, cmd, dur, field, skey):
    """runs ffmpeg, updates the progress % + that step's own estimate, returns seconds taken"""
    cancel = j["_cancel"]
    t0 = time.time()
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors="replace", bufsize=1)
    except OSError as e:
        ffmpeg_check(True)
        raise RuntimeError("ffmpeg could not start: %s | %s" % (e, FF["msg"]))
    j["_proc"] = p
    gstop = threading.Event()
    threading.Thread(target=_merge_governor, args=(p, j, gstop), daemon=True).start()
    tail = []
    prog_key = re.compile(r"^(frame|fps|stream_\S+|bitrate|total_size|out_time\S*|dup_frames|drop_frames|speed|progress)=")
    try:
        for line in p.stdout:
            if cancel.is_set():
                _proc_suspend(p, False)
                p.terminate()
                break
            line = line.strip()
            m = re.match(r"out_time_(?:us|ms)=(\d+)", line)
            if m:
                if dur:
                    pct = min(99.0, int(m.group(1)) / 1e6 / dur * 100)
                    if field:
                        upd(j, **{field: pct})
                    el = time.time() - t0
                    if skey:
                        if pct >= 3 and el > 1:
                            step(j, skey, "downloading", j["steps"][skey]["text"],
                                 eta=t0 + el * 100 / pct, pct=pct)
                        else:
                            step_pct(j, skey, pct)
            elif line and not prog_key.match(line):
                tail.append(line)
                tail = tail[-6:]
        rc = p.wait()
    finally:
        gstop.set()
        j["_proc"] = None
    if cancel.is_set():
        raise JobCancelled()
    if rc != 0:
        raise RuntimeError("ffmpeg failed: " + " | ".join(tail[-3:]))
    if field:
        upd(j, **{field: 100})
    return time.time() - t0


def copy_with_progress(src, dst, j):
    src, dst = Path(src), Path(dst)
    try:
        os.replace(src, dst)           # same disk: instant
        upd(j, up=100)
        return
    except OSError:
        pass
    total = src.stat().st_size or 1
    done = 0
    try:
        with open(src, "rb") as fi, open(dst, "wb") as fo:
            while True:
                if j["_cancel"].is_set():
                    raise JobCancelled()
                while _up(j):
                    if j["_cancel"].is_set():
                        raise JobCancelled()
                    time.sleep(0.3)
                b = fi.read(1 << 20)
                if not b:
                    break
                fo.write(b)
                done += len(b)
                pct = min(99.0, done * 100 / total)
                upd(j, up=pct)
                step_pct(j, "s", pct)
    except BaseException:
        try:
            dst.unlink()
        except OSError:
            pass
        raise
    src.unlink()
    upd(j, up=100)


def run_job(j):
    if is_ext(str(j.get("vid") or "")):
        return run_ext_job(j)
    jid = j["id"]
    cancel = j["_cancel"]
    ensure_work()
    work = job_work(j) if j.get("work") else (LEGACY_WORK / jid if (LEGACY_WORK / jid).exists() else WORK_DIR / jid)
    j["work"] = str(work)
    work.mkdir(parents=True, exist_ok=True)
    kind = j["kind"]
    v = j.get("v") or {}
    a = j.get("a") or {}
    dur = j.get("duration") or 0
    final = None
    try:
        pl = plan(j)
        with CV:
            j["steps"] = {}
        # every stage gets its own line, its own %, its own time taken and its own estimate
        step_init(j, "p", "Preparing: waiting", pl["p"])
        if kind in ("video", "vonly"):
            step_init(j, "v", "Video stream: waiting", pl["v"])
        if kind in ("video", "audio"):
            step_init(j, "a", "Audio stream: waiting", pl["a"])
        if kind == "video":
            step_init(j, "m", "Merge: waiting", pl["m"])
        if kind == "audio" and a.get("conv"):
            step_init(j, "c", f"Convert to MP3 {a.get('br')}k: waiting", pl["c"])
        step_init(j, "s", "Save to folder: waiting", pl["s"])
        step(j, "p", "downloading", "Preparing: reading video info...", eta=time.time() + pl["p"])


        # ---------------- 1. download the streams ----------------
        want = []
        if kind in ("video", "vonly"):
            want.append(("v", v["id"]))
        if kind in ("video", "audio"):
            want.append(("a", a["src"]))
        fkey = {fid: key for key, fid in want}
        names = {"v": "Video stream", "a": "Audio stream"}
        sizes = {"v": j.get("v_bytes") or 0, "a": j.get("a_bytes") or 0}
        prog, paths, fin = {}, {}, set()
        est = j.get("est_bytes") or (sizes["v"] + sizes["a"])
        first = [False]

        rl_state = {}
        pabort = [False]

        def hook(d):
            if cancel.is_set():
                raise JobCancelled()
            if not d.get("_fast"):
                t_p = None
                while j["_pause"].is_set() or j["_upause"].is_set():     # paused (by you / by the switch)
                    if cancel.is_set():
                        raise JobCancelled()
                    if j["_upause"].is_set():
                        t_p = t_p or time.time()
                        if time.time() - t_p > 2:        # a real pause: stop the transfer completely, carry on later
                            pabort[0] = True
                            raise PauseAbort()
                    time.sleep(0.3)
                lim = j.get("_limit") or 0
                if lim and d.get("status") == "downloading":
                    fid0 = str((d.get("info_dict") or {}).get("format_id") or "")
                    dn0 = d.get("downloaded_bytes") or 0
                    r0 = rl_state
                    if r0.get("lim") != lim or r0.get("fid") != fid0 or dn0 < r0.get("b", 0):
                        r0.update(t=time.time(), b=dn0, lim=lim, fid=fid0)
                    while True:
                        lim = j.get("_limit") or 0
                        if not lim or cancel.is_set() or j["_pause"].is_set() or j["_upause"].is_set():
                            break
                        if r0.get("lim") != lim:
                            r0.update(t=time.time(), b=dn0, lim=lim)
                        need = (dn0 - r0["b"]) / lim - (time.time() - r0["t"])
                        if need <= 0:
                            break
                        time.sleep(min(need, 0.3))
                    if cancel.is_set():
                        raise JobCancelled()
                else:
                    rl_state.clear()
            now = time.time()
            if not first[0]:
                first[0] = True
                step(j, "p", "done", "Preparing: ready \u2713")
            fid = str((d.get("info_dict") or {}).get("format_id") or "")
            key = fkey.get(fid)
            st = d.get("status")
            inst = None                      # live (instantaneous) speed from yt-dlp
            if st == "downloading":
                done = d.get("downloaded_bytes") or 0
                tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                prog[fid] = [done, tot]
                inst = d.get("speed")
                if key:
                    t0 = (j["steps"].get(key) or {}).get("t0") or now
                    el = now - t0
                    total_k = tot or sizes[key]
                    # AVERAGE speed of this stream so far (global average at the very start): used for ETA only
                    rate = done / el if el >= 3 and done > 0 else avg_bps()
                    pct = min(99.9, done * 100 / total_k) if total_k else 0
                    step(j, key, "downloading", f"{names[key]}: downloading...",
                         eta=(now + max(0, total_k - done) / max(rate, 1e4)) if total_k else None,
                         pct=pct, spd=inst or 0)
            elif st == "finished":
                done = d.get("total_bytes") or d.get("downloaded_bytes") or prog.get(fid, [0, 0])[0]
                prog[fid] = [done, done]
                paths[fid] = d.get("filename")
                fin.add(fid)
                inst = 0
                if key:
                    step(j, key, "done", f"{names[key]}: downloaded \u2713")
                    s = j["steps"][key]
                    el = (s.get("t1") or now) - (s.get("t0") or now)
                    if el > 1 and done > 5e4:
                        STAT["dl_b"] += done
                        STAT["dl_s"] += el
            dn = sum(p[0] for p in prog.values())
            known = sum(max(p[0], p[1]) for p in prog.values())
            total = known if len(prog) >= len(want) else max(known, est)
            pct = 100.0 if len(fin) >= len(want) else (min(99.0, dn * 100 / total) if total else 0)
            kw = {"dl": pct, "done_b": dn, "total_b": total}
            if inst is not None:
                kw["speed"] = inst
            upd(j, **kw)

        opts = {
            "format": ",".join(fid for _, fid in want),
            "outtmpl": str(work / "%(format_id)s.%(ext)s"),
            "noplaylist": True,
            "continuedl": True,
            "retries": 8,
            "fragment_retries": 8,
            "concurrent_fragment_downloads": 16,   # fragmented streams: many pieces at once
            "http_chunk_size": 4194304,            # 4 MB ranged requests: every piece starts at full speed, so it stays steady
            "buffersize": 1 << 18,
            "progress_hooks": [hook],
        }
        watch = "https://www.youtube.com/watch?v=" + j["vid"]
        pabort[0] = False

        def wait_resume():
            """a video you paused stays paused here, also while it is only preparing"""
            while _up(j):
                if cancel.is_set():
                    raise JobCancelled()
                time.sleep(0.3)

        def extract():
            with Y({"noplaylist": True, "skip_download": True}, "") as ydl:
                inf = ydl.extract_info(watch, download=False) or {}
            return {str(x.get("format_id")): x for x in (inf.get("formats") or [])}

        try:
            wait_resume()
            # fast path: each stream over several connections at once (falls back to plain yt-dlp on any problem)
            fast = {}
            try:
                fast = extract()
            except Exception:
                if cancel.is_set():
                    raise JobCancelled()
            parts = j.setdefault("parts", {})          # saved in data.json: which pieces of each stream are finished
            for _key, fid in want:
                wait_resume()
                fm = fast.get(fid)
                if not fm or not fast_ok(fm):
                    continue
                fpath = str(work / f"{fid}.{fm.get('ext') or 'bin'}")
                info = {"format_id": fid}
                stt = parts.setdefault(fid, {})
                ok = False
                for attempt in range(3):
                    try:
                        size = fast_download(fm, fpath, cancel, lambda dn, tt, sp, fid=fid, info=info: hook(
                            {"status": "downloading", "downloaded_bytes": dn, "total_bytes": tt,
                             "speed": sp, "info_dict": info, "_fast": True}), Either(j["_pause"], j["_upause"]),
                            lambda: j.get("_limit") or 0, stt, persist)
                        hook({"status": "finished", "filename": fpath, "total_bytes": size, "info_dict": info})
                        ok = True
                        break
                    except JobCancelled:
                        raise
                    except Exception as fe:
                        if cancel.is_set():
                            raise JobCancelled()
                        print("[fast download] format %s, try %d: %s" % (fid, attempt + 1, clean_err(fe)))
                        if attempt == 2:
                            break
                        wait_resume()
                        time.sleep(2)
                        try:
                            fm = extract().get(fid) or fm        # fresh links: the old ones may have expired
                        except Exception:
                            if cancel.is_set():
                                raise JobCancelled()
                if not ok:
                    print("[fast download] using yt-dlp for format %s instead" % fid)
                    prog.pop(fid, None)
                    parts.pop(fid, None)
                    try:
                        os.remove(fpath)
                    except OSError:
                        pass
            left = [fid for _k, fid in want if fid not in fin]
            while left:
                wait_resume()
                opts["format"] = ",".join(left)
                pabort[0] = False
                try:
                    with Y(opts, "") as ydl:
                        ydl.download([watch])
                    break
                except Exception:
                    if cancel.is_set():
                        raise JobCancelled()
                    if pabort[0]:                          # stopped on purpose because you paused it
                        left = [fid for _k, fid in want if fid not in fin]
                        continue
                    raise
        except Exception:
            if cancel.is_set():
                raise JobCancelled()
            raise
        if cancel.is_set():
            raise JobCancelled()
        if not first[0]:
            step(j, "p", "done", "Preparing: ready \u2713")
        files = {}
        for key, fid in want:
            p = paths.get(fid)
            if not p or not os.path.exists(p):
                p = find_file(work, fid)
            if not p:
                raise RuntimeError(f"Download of format {fid} produced no file")
            files[key] = p
            if (j["steps"].get(key) or {}).get("status") != "done":
                step(j, key, "done", f"{names[key]}: downloaded \u2713")
        upd(j, dl=100, speed=0)
        post_gate(j)           # the next video may start downloading while this one merges / saves

        # ---------------- 2. merge / convert ----------------
        if kind == "video":
            fam = v.get("fam")
            h264 = fam == "h264" or j.get("compat")
            need_enc = j.get("compat") and fam != "h264"
            container = "mp4" if h264 else "mkv"
            out = work / f"merged.{container}"
            cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-nostats",
                   "-progress", "pipe:1", "-i", files["v"], "-i", files["a"],
                   "-map", "0:v:0", "-map", "1:a:0"]
            if need_enc:
                cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p"]
            else:
                cmd += ["-c:v", "copy"]
            if a.get("conv"):
                cmd += ["-c:a", "libmp3lame", "-b:a", f"{a.get('br') or 192}k"]
            elif container == "mp4" and a.get("ext") != "m4a":
                cmd += ["-c:a", "aac", "-b:a", "192k"]
            else:
                cmd += ["-c:a", "copy"]
            if container == "mp4":
                cmd += ["-movflags", "+faststart"]
            cmd.append(str(out))
            upd(j, stage="merging", merge=0, speed=0)
            step(j, "m", "downloading",
                 "Merge: converting to H.264 and joining..." if need_enc else "Merge: joining video and audio...",
                 eta=time.time() + pl.get("m", 2), pct=0)
            took = run_ffmpeg(j, cmd, dur, "merge", "m")
            if need_enc and dur and took > 1:
                STAT["enc_m"] += dur
                STAT["enc_s"] += took
            step(j, "m", "done", "Merge: finished \u2713")
            ext = container
        elif kind == "vonly":
            out = Path(files["v"])
            ext = out.suffix.lstrip(".") or "mp4"
        else:
            if a.get("conv"):
                out = work / "audio.mp3"
                upd(j, stage="merging", merge=0, speed=0)
                step(j, "c", "downloading", f"Convert to MP3 {a.get('br')}k: working...",
                     eta=time.time() + pl.get("c", 2), pct=0)
                run_ffmpeg(j, ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-nostats",
                               "-progress", "pipe:1", "-i", files["a"], "-vn",
                               "-c:a", "libmp3lame", "-b:a", f"{a.get('br') or 192}k", str(out)],
                           dur, "merge", "c")
                step(j, "c", "done", "Convert: finished \u2713")
                ext = "mp3"
            else:
                out = Path(files["a"])
                ext = out.suffix.lstrip(".") or a.get("ext") or "m4a"

        # ---------------- 3. save into the chosen folder ----------------
        ql = a.get("label") if kind == "audio" else v.get("label") if kind == "vonly" \
            else f"{v.get('label')} + {a.get('label')}"
        name = f"{safe_name(j['title'], 150)}.{ext}"
        dest = Path(j.get("dest") or OUTPUT_DIR)
        try:
            dest.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(f"Cannot use the folder {dest}: {e}")
        final = unique_path(dest / name)
        upd(j, stage="uploading", up=0, speed=0)
        step(j, "s", "downloading", "Save to folder: working...", eta=time.time() + pl.get("s", 1), pct=0)
        copy_with_progress(out, final, j)
        step(j, "s", "done", "Save to folder: finished \u2713")
        shutil.rmtree(work, ignore_errors=True)
        keep = KEEP_AUDIO if kind == "audio" else KEEP_VIDEO
        now = time.time()
        upd(j, stage="done", finished=now, file=str(final), path=str(final), note="",
            dl=100, merge=100, up=100, speed=0,
            expires_at=(now + keep * 3600) if keep else None)
    except JobCancelled:
        if final:
            try:
                Path(final).unlink()
            except OSError:
                pass
        shutil.rmtree(work, ignore_errors=True)
        upd(j, stage="cancelled", note="", speed=0)
    except Exception as exc:
        msg = clean_err(exc)
        for k, s in list(j["steps"].items()):
            if s["status"] == "downloading":
                step(j, k, "error", s["text"])
        upd(j, stage="error", note=msg, speed=0)
    finally:
        j["_proc"] = None
        persist()


def _begin(j):
    """mark a queued job as started (called with CV held)"""
    j["stage"] = "downloading"
    j["started"] = time.time()
    j["finished"] = None
    j["note"] = ""
    j["dl"] = j["merge"] = j["up"] = 0
    j["done_b"] = 0
    j["speed"] = 0
    j["total_b"] = j.get("est_bytes") or 0
    j["_cancel"].clear()
    j["_pause"].clear()
    j["_limit"] = 0
    j["_mlimit"] = 0
    j["_phase"] = "dl"
    if not (j.get("work") and Path(j["work"]).exists()):
        j["work"] = ""


def dl_cap():
    """how many videos may download at the same time"""
    if SET["par_dl"]:
        return max(1, int(SET["par_n"]))
    return 2 if SET["smart"] else 1


def post_cap():
    """how many videos may merge / save at the same time"""
    return max(1, int(SET["merge_n"])) if SET["par_merge"] else 1


def _count(phase):
    return sum(1 for x in JOBS.values() if x.get("_phase") == phase)


def post_gate(j):
    """Called when a video has finished downloading. Frees its download slot (so the next video can
    start) and waits for a free merge / save slot."""
    cancel = j["_cancel"]
    shown = False
    with CV:
        j["_phase"] = "wait"
        CV.notify_all()
        while True:
            if cancel.is_set():
                raise JobCancelled()
            ok = _count("post") < post_cap() and (SET["dl_merge"] or _count("dl") == 0)
            if ok:
                j["_phase"] = "post"
                CV.notify_all()
                break
            if not shown:
                shown = True
                a = j.get("a") or {}
                j["stage"] = "merging" if (j["kind"] == "video" or (j["kind"] == "audio" and a.get("conv"))) \
                    else "uploading"
                j["note"] = "Waiting for its turn"
                j["speed"] = 0
                j["updated"] = time.time()
            CV.wait(0.5)
    if shown:
        upd(j, note="")


def _run_thread(j):
    try:
        run_job(j)
    except Exception as exc:       # never let a job thread die silently
        upd(j, stage="error", note=clean_err(exc), speed=0)
    finally:
        with CV:
            j["_phase"] = None
            CV.notify_all()


def dispatcher():
    """Starts queued videos in order. Downloads: 1 at a time (more only if allowed in Settings or if the
    slow-download switch asks for it). Merging / saving of a finished video runs next to the next download."""
    while True:
        with CV:
            while True:
                j = None
                que = [x for x in JOBS.values() if x["stage"] == "queued" and not _up(x)]
                if que and not MAINT["on"]:
                    n_dl = sum(1 for x in JOBS.values() if x.get("_phase") == "dl" and not _up(x))
                    ok = n_dl < dl_cap()
                    if ok and not SET["dl_merge"] and (_count("wait") or _count("post")):
                        ok = False
                    if ok and n_dl > 0 and not SET["par_dl"]:
                        ok = bool(SET["smart"] and SMART["go"])
                    if ok:
                        j = min(que, key=lambda x: x["qseq"])
                        _begin(j)
                        if n_dl > 0 and not SET["par_dl"]:
                            SMART["go"] = False
                        break
                CV.wait(1.0)
        persist()
        threading.Thread(target=_run_thread, args=(j,), daemon=True).start()


def _apply(j, pause, limit, note, merge=0):
    """slow one video down: limit = download speed in bytes/s, merge = share of full merge speed in percent
    (0 = full speed). Nothing is ever frozen completely."""
    new = (bool(pause), int(limit or 0), int(merge or 0))
    cur = (j["_pause"].is_set(), int(j.get("_limit") or 0), int(j.get("_mlimit") or 0))
    held = new != (False, 0, 0)
    if cur == new and (not held or j.get("note") == note):
        return
    if new[0]:
        j["_pause"].set()
    else:
        j["_pause"].clear()
    j["_limit"] = new[1]
    j["_mlimit"] = new[2]
    if held:
        upd(j, note=note, speed=0 if new[0] else (j.get("speed") or 0))
        j["_rnote"] = note
    else:
        if j.get("_rnote") and j.get("note") == j["_rnote"]:
            upd(j, note="")
        j["_rnote"] = ""


def rate_tick(st):
    """Decides, every second, which videos run at full speed. Order = the order the videos were selected
    (playlist order): first, second, third ...
    DOWNLOADS: as many videos as 'several at once' allows run at full speed (1 normally, 2 with auto-switch).
      Every further video that is already downloading is slowed down (Settings: speed of extra videos).
      Auto-switch (only when 'several at once' is off): if the first video stays below the minimum speed for the
      wait time, the second one starts too; when the first is fast again for the wait time, the second one is
      limited (Settings: second video speed) until the first is slow again.
    MERGES: as many merges as 'merge several at once' allows run at full speed; further merges that are already
      running are slowed to a share of full speed (Settings).
    If 'download while merging' is off but both are running, the older video wins and the other side is slowed."""
    with CV:
        live = sorted((j for j in JOBS.values() if j["stage"] == "downloading" and not _up(j)), key=lambda x: x["qseq"])
        posts = sorted((j for j in JOBS.values() if j.get("_phase") == "post"), key=lambda x: x["qseq"])
        queued = any(j["stage"] == "queued" and not _up(j) for j in JOBS.values())
        alljobs = list(JOBS.values())
    SMART["info"] = None
    busy = {j["id"] for j in live} | {j["id"] for j in posts}
    for j in alljobs:
        if j["id"] not in busy:
            _apply(j, False, 0, "")
    cap = dl_cap()
    smart_on = bool(SET["smart"]) and not SET["par_dl"]
    extra_bps = int(SET["extra_kb"] * 1000)
    second_bps = int(SET["second_kb"] * 1000)
    pct = int(SET["merge_pct"])
    # download while merging switched off, but both are running: the older video keeps full speed
    conf_dl = conf_post = False
    if not SET["dl_merge"] and live and posts:
        if posts[0]["qseq"] < live[0]["qseq"]:
            conf_dl = True
        else:
            conf_post = True
    for i, j in enumerate(posts):
        if conf_post or i >= post_cap():
            _apply(j, False, 0, "Slowed to %d%% speed: merging is limited" % pct, pct)
        else:
            _apply(j, False, 0, "")
    if not live:
        SMART["go"] = False
        st.update(pid=None, slow=None, fast=None, held=False)
        return
    now = time.time()
    prim = live[0]
    if st.get("pid") != prim["id"]:
        st.update(pid=prim["id"], slow=None, fast=None, held=False, sm=None)
    wait = SET["wait_s"]
    slow_long = fast_long = False
    if smart_on:
        isdl = (prim.get("done_b") or 0) > 0
        cur = float(prim.get("speed") or 0)
        sm = st.get("sm")
        st["sm"] = cur if sm is None else sm * 0.75 + cur * 0.25      # smoothed: one slow second does not count
        thr = SET["min_mb"] * 1e6
        if len(live) > 1:
            thr *= RECOVER_FACTOR          # a second video is running: ONE steady limit of 50% of the minimum (no flip-flop)
        if isdl and st["sm"] < thr:
            st["slow"] = st.get("slow") or now
            st["fast"] = None
        elif isdl:
            st["fast"] = st.get("fast") or now
            st["slow"] = None
        else:
            st["slow"] = st["fast"] = None
            st["held"] = False
        slow_long = bool(st.get("slow")) and now - st["slow"] >= wait
        fast_long = bool(st.get("fast")) and now - st["fast"] >= wait
        if fast_long:
            st["held"] = True
        elif slow_long:
            st["held"] = False
    else:
        st.update(slow=None, fast=None, held=False)
    for i, j in enumerate(live):
        if conf_dl or i >= cap:
            _apply(j, False, extra_bps, "Slowed to %d KB/s: only the first video downloads at full speed" % SET["extra_kb"])
        elif i >= 1 and smart_on and st.get("held"):
            _apply(j, False, second_bps, "Limited to %d KB/s: the first video is downloading fast" % SET["second_kb"])
        else:
            _apply(j, False, 0, "")
    can_start = queued and len(live) < cap
    SMART["go"] = bool(smart_on and slow_long and can_start)
    info = None
    if smart_on:
        others = live[1:cap]
        if st.get("slow"):
            left = max(0, int(wait - (now - st["slow"]) + 0.99))
            if others and st.get("held"):
                info = {"kind": "resume", "left": left}
            elif not others and can_start:
                info = {"kind": "switch", "left": left}
        elif st.get("fast") and others and not st.get("held"):
            info = {"kind": "pause", "left": max(0, int(wait - (now - st["fast"]) + 0.99))}
    SMART["info"] = info
    if SMART["go"]:
        with CV:
            CV.notify_all()


def smart_loop():
    st = {}
    last = ""
    while True:
        time.sleep(1)
        try:
            rate_tick(st)
        except Exception:
            tb = traceback.format_exc()
            if tb != last:                 # show a problem once in the console instead of hiding it
                last = tb
                print("[speed control] " + tb)


# ---- speed history (for the graph that opens when you click the speed on the page)
SPEED = {"pts": deque(maxlen=21600), "total": 0, "t0": time.time(), "last": {}}     # pts: (time, bytes/s, bytes)
SPEED_LOCK = threading.Lock()


def sampler():
    last_t = time.time()
    while True:
        time.sleep(1)
        now = time.time()
        dt = max(0.2, now - last_t)
        last_t = now
        b = 0
        with CV:
            for j in list(JOBS.values()):
                d = j.get("done_b") or 0
                jid = j["id"]
                if j["stage"] == "downloading":
                    prev = SPEED["last"].get(jid, 0)
                    if d > prev:
                        b += d - prev
                    SPEED["last"][jid] = d
                elif jid in SPEED["last"]:
                    prev = SPEED["last"].pop(jid)
                    if d > prev:
                        b += d - prev
        with SPEED_LOCK:
            SPEED["pts"].append((now, b / dt, b))
            SPEED["total"] += b


def api_speedlog(qs):
    secs = min(21600, max(30, _int(qs.get("secs"), 300)))
    now = time.time()
    lo = now - secs
    with SPEED_LOCK:
        raw = [p for p in SPEED["pts"] if p[0] >= lo]
        total = SPEED["total"]
    bucket = max(1, -(-secs // 300))
    acc = {}
    for t, bps, by in raw:
        k = int((t - lo) // bucket)
        a = acc.setdefault(k, [0.0, 0])
        a[0] += bps
        a[1] += 1
    pts = [[round(lo + k * bucket + bucket / 2, 1), round(v[0] / v[1])] for k, v in sorted(acc.items())]
    used = sum(p[2] for p in raw)
    return {"now": now, "secs": secs, "bucket": bucket, "points": pts,
            "range_bytes": used, "total_bytes": total, "since": SPEED["t0"],
            "peak": max((p[1] for p in raw), default=0),
            "avg": used / max(1.0, min(secs, now - SPEED["t0"]))}


def sweeper():
    while True:
        time.sleep(30)
        now = time.time()
        with CV:
            due = [j for j in JOBS.values()
                   if j["stage"] == "done" and j.get("expires_at") and j["expires_at"] <= now]
        for j in due:
            try:
                Path(j["file"]).unlink()
            except OSError:
                pass
            upd(j, stage="expired")
        if due:
            persist()


# ----------------------------------------------------------------------------
# job actions
# ----------------------------------------------------------------------------
def cancel_job(j):
    with CV:
        st = j["stage"]
        if st in ("queued", "confirm", "error"):
            j["stage"] = "cancelled"
            j["note"] = ""
        elif st in LIVE and st != "cancelling":
            j["stage"] = "cancelling"
            j["_cancel"].set()
            j["_upause"].clear()
            j["paused"] = False
            p = j.get("_proc")
            if p:
                try:
                    p.terminate()
                except Exception:
                    pass
        else:
            return
        cancelled = j["stage"] == "cancelled"
    if cancelled:
        shutil.rmtree(job_work(j), ignore_errors=True)


def resume_job(j):
    with CV:
        if j["stage"] not in ("confirm", "error"):
            return
        j["stage"] = "queued"
        j["note"] = ""
        j["qseq"] = NEXT_Q[0]
        NEXT_Q[0] += 1
        j["_cancel"].clear()
        CV.notify_all()


def skip_job(j):
    with CV:
        if j["stage"] not in ("confirm", "error"):
            return
        ok = bool(j.get("file") and Path(j["file"]).exists())
        j["stage"] = "done" if ok else "cancelled"
        j["note"] = ""
        if ok:
            j["finished"] = j.get("finished") or time.time()
    if not ok:
        shutil.rmtree(job_work(j), ignore_errors=True)


def delete_job_file(j):
    with CV:
        if j["stage"] != "done":
            return
    try:
        Path(j["file"]).unlink()
    except OSError:
        pass
    upd(j, stage="deleted")


PAUSE_NOTE_U = "Paused by you"


def pause_job(j, on):
    with CV:
        if on:
            if j["stage"] not in LIVE and j["stage"] != "queued" or j["stage"] == "cancelling":
                return
            if j["_upause"].is_set():
                return
            j["_upause"].set()
            j["paused"] = True
            j["note"] = PAUSE_NOTE_U
            j["speed"] = 0
            j["updated"] = time.time()
        else:
            if not j["_upause"].is_set():
                return
            j["_upause"].clear()
            j["paused"] = False
            if j.get("note") == PAUSE_NOTE_U:
                j["note"] = ""
            j["updated"] = time.time()
        CV.notify_all()


def do_job_action(jid, what):
    with CV:
        j = JOBS.get(jid)
    if not j:
        raise ApiError("Unknown download", 404)
    if what == "resume":
        resume_job(j)
    elif what == "skip":
        skip_job(j)
    elif what == "cancel":
        cancel_job(j)
    elif what == "pause":
        pause_job(j, True)
    elif what == "unpause":
        pause_job(j, False)
    elif what == "delete":
        delete_job_file(j)
    else:
        raise ApiError("Unknown action", 404)
    persist()


def do_bulk(what):
    with CV:
        jobs = sorted(JOBS.values(), key=lambda x: x["qseq"])
    if what == "pause_all":
        for j in jobs:
            pause_job(j, True)
    elif what == "unpause_all":
        for j in jobs:
            pause_job(j, False)
    elif what == "cancel_all":
        for j in jobs:
            if j["stage"] not in END:
                cancel_job(j)
    elif what == "resume_all":
        for j in jobs:
            resume_job(j)
    elif what == "clear":
        with CV:
            gone = [j for j in JOBS.values() if j["stage"] in CLEARABLE]
            for j in gone:
                JOBS.pop(j["id"], None)
        for j in gone:
            shutil.rmtree(job_work(j), ignore_errors=True)
    persist()


def start_downloads(body):
    items = body.get("items")
    if not isinstance(items, list) or not items:
        raise ApiError("Nothing to download")
    cache, jobs = {}, []
    for it in items[:2000]:
        if not isinstance(it, dict):
            raise ApiError("Bad request")
        d = it.get("dest") if isinstance(it.get("dest"), dict) else {}
        key = (str(d.get("base") or "").strip(), str(d.get("sub") or "").strip())
        if key not in cache:
            cache[key] = resolve_dest(*key)
        jobs.append(make_job(it, body.get("compat"), body.get("playlist"), cache[key]))
    with CV:
        for j in jobs:
            JOBS[j["id"]] = j
        CV.notify_all()
    persist()
    return {"ok": True, "count": len(jobs)}


# ----------------------------------------------------------------------------
# HTTP server
# ----------------------------------------------------------------------------
LOOPBACK = {"localhost", "127.0.0.1", "[::1]", "::1"}
BIND_HOST = "127.0.0.1"

SW_JS = """
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
async function tell(msg){
  const all=await self.clients.matchAll({type:'window',includeUncontrolled:true});
  all.forEach(c=>c.postMessage(msg));
  return all;
}
self.addEventListener('notificationclose',e=>{e.waitUntil(tell({type:'note-closed'}))});
self.addEventListener('notificationclick',e=>{
  e.waitUntil((async()=>{
    const all=await tell({type:'note-closed'});
    for(const c of all){ if('focus' in c){ return c.focus(); } }
    if(self.clients.openWindow){ return self.clients.openWindow('/'); }
  })());
});
"""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "TubeLocal"

    def log_message(self, *a):
        pass

    # -- plumbing
    def _send(self, code, body, ctype, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8")

    def _guard(self):
        hh = self.headers.get("Host") or ""
        host = (hh.split("]")[0] + "]") if hh.startswith("[") else hh.rsplit(":", 1)[0]
        if BIND_HOST in LOOPBACK and host not in LOOPBACK:
            self._json({"error": "Forbidden host"}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and up.urlsplit(origin).netloc != self.headers.get("Host"):
            self._json({"error": "Forbidden origin"}, 403)
            return False
        return True

    def _stream(self, host):
        """live job updates, pushed once a second (not slowed down when the tab is in the background)"""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.close_connection = True
        try:
            while True:
                data = json.dumps(jobs_payload(host)).encode("utf-8")
                self.wfile.write(b"data: " + data + b"\n\n")
                self.wfile.flush()
                time.sleep(1)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def _route(self, method):
        if not self._guard():
            return
        u = up.urlsplit(self.path)
        qs = dict(up.parse_qsl(u.query))
        country = qs.get("country", "").upper()
        if not re.fullmatch(r"[A-Z]{2}", country):
            country = ""
        path = u.path
        host = self.headers.get("Host") or f"127.0.0.1:{self.server.server_address[1]}"
        try:
            if method in ("GET", "HEAD"):
                if path in ("/", "/index.html"):
                    return self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
                if path == "/favicon.ico":
                    return self._send(204, b"", "image/x-icon")
                if path == "/sw.js":
                    return self._send(200, SW_JS.encode("utf-8"), "application/javascript; charset=utf-8",
                                      {"Service-Worker-Allowed": "/"})
                if path == "/api/ping":
                    return self._json({"ok": True, "keep": {"video": KEEP_VIDEO, "audio": KEEP_AUDIO},
                                       "free": free_bytes(), "dl_bps": avg_bps(),
                                       "out": str(OUTPUT_DIR), "ffmpeg": have_ffmpeg(),
                                       "ytdlp": ytdlp_version(), "health": HEALTH["state"]})
                if path == "/api/stream":
                    return self._stream(host)
                if path == "/api/settings":
                    return self._json(api_settings_get())
                if path == "/api/browse":
                    return self._json(api_browse(qs))
                if path == "/api/ytdlp":
                    return self._json(ytdlp_status())
                if path == "/api/search":
                    return self._json(api_search(qs, country))
                if path == "/api/playlist":
                    return self._json(api_playlist(qs, country))
                if path == "/api/formats":
                    vid = qs.get("id") or ""
                    if not VID_OK.fullmatch(vid):
                        raise ApiError("Bad video id")
                    return self._json(get_formats(vid, country))
                if path == "/api/speedlog":
                    return self._json(api_speedlog(qs))
                if path == "/api/jobs":
                    return self._json(jobs_payload(host))
                if path == "/api/sites":
                    return self._json({"items": sites_list()})
                if path == "/api/channels":
                    return self._json(api_channels(qs, country))
                if path == "/api/channel":
                    return self._json(api_channel(qs, country))
                if path == "/api/history":
                    return self._json({"items": list(HISTORY)})
                if path == "/api/library":
                    return self._json({"items": scan_library()})
                if path == "/api/health":
                    return self._json({"state": HEALTH["state"]})
                m = re.fullmatch(r"/lib/([0-9a-f]{12})", path)
                if m:
                    p = LIBMAP.get(m.group(1))
                    if not p or not os.path.isfile(p):
                        raise ApiError("File not found", 404)
                    return self._serve(p)
                m = re.fullmatch(r"/files/([0-9a-f]{12})", path)
                if m:
                    return self._file(m.group(1))
            elif method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                if n > 30_000_000:
                    raise ApiError("Request too large", 413)
                raw = self.rfile.read(n) if n else b""

                def body():
                    try:
                        b = json.loads(raw.decode("utf-8") or "{}")
                    except ValueError:
                        raise ApiError("Bad request")
                    if not isinstance(b, dict):
                        raise ApiError("Bad request")
                    return b

                if path == "/api/download":
                    return self._json(start_downloads(body()))
                if path == "/api/settings":
                    return self._json(api_settings_set(body()))
                if path == "/api/mkdir":
                    return self._json(api_mkdir(body()))
                if path == "/api/history":
                    hist_add(body().get("q"))
                    return self._json({"items": list(HISTORY)})
                if path == "/api/history/del":
                    hist_del(str(body().get("q") or ""))
                    return self._json({"items": list(HISTORY)})
                if path == "/api/history/clear":
                    hist_del(None)
                    return self._json({"items": []})
                if path == "/api/library/delete":
                    lib_delete(str(body().get("id") or ""))
                    return self._json({"ok": True})
                if path == "/api/health/retry":
                    if HEALTH["state"] in ("busy", "offline", "ok"):
                        HEALTH["state"] = "idle"
                    return self._json({"ok": True})
                if path == "/api/ytdlp/reinstall":
                    return self._json(start_reinstall())
                if path in ("/api/jobs/cancel_all", "/api/jobs/resume_all", "/api/jobs/clear",
                            "/api/jobs/pause_all", "/api/jobs/unpause_all"):
                    do_bulk(path.rsplit("/", 1)[1])
                    return self._json({"ok": True})
                m = re.fullmatch(r"/api/jobs/([0-9a-f]{12})/(\w+)", path)
                if m:
                    do_job_action(m.group(1), m.group(2))
                    return self._json({"ok": True})
            self._json({"error": "Not found"}, 404)
        except ApiError as e:
            self._json({"error": str(e)}, e.code)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self._json({"error": clean_err(e)}, 500)
            except Exception:
                pass

    def do_GET(self):
        self._route("GET")

    def do_HEAD(self):
        self._route("HEAD")

    def do_POST(self):
        self._route("POST")

    # -- finished files (with Range support so videos can be played / resumed)
    def _file(self, jid):
        with CV:
            j = JOBS.get(jid)
        if not j or j["stage"] != "done" or not j.get("file") or not os.path.isfile(j["file"]):
            raise ApiError("File not found", 404)
        return self._serve(j["file"])

    def _serve(self, path):
        size = os.path.getsize(path)
        start, end, code = 0, size - 1, 200
        rng = self.headers.get("Range")
        if rng:
            m = re.fullmatch(r"bytes=(\d*)-(\d*)", rng.strip())
            if m and (m.group(1) or m.group(2)):
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                else:
                    start = max(0, size - int(m.group(2)))
                end = min(end, size - 1)
                if start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                code = 206
        ctype = mimetypes.guess_type(path)[0] or {
            ".mkv": "video/x-matroska", ".m4a": "audio/mp4", ".opus": "audio/ogg"}.get(
            Path(path).suffix.lower(), "application/octet-stream")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Disposition",
                         "inline; filename*=UTF-8''" + up.quote(Path(path).name))
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    b = f.read(min(1 << 18, left))
                    if not b:
                        break
                    self.wfile.write(b)
                    left -= len(b)
        except (BrokenPipeError, ConnectionResetError):
            pass


def open_browser(url):
    try:
        if shutil.which("termux-open-url"):
            subprocess.Popen(["termux-open-url", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            webbrowser.open(url)
    except Exception:
        pass


def main():
    global BIND_HOST
    ap = argparse.ArgumentParser(description="Tube to Drive - local edition")
    ap.add_argument("--out", default=None)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--keep-video-hours", type=float, default=None)
    ap.add_argument("--keep-audio-hours", type=float, default=None)
    args = ap.parse_args()

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    load_settings()
    load_history()
    if args.out:
        SET["out"] = args.out
    if args.keep_video_hours is not None:
        SET["keep_video"] = max(0.0, args.keep_video_hours)
    if args.keep_audio_hours is not None:
        SET["keep_audio"] = max(0.0, args.keep_audio_hours)
    apply_settings()
    try:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"WARNING: cannot use the save folder {OUTPUT_DIR} ({e}). Using the default folder instead.")
        SET["out"] = ""
        apply_settings()
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ensure_work()
    BIND_HOST = args.host

    load_jobs()
    persist()          # creates / updates data.json right away
    threading.Thread(target=dispatcher, daemon=True).start()
    threading.Thread(target=smart_loop, daemon=True).start()
    threading.Thread(target=sampler, daemon=True).start()
    threading.Thread(target=sweeper, daemon=True).start()
    threading.Thread(target=auto_update_loop, daemon=True).start()
    threading.Thread(target=health_loop, daemon=True).start()

    srv = None
    for port in range(args.port, args.port + 25):
        try:
            srv = ThreadingHTTPServer((args.host, port), Handler)
            break
        except OSError:
            continue
    if not srv:
        print("Could not open a local port. Use --port to choose another one.")
        sys.exit(1)
    srv.daemon_threads = True
    url = f"http://{'127.0.0.1' if args.host in ('0.0.0.0', '') else args.host}:{port}/"

    print("-" * 58)
    print("               TUBE TO DRIVE  (local edition)")
    print("-" * 58)
    print(f"Open this page : {url}")
    print(f"Files saved in : {OUTPUT_DIR}")
    if yt_dlp:
        print(f"yt-dlp         : {ytdlp_version()}")
    else:
        print("yt-dlp         : NOT INSTALLED (the app installs it automatically)")
    if not have_ffmpeg():
        print("WARNING: ffmpeg not found. Merging and MP3 conversion need it (Termux: pkg install ffmpeg).")
    if not (shutil.which("deno") or shutil.which("node")):
        print("Tip: if some YouTube formats are missing, install deno or nodejs (Termux: pkg install nodejs).")
    if args.host not in LOOPBACK:
        print("NOTE: the page is open to your network. Anyone who can reach it can browse folders and change settings.")
    print("Press Ctrl+C to stop.\n")
    if not args.no_browser:
        threading.Timer(0.8, open_browser, args=(url,)).start()
    try:
        for sg in ("SIGTERM", "SIGHUP"):
            if hasattr(signal, sg):
                try:
                    signal.signal(getattr(signal, sg), lambda *a: (_ for _ in ()).throw(KeyboardInterrupt()))
                except Exception:
                    pass
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped. Unfinished downloads can be continued next time.")
    finally:
        persist()
        srv.server_close()


# ----------------------------------------------------------------------------
# the page
# ----------------------------------------------------------------------------
PAGE = r'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CONTENT DOWNLOADER</title>
<style>
:root{--bg:#e9eef5;--card:#fff;--ink:#16233b;--mut:#5d6b82;--line:#d3dbe7;--acc:#2f4bff;--ok:#15935a;--bad:#d6334a;--warn:#b7791f}
*{box-sizing:border-box}
[hidden]{display:none!important}
body{margin:0;background:var(--bg);color:var(--ink);font:13px/1.4 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;padding-bottom:70px}
h1,h2,h3{font-family:system-ui,sans-serif;margin:0}
.wrap{max-width:1040px;margin:0 auto;padding:16px}
header{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:12px}
h1{font-size:34px;font-weight:800;letter-spacing:-1px}
.hr{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.pill{display:inline-flex;gap:8px;align-items:center;padding:6px 12px;border-radius:99px;background:var(--card);border:1px solid var(--line);font-weight:500}
.pill.spd{color:var(--acc);font-weight:600}
.dot{width:10px;height:10px;border-radius:50%;background:var(--bad)}.on .dot{background:var(--ok)}
.ibtn{width:38px;height:38px;padding:0;display:inline-flex;align-items:center;justify-content:center;background:#fff;color:var(--ink);border:1px solid var(--line);border-radius:50%}
.ibtn svg{width:19px;height:19px}.ibtn.on{background:var(--acc);color:#fff;border-color:var(--acc)}
.banner{display:none;background:var(--bad);color:#fff;padding:12px 14px;border-radius:10px;margin-bottom:12px}
.offline .banner{display:block}
.offline .need{opacity:.45;pointer-events:none}
.row{display:flex;gap:8px;flex-wrap:wrap}
input[type=text],input[type=number],select{font:inherit;padding:11px 12px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--ink)}
input[type=text]{flex:1;min-width:160px}
input[type=number]{width:100%}
button{font:inherit;font-weight:600;border:0;border-radius:10px;padding:10px 14px;background:var(--acc);color:#fff;cursor:pointer}
button.alt{background:#fff;color:var(--ink);border:1px solid var(--line)}
button.sm{padding:5px 10px;font-size:13px}
button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #9fb0ff;outline-offset:1px}
button:disabled{opacity:.5}
section{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;margin-top:14px}
section>h2{font-size:20px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:8px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px}
.vid img{width:100%;border-radius:10px;aspect-ratio:16/9;object-fit:cover;background:#cfd8e6}
.vid h3{font-size:15px;margin:8px 0 2px;line-height:1.25;font-weight:700}
.mut{color:var(--mut);font-size:13px}
.vid .row{margin-top:8px}.vid button{flex:1;padding:8px}
.overlay{position:fixed;inset:0;background:rgba(15,25,45,.6);display:none;align-items:flex-start;justify-content:center;overflow:auto;padding:16px;z-index:9}
.overlay.show{display:flex}
#ov2{z-index:12}
.modal{background:#fff;border-radius:14px;padding:14px;width:100%;max-width:760px}
.modal iframe{width:100%;aspect-ratio:16/9;border:0;border-radius:10px}
.modal.wide{max-width:900px}
table{width:100%;border-collapse:collapse;font-size:14px}
td,th{padding:7px 6px;border-bottom:1px solid var(--line);text-align:left}
.tag{padding:1px 7px;border-radius:6px;font-size:12px;font-weight:600}
.tv{background:#e3e8ff;color:#2437b8}.ta{background:#d9f3e6;color:#0e6b42}.tm{background:#fdeccb;color:#8a5a0b}
.job{display:grid;grid-template-columns:96px 1fr;gap:10px;padding:10px 0;border-bottom:1px solid var(--line)}
.job img{width:96px;border-radius:8px;aspect-ratio:16/9;object-fit:cover}
.bar{height:9px;background:#e3e9f3;border-radius:9px;overflow:hidden}
.bar i{display:block;height:100%;background:var(--acc);width:0;transition:width .4s}
.bar.s{height:6px;margin-top:3px}
.bar.m i{background:var(--warn)}.bar.u i{background:var(--ok)}.bar.d i{background:var(--ok)}
.st{margin-top:7px;font-size:13px}
.sl{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap}
.sl .sr{color:var(--mut)}
.err{color:var(--bad);font-weight:500}
.lnk{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
.lnk a,.lnk button{padding:6px 10px;font-size:13px;border-radius:8px;text-decoration:none;background:var(--ok);color:#fff;border:0}
.lnk button{background:#fff;color:var(--ink);border:1px solid var(--line)}
.lk{display:flex;gap:6px;align-items:center;margin-top:6px}.lk a{background:var(--ok);color:#fff;text-decoration:none;padding:6px 10px;border-radius:8px;font-size:13px;font-weight:600}.lk button{padding:6px 10px;font-size:13px;background:#fff;color:var(--ink);border:1px solid var(--line)}
.ok{color:var(--ok);font-weight:500}.run{color:var(--acc);font-weight:600}
.ask{background:#fff6e0;border:1px solid #ecd28a;border-radius:10px;padding:10px;margin:8px 0}
.empty{color:var(--mut);padding:6px 0}
.ql{margin:2px 0}
#qsum{background:#eef2ff;border:1px solid #c9d2ff;border-radius:10px;padding:10px;margin-bottom:8px}
@media(prefers-reduced-motion:reduce){.bar i{transition:none}}

/* search bar */
.sbar{display:flex;gap:8px}
.sb{position:relative;flex:1;min-width:0}
.sb input[type=text]{width:100%;min-width:0;padding-right:48px}
.attach{position:absolute;right:5px;top:50%;transform:translateY(-50%);width:34px;height:34px;padding:0;display:inline-flex;align-items:center;justify-content:center;background:#eef2ff;color:var(--acc);border:1px solid #c9d2ff;border-radius:9px}
.attach:hover{background:var(--acc);color:#fff}
.attach svg{width:17px;height:17px}
.tools{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px}
.tg,button.tg{display:inline-flex;gap:7px;align-items:center;padding:7px 12px;border:1px solid var(--line);border-radius:99px;background:#fff;color:var(--ink);font-weight:600;font-size:14px;cursor:pointer;user-select:none}
.tg.on,button.tg.on{border-color:var(--acc);background:#eef2ff;color:#2437b8}
.tg input{width:16px;height:16px;margin:0;accent-color:var(--acc)}
.tg svg{width:16px;height:16px}
.cnt{background:var(--acc);color:#fff;border-radius:99px;font-size:12px;padding:0 7px;line-height:18px}
.fpanel{margin-top:10px;padding:12px;border:1px solid var(--line);border-radius:12px;background:#f6f8fc;display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;align-items:end}
.fpanel label{display:flex;flex-direction:column;gap:4px;font-size:13px;color:var(--mut);font-weight:500}
.fpanel select{width:100%}
.drop{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(47,75,255,.12);border:4px dashed var(--acc);font:800 22px system-ui,sans-serif;color:var(--acc);z-index:20;pointer-events:none}
.drop.show{display:flex}

/* cards + selection */
.vid{position:relative}.vid.sel .th img{outline:3px solid var(--acc)}.th{position:relative}
.pick{position:absolute;top:8px;left:8px;width:22px;height:22px}
.badge{position:absolute;right:6px;bottom:6px;background:rgba(0,0,0,.75);color:#fff;border-radius:6px;padding:1px 6px;font-size:12px}
.badge.dup{left:6px;right:auto;background:var(--ok);max-width:75%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.selbar{position:fixed;left:0;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);padding:10px 16px;display:none;gap:8px;align-items:center;flex-wrap:wrap;z-index:8}
.selbar.show{display:flex}.selbar b{margin-right:auto}
.seg button{background:#fff;color:var(--ink);border:1px solid var(--line)}.seg button.on{background:var(--acc);color:#fff;border-color:var(--acc)}

/* quality window */
.strip{display:flex;gap:8px;overflow-x:auto;padding:8px 0}
.chip{position:relative;flex:0 0 130px;border:2px solid var(--line);border-radius:10px;padding:4px;font-size:12px}.chip.pick1{cursor:pointer}.chip.on{border-color:var(--acc)}
.chip img{width:100%;border-radius:6px;aspect-ratio:16/9;object-fit:cover}.chip div{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.chip .x{position:absolute;top:2px;right:2px;width:22px;height:22px;padding:0;border-radius:50%;background:var(--bad);color:#fff;line-height:1;z-index:1}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:10px}@media(max-width:640px){.cols{grid-template-columns:1fr}}
.qlist{max-height:34vh;overflow:auto;border:1px solid var(--line);border-radius:10px}
.opt{display:flex;gap:8px;align-items:center;padding:7px 8px;border-bottom:1px solid var(--line);cursor:pointer}.opt .c{margin-left:auto;color:var(--mut);font-size:12px;white-space:nowrap}
.opt button{padding:2px 8px;font-size:12px}.sub{padding:4px 8px 8px 30px;font-size:12px;color:var(--mut)}
.sum{background:#eef2ff;border:1px solid #c9d2ff;border-radius:10px;padding:10px;margin-top:10px}
.g{color:var(--ok);font-weight:600}.r{color:var(--bad);font-weight:600}
.cat{display:inline-flex;gap:6px;align-items:center;padding:8px 12px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--ink);font-weight:600;cursor:pointer}.cat.on{background:var(--acc);color:#fff;border-color:var(--acc)}
.blk{margin-top:12px;padding-top:10px;border-top:1px solid var(--line)}.sh{font-size:17px;margin:0 0 6px}
.dst{word-break:break-all;margin-bottom:6px}
.fname{width:100%;margin-top:6px}

/* folder picker + settings */
.fpath{font-size:13px;word-break:break-all;background:#f1f4fa;border-radius:8px;padding:6px 8px;margin-top:6px}
.roots{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}
.roots button{padding:4px 10px;font-size:13px}
.fplist{max-height:48vh;overflow:auto;border:1px solid var(--line);border-radius:10px}
.fi{display:flex;gap:8px;padding:10px;border-bottom:1px solid var(--line);cursor:pointer;align-items:center;word-break:break-all}.fi:hover{background:#f1f5ff}
.set label.lb{display:block;font-weight:600;margin:14px 0 4px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.two label{font-size:13px;color:var(--mut)}
.log{background:#0f1830;color:#cfe0ff;font:12px/1.4 ui-monospace,Menlo,Consolas,monospace;padding:8px;border-radius:8px;max-height:160px;overflow:auto;white-space:pre-wrap;margin:8px 0 0}

/* compact look */
body{font-size:13px;padding-bottom:40px}
.wrap{padding:10px}
h1{font-size:20px;letter-spacing:-.4px}
section{padding:10px;margin-top:10px;border-radius:12px}
section>h2{font-size:15px;margin-bottom:8px}
button{padding:7px 11px;font-size:13px;border-radius:9px}
button.sm{padding:4px 8px;font-size:12px}
input[type=text],input[type=number],select{padding:8px 10px;font-size:14px;border-radius:9px}
.ibtn{width:32px;height:32px;position:relative}.ibtn svg{width:16px;height:16px}
.pill{padding:4px 9px;font-size:12px}
.mut{font-size:12px}
.vid h3{font-size:13px}.vid .row{margin-top:6px}.vid button{padding:6px}
.grid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.job{grid-template-columns:76px 1fr;gap:8px}.job img{width:76px}
.tg,button.tg{padding:5px 10px;font-size:12px}
.fpanel{padding:10px;gap:8px}
.modal{padding:12px}
table{font-size:12px}
.sh{font-size:14px}
.set label.lb{margin:10px 0 3px}
.banner{background:#e7ecf6;color:var(--ink);padding:8px 12px;font-size:13px}
#status{display:none!important}
#dl{position:fixed;inset:0;z-index:8;margin:0;border-radius:0;border:0;overflow:auto;display:none;padding:12px;background:var(--bg)}
#dl.show{display:block}
body.noscroll{overflow:hidden}
.nb{position:absolute;top:-4px;right:-4px;background:var(--acc);color:#fff;border-radius:99px;font-size:10px;min-width:16px;height:16px;line-height:16px;text-align:center;padding:0 4px}
.hb{background:#fff6e0;border:1px solid #ecd28a;border-radius:12px;padding:12px;margin-bottom:10px;font-size:13px}
.hb #hbt{font-size:15px;display:block;margin-bottom:4px}
.hist{margin-top:8px}.hh{display:flex;justify-content:space-between;align-items:center}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.chp{display:inline-flex;align-items:center;gap:6px;background:#eef2ff;border:1px solid #c9d2ff;border-radius:99px;padding:3px 8px;font-size:12px}
.chp a{color:#2437b8;cursor:pointer}.chp i{font-style:normal;color:var(--mut);cursor:pointer;padding:0 2px}
.grid.list{grid-template-columns:1fr}
.chc{display:flex;gap:10px;align-items:center;padding:8px;border:1px solid var(--line);border-radius:12px;background:#fff;cursor:pointer}
.av{width:46px;height:46px;border-radius:50%;background:#cfd8e6;color:#44526b;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;overflow:hidden;flex:0 0 auto}
.av img{width:100%;height:100%;object-fit:cover;display:block}.av.big{width:56px;height:56px}
.chi{min-width:0;flex:1}.chi b{display:block;font-size:14px}
.chi .desc{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.chh{display:flex;gap:10px;align-items:center}
.lf{display:flex;gap:8px;align-items:center;padding:8px 0;border-bottom:1px solid var(--line)}
.lic{width:34px;height:34px;border-radius:8px;background:#eef2ff;color:var(--acc);display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto}
.lfi{min-width:0;flex:1}.lfi b{display:block;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#16233b;color:#fff;padding:8px 14px;border-radius:99px;font-size:13px;opacity:0;pointer-events:none;transition:opacity .25s;z-index:30}#toast.show{opacity:1}
#modal video,#modal audio{width:100%;border-radius:10px;background:#000}
.accb{display:flex;justify-content:space-between;align-items:center;width:100%;background:#f1f4fa;color:var(--ink);border:1px solid var(--line);padding:8px 10px;margin:0 0 6px;font-weight:700;text-align:left}
/* extra small text and buttons */
body{font-size:12.5px}
button{font-size:12.5px;padding:6px 10px}
button.sm{font-size:11.5px;padding:3px 8px}
input[type=text],input[type=number],select{font-size:13px;padding:7px 9px}
.tg,button.tg{font-size:12px;padding:4px 9px}
.pill{font-size:11.5px}
h1{font-size:18px;letter-spacing:.5px}
section>h2{font-size:14px}
.vid h3{font-size:12.5px}
.sitehdr{margin-top:8px;font-size:12px;color:var(--mut)}.sitehdr b{color:var(--ink)}
.lth{width:56px;aspect-ratio:16/9;border-radius:6px;overflow:hidden;background:#eef2ff;display:flex;align-items:center;justify-content:center;color:var(--acc);flex:0 0 auto}
.lth img{width:100%;height:100%;object-fit:cover;display:block}
.lf{cursor:pointer}.pth{font-size:11px;word-break:break-all}
.chl{color:var(--acc);cursor:pointer;text-decoration:underline}
.chip{flex:0 0 84px;font-size:11px}
.fli{display:flex;gap:8px;align-items:center;padding:6px 8px;border-bottom:1px solid var(--line)}
.fli img{width:56px;aspect-ratio:16/9;object-fit:cover;border-radius:5px;background:#eef2ff;flex:0 0 auto}
.fli .t{min-width:0;flex:1;font-size:12px}.fli .t b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
</style>
</head>
<body>
<div class="wrap offline" id="app">
  <header>
    <h1>CONTENT DOWNLOADER</h1>
    <div class="hr">
      <div class="pill spd" id="gspd" hidden title="Current download speed - click for the speed graph" role="button" tabindex="0" style="cursor:pointer">&#8595; <b id="gspdv">0 KB/s</b></div>
      <div class="pill spd" id="gsw" hidden title="Automatic switching between slow and fast downloads"></div>
      <button class="ibtn" id="bell" hidden type="button" title="Notifications" aria-label="Notifications"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></button>
      <button class="ibtn" id="dlbtn" type="button" title="Downloads" aria-label="Downloads"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="M7 11l5 5 5-5"/><path d="M5 20h14"/></svg><span class="nb" id="dlnb" hidden></span></button>
      <button class="ibtn" id="gear" type="button" title="Settings" aria-label="Settings"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
      <span id="status" hidden><span id="stxt"></span></span>
    </div>
  </header>

  <div class="banner" id="banner"><b>Connecting&hellip;</b><span id="why" hidden></span></div>
  <div class="hb" id="hb" hidden><b id="hbt"></b><div id="hbm"></div><div class="row" style="margin-top:8px"><button class="sm" id="hbretry" type="button">Try again</button></div></div>

  <section class="need" id="dl">
    <h2>Downloads <button class="alt sm" id="dlclose" type="button">Close</button></h2>
    <div id="qsum"><span class="mut">Nothing downloading.</span></div>
    <div class="row" id="pallbar" style="margin-bottom:8px" hidden>
      <button class="alt" id="pall" type="button">&#10074;&#10074; Pause all</button>
      <button class="alt" id="rall" type="button">&#9654; Resume all</button>
    </div>
    <div class="ask" id="stopbar" hidden>
      <b id="stopn"></b> <span class="mut">unfinished or stopped. Continue them all at once instead of one by one.</span>
      <div class="row" style="margin-top:6px"><button id="cnt" type="button">Continue all</button></div>
    </div>
    <div id="downloadContent">
      <div class="row" style="margin-bottom:6px">
        <button class="alt" id="cxa" type="button">Cancel all</button>
      </div>
      <div id="jobs"><div class="empty">Nothing downloading.</div></div>
      <h3 class="sh" id="libh" hidden style="margin-top:12px">Downloaded on this device</h3><div id="lib"></div>
      <div class="mut" id="keepnote" style="margin-top:8px"></div>
    </div>
  </section>

  <section class="need">
    <h2>Search</h2>
    <div class="sbar">
      <div class="sb">
        <input type="text" id="q" placeholder="Search YouTube or paste a video / playlist link" autocomplete="off">
        <button class="attach" id="attach" type="button" title="Upload a file that contains links" aria-label="Upload a file that contains links"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg></button>
      </div>
      <button id="go" type="button">Search</button>
    </div>
    <input type="file" id="fileIn" multiple hidden>
    <div class="hist" id="hist" hidden><div class="hh"><span class="mut">Recent searches</span><button class="alt sm" id="histclr" type="button">Clear</button></div><div class="chips" id="histl"></div></div>
    <div class="tools">
      <span class="seg" id="mode"><button class="tg on" data-m="s" type="button">Videos</button> <button class="tg" data-m="c" type="button">Channels</button></span>
      <label class="tg" id="multiLbl"><input type="checkbox" id="multi"> Multi select</label>
      <button class="tg" id="sitebtn" type="button">Site: YouTube</button>
      <button class="tg" id="fbtn" type="button" aria-expanded="false" aria-controls="fpanel"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg> Filters <span class="cnt" id="fcnt" hidden></span></button>
    </div>
    <div class="fpanel" id="fpanel" hidden>
      <label>Type<select id="ftype"><option value="all">Videos and playlists</option><option value="video">Videos only</option><option value="playlist">Playlists only</option></select></label>
      <label>Upload date<select id="fdate"><option value="">Any upload date</option><option value="hour">Last hour</option><option value="today">Today</option><option value="week">This week</option><option value="month">This month</option><option value="year">This year</option></select></label>
      <label>Length<select id="fdur"><option value="">Any length</option><option value="short">Under 4 minutes</option><option value="medium">4 to 20 minutes</option><option value="long">Over 20 minutes</option></select></label>
      <label>Country (like a VPN)<select id="fcountry"><option value="">Automatic</option><option value="US">United States</option><option value="GB">United Kingdom</option><option value="CA">Canada</option><option value="AU">Australia</option><option value="DE">Germany</option><option value="FR">France</option><option value="NL">Netherlands</option><option value="SE">Sweden</option><option value="NO">Norway</option><option value="FI">Finland</option><option value="DK">Denmark</option><option value="CH">Switzerland</option><option value="AT">Austria</option><option value="BE">Belgium</option><option value="IE">Ireland</option><option value="ES">Spain</option><option value="PT">Portugal</option><option value="IT">Italy</option><option value="PL">Poland</option><option value="CZ">Czechia</option><option value="RO">Romania</option><option value="UA">Ukraine</option><option value="TR">Turkey</option><option value="IL">Israel</option><option value="AE">United Arab Emirates</option><option value="SA">Saudi Arabia</option><option value="IN">India</option><option value="PK">Pakistan</option><option value="BD">Bangladesh</option><option value="LK">Sri Lanka</option><option value="SG">Singapore</option><option value="MY">Malaysia</option><option value="ID">Indonesia</option><option value="TH">Thailand</option><option value="VN">Vietnam</option><option value="PH">Philippines</option><option value="JP">Japan</option><option value="KR">South Korea</option><option value="HK">Hong Kong</option><option value="TW">Taiwan</option><option value="NZ">New Zealand</option><option value="ZA">South Africa</option><option value="NG">Nigeria</option><option value="KE">Kenya</option><option value="EG">Egypt</option><option value="BR">Brazil</option><option value="AR">Argentina</option><option value="CL">Chile</option><option value="CO">Colombia</option><option value="MX">Mexico</option></select></label>
      <button class="alt" id="freset" type="button">Reset filters</button>
    </div>
    <div id="sitehdr" class="sitehdr" hidden></div>
    <div id="crumb" style="margin-top:8px"></div>
    <div id="msg" class="mut" style="margin-top:8px"></div>
    <div class="grid" id="results" style="margin-top:10px"></div>
    <div class="mut" id="more" style="text-align:center;margin-top:12px" hidden>Loading more&hellip;</div><div id="sentinel" style="height:1px"></div>
  </section>
</div>

<div class="selbar" id="selbar"><b id="sn"></b><button class="alt" id="selall">Select all shown</button><button class="alt" id="selclr">Clear</button><button id="selgo">Choose quality</button></div>
<div class="drop" id="drop">Drop a file that contains links</div>
<div class="overlay" id="ov"><div class="modal" id="modal"></div></div>
<div class="overlay" id="ov2"><div class="modal" id="modal2"></div></div>

<script>
const $=s=>document.querySelector(s);
const LS={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
const API=location.origin;
let online=false,busy=false,KEEPV=0,KEEPA=0,OUT='',FREE=null,BPS=8e6,skew=0;
let COUNTRY=LS.get('country')||'';$('#fcountry').value=COUNTRY;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mb=b=>b?(b>1e9?(b/1e9).toFixed(2)+' GB':(b/1e6).toFixed(1)+' MB'):'size unknown';
const dur=s=>{if(!s)return'';s=Math.round(s);const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(s%60).padStart(2,'0')};
const sp=b=>!b||b<1?'':b>=1e6?(b/1e6).toFixed(1)+' MB/s':Math.round(b/1e3)+' KB/s';
const trimT=(t,n)=>String(t).length>n?String(t).slice(0,n-1)+'\u2026':String(t);
const ckFor=()=>false;
async function api(path,opt){
  if(ckFor(path)&&!/[?&]ck=/.test(path))path+=(path.includes('?')?'&':'?')+'ck=1';
  if(COUNTRY&&!/[?&]country=/.test(path))path+=(path.includes('?')?'&':'?')+'country='+COUNTRY;
  const r=await fetch(API+path,opt);
  const j=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(j.error||('Error '+r.status));
  return j;
}
const post=(p,o)=>api(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o||{})});

function setOnline(v,why){
  online=v;$('#app').classList.toggle('offline',!v);$('#status').classList.toggle('on',v);
  if(!v){$('#gspd').hidden=true;$('#gsw').hidden=true}
}
async function tryUrl(){try{const r=await fetch(API+'/api/ping');const j=await r.json();return j.ok?j:null}catch(e){return null}}
function gotOnline(p){
  const was=online;KEEPV=p.keep.video;KEEPA=p.keep.audio;OUT=p.out||'';FREE=p.free;BPS=p.dl_bps||8e6;
  $('#keepnote').textContent=(OUT?'Files are saved in '+OUT+' unless you choose a custom folder. ':'')+(KEEPV||KEEPA?'Merged videos are deleted '+KEEPV+' hours after they finish, audio-only files after '+KEEPA+' hours.':'Nothing is deleted automatically.');
  setOnline(true);
  healthUi(p.health);
  if(!was){loadJobs();startStream();loadHist()}
}
async function ping(){
  if(busy)return;busy=true;
  try{const p=await tryUrl();if(p)gotOnline(p);else setOnline(false)}finally{busy=false}
}

/* state */
const SEL=new Map(),ITEMS=new Map(),famOrd={h264:0,vp9:1,av1:2},extOrd={m4a:0,webm:1,mp3:2};
let R=null,back=null,multi=false,Q=null;
const LIVE=['downloading','merging','uploading','cancelling'],END=['done','error','cancelled','expired','deleted'];
const clk=t=>new Date(t*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
const hm=s=>{s=Math.max(0,Math.round(s));const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return h?h+' h '+m+' min':m?m+' min '+s%60+' s':s+' s'};
const now=()=>Date.now()/1000+skew;

/* filters */
function updFilters(){let n=0;if($('#ftype').value!=='all')n++;if($('#fdate').value)n++;if($('#fdur').value)n++;if($('#fcountry').value)n++;
  $('#fcnt').hidden=!n;$('#fcnt').textContent=n;$('#fbtn').classList.toggle('on',n>0)}
$('#fbtn').onclick=()=>{const p=$('#fpanel');p.hidden=!p.hidden;$('#fbtn').setAttribute('aria-expanded',String(!p.hidden))};
$('#freset').onclick=()=>{$('#ftype').value='all';$('#fdate').value='';$('#fdur').value='';$('#fcountry').value='';COUNTRY='';LS.set('country','');
  $('#fdate').disabled=$('#fdur').disabled=false;updFilters();if($('#q').value.trim())search()};

/* search, load more, playlists */
function pageUrl(){return R.mode==='ch'?'/api/channel?'+new URLSearchParams({id:R.id||'',url:R.url||'',tab:R.tab||'videos',q:R.cq||'',offset:R.next,n:12}):R.mode==='pl'?`/api/playlist?id=${R.id}&offset=${R.next}&n=12`:'/api/search?'+new URLSearchParams({q:R.q,type:R.p.type,date:R.p.date,dur:R.p.dur,site:SITE,offset:R.next,n:12})}
async function load(){
  const r=R;if(r.busy)return;r.busy=1;$('#more').hidden=!r.items.length;$('#msg').textContent=r.items.length?'':'Loading\u2026';
  try{const d=await api(pageUrl());if(R!==r)return;
    d.results.filter(v=>!r.items.some(x=>x.id===v.id)).forEach(v=>{ITEMS.set(v.id,v);r.items.push(v)});
    if(d.channel)chHead(d.channel);
    if(d.site&&r.mode==='s')showSite(d.site,d.link);
    r.next=d.next;r.more=d.more&&d.results.length>0;r.loaded=1;r.busy=0;paint();
  }catch(e){r.err=1;if(R===r){$('#more').hidden=true;$('#msg').innerHTML='<span class="err">'+esc(e.message)+'</span>'}}
  finally{r.busy=0}
}
function showSite(site,link){const h=$('#sitehdr');if(!site){h.hidden=true;return}h.hidden=false;h.innerHTML=(link?'Link from ':'Results from ')+'<b>'+esc(siteName(site))+'</b>'}
function searchVideos(){const q=$('#q').value.trim();if(!q)return;const pl=$('#ftype').value==='playlist';if(!/^https?:\/\//i.test(q))showSite(SITE,false);else $('#sitehdr').hidden=true;
  R={mode:'s',q,p:{type:$('#ftype').value,date:pl?'':$('#fdate').value,dur:pl?'':$('#fdur').value},items:[],next:0};$('#crumb').innerHTML='';$('#results').innerHTML='';load()}
function search(){const q=$('#q').value.trim();if(!q)return;if(!/^https?:\/\//i.test(q)&&!/youtu\.?be/i.test(q))addHist(q);
  if(MODE==='c'){if(SITE!=='youtube'){if(/^https?:\/\//i.test(q)){CHFROM=null;return openChX({url:q,name:''})}$('#msg').textContent='Paste the channel or profile link of this site.';return}return chSearch(q)}searchVideos()}
$('#go').onclick=search;$('#q').onkeydown=e=>{if(e.key==='Enter')search()};
const SENT=$('#sentinel'),io=new IntersectionObserver(es=>{if(es.some(e=>e.isIntersecting)&&R&&R.more&&R.loaded&&!R.busy&&!R.err)load()},{rootMargin:'700px'});io.observe(SENT);
const watch=()=>setTimeout(()=>{io.unobserve(SENT);io.observe(SENT)},60);
$('#fcountry').onchange=()=>{COUNTRY=$('#fcountry').value;LS.set('country',COUNTRY);updFilters();if($('#q').value.trim())search()};
['ftype','fdate','fdur'].forEach(i=>$('#'+i).onchange=()=>{$('#fdate').disabled=$('#fdur').disabled=$('#ftype').value==='playlist';updFilters();if($('#q').value.trim())search()});
updFilters();
function card(v){
  if(v.type==='playlist')return `<div class="vid" data-id="${v.id}"><div class="th"><img src="${esc(v.thumb||'')}" alt=""><span class="badge">Playlist${v.count?' \u00b7 '+v.count+' videos':''}</span></div><h3>${esc(v.title)}</h3><div class="mut">${esc(v.channel||'')}</div><div class="row"><button class="alt" data-open="1">Open</button><button data-all="1">Download all</button></div></div>`;
  const on=SEL.has(v.id),sx=SEL.get(v.id),dup=multi&&sx&&sx.from!==fromOf();
  return `<div class="vid${on?' sel':''}" data-id="${v.id}"><div class="th"><img src="${esc(v.thumb)}" alt="">${multi?`<input type="checkbox" class="pick" ${on?'checked':''}>`:''}${dup?`<span class="badge dup">Already selected: ${esc(sx.from)}</span>`:''}${v.duration?`<span class="badge">${dur(v.duration)}</span>`:''}</div><h3>${esc(v.title)}</h3><div class="mut">${v.channel&&(v.chid||v.churl)?`<a class="chl" data-chl="1">${esc(v.channel)}</a>`:esc(v.channel||'')}</div><div class="row"><button class="alt" data-p="1">Play</button>${multi?'':'<button data-d="1">Download</button>'}</div></div>`}
const fromOf=()=>R.mode==='s'?R.q:R.title;
function paint(){$('#results').innerHTML=R?R.items.map(card).join(''):'';$('#more').hidden=true;watch();updSel();
  if(R&&R.loaded){const n=multi?R.items.filter(v=>{const x=SEL.get(v.id);return x&&x.from!==fromOf()}).length:0;
    $('#msg').innerHTML=!R.items.length?'No results.':n?`<span class="g">${n} video${n>1?'s here are':' here is'} already in your selection from another search.</span>`:''}}
$('#results').onclick=e=>{const t=e.target,c=t.closest('.vid');if(!c)return;const id=c.dataset.id,v=ITEMS.get(id);
  if(t.dataset.chl){CHFROM=R;return v.chid?openCh({id:v.chid,name:v.channel,logo:'',subs:0}):openChX({url:v.churl,name:v.channel})}
  if(t.dataset.p&&String(id).startsWith('x~'))return toast('Preview works for YouTube only');if(t.dataset.p)return modal(`<iframe src="https://www.youtube.com/embed/${id}?autoplay=1" allow="autoplay;encrypted-media;fullscreen" allowfullscreen></iframe>${closeBtn()}`);
  if(t.dataset.d)return openQuality([v],{});
  if(t.dataset.open)return openPl(v);
  if(t.dataset.all)return plAll(v,t);
  if(multi&&v.type==='video'&&!t.closest('button')){SEL.has(id)?SEL.delete(id):SEL.set(id,{...v,from:fromOf()});c.classList.toggle('sel',SEL.has(id));const dd=c.querySelector('.dup');if(dd&&!SEL.has(id))dd.remove();const p=c.querySelector('.pick');if(p)p.checked=SEL.has(id);updSel()}};
function openPl(v){back=R;R={mode:'pl',id:v.id,title:v.title,items:[],next:0};$('#crumb').innerHTML=`<button class="alt" id="bk">\u2190 Back to results</button> <b>${esc(v.title)}</b>`;
  $('#bk').onclick=()=>{R=back;if(R.mode==='ch')chCrumb();else $('#crumb').innerHTML='';paint()};paint();load()}
async function plAll(v,b){b.disabled=true;b.textContent='Reading\u2026';
  try{const d=await api(`/api/playlist?id=${v.id}&all=1`);d.results.forEach(x=>ITEMS.set(x.id,x));openQuality(d.results,{playlist:v.title||d.title})}catch(e){alert(e.message)}
  b.disabled=false;b.textContent='Download all'}
$('#multi').onchange=e=>{multi=e.target.checked;$('#multiLbl').classList.toggle('on',multi);if(R)paint()};
function updSel(){$('#selbar').classList.toggle('show',multi&&SEL.size>0);$('#sn').textContent=SEL.size+' selected'}
$('#selall').onclick=()=>{R&&R.items.filter(v=>v.type==='video').forEach(v=>{if(!SEL.has(v.id))SEL.set(v.id,{...v,from:fromOf()})});paint()};
$('#selclr').onclick=()=>{SEL.clear();if(R)paint();else updSel()};
$('#selgo').onclick=()=>openQuality([...SEL.values()],{fromSel:1});

/* quality selection */
function pickV(L,w){if(!w||!L.length)return null;let f=L.find(x=>x.label===w.label);if(f)return{f,fb:0};
  const s=L.filter(x=>x.fam===w.fam),p=s.length?s:L;
  f=p.filter(x=>x.h<=w.h).sort((a,b)=>b.h-a.h||b.fps-a.fps)[0]||p.slice().sort((a,b)=>a.h-b.h)[0];return{f,fb:1}}
function pickA(L,w){if(!w||!L.length)return null;let f=L.find(x=>x.label===w.label);if(f)return{f,fb:0};
  let p=L.filter(x=>x.ext===w.ext);if(!p.length)p=L.filter(x=>x.ext==='mp3');if(!p.length)p=L;
  f=p.filter(x=>x.abr<=w.abr).sort((a,b)=>b.abr-a.abr)[0]||p.slice().sort((a,b)=>a.abr-b.abr)[0];return{f,fb:1}}
function agg(k){const m=new Map();Q.ok.forEach(it=>Q.info.get(it.id)[k].forEach(f=>{if(!m.has(f.label))m.set(f.label,{f,ids:[]});m.get(f.label).ids.push(it.id)}));
  return[...m.values()].sort(k==='videos'?(x,y)=>y.f.h-x.f.h||y.f.fps-x.f.fps||famOrd[x.f.fam]-famOrd[y.f.fam]:(x,y)=>extOrd[x.f.ext]-extOrd[y.f.ext]||y.f.abr-x.f.abr)}
const ctxOf=id=>Q.mode==='same'?Q.same:Q.each.get(id);
const sync=cc=>{cc.cat.vm=(cc.qp.size||cc.ox.size)?1:0;cc.cat.vo=cc.vo.size?1:0;cc.cat.ao=cc.ao.size?1:0};
const oneOf=cc=>{if(!cc)return;let kept=false;['qp','ox','vo','ao'].forEach(k=>{const a=[...cc[k]];cc[k].clear();if(!kept&&a.length){cc[k].add(a[0]);kept=true}});sync(cc)};
const MP3='MP3 192k',QA='AAC 128k',ms=b=>b?'~'+mb(b):'size unknown';
/* one choice = which types are ticked + the qualities ticked in each list + where the files go:
   cat  {vm,vo,ao} = Video+audio / Video only / Audio only ticked
   qp   video qualities ticked in "H.264 + AAC 128k" quick picks
   ox   video qualities ticked in "Other combinations" (paired with audio oa)
   vo   video-only qualities ticked   ao  audio-only qualities ticked
   dest {base:'' = default folder, useSub: put files in a new folder, name: that folder's name} */
const mkCtx=()=>({cat:{vm:1,vo:0,ao:0},qp:new Set(),ox:new Set(),oa:null,vo:new Set(),ao:new Set(),
  dest:{base:'',useSub:!!(Q&&Q.meta&&Q.meta.playlist),name:(Q&&Q.meta&&Q.meta.playlist)||'New folder'}});
const cloneCtx=c=>({cat:{...c.cat},qp:new Set(c.qp),ox:new Set(c.ox),oa:c.oa,vo:new Set(c.vo),ao:new Set(c.ao),dest:{...c.dest}});
const destTxt=c=>{const b=c.dest.base||OUT,sep=b.includes('\\')&&!b.includes('/')?'\\':'/';return c.dest.useSub?b.replace(/[\\/]+$/,'')+sep+(c.dest.name.trim()||'New folder'):b};
const fmtBy=(k,l)=>{for(const it of Q.ok){const f=Q.info.get(it.id)[k==='v'?'videos':'audios'].find(x=>x.label===l);if(f)return f}};
const szV=(id,w)=>{const v=pickV(Q.info.get(id).videos,w);return v?v.f.size||0:0};
const szA=(id,w)=>{const a=pickA(Q.info.get(id).audios,w);return a?a.f.size||0:0};
/* every file that will be downloaded for one video (duplicates collapse into one) */
function resAll(id){const L=Q.info.get(id),c=ctxOf(id),out=[],seen=new Set();let miss=0;
  const add=r=>{if(!r){miss++;return}const k=r.kind+'|'+(r.v?r.v.id:'')+'|'+(r.a?r.a.id:'');if(seen.has(k)){if(r.fb)out.dup=(out.dup||0)+1;return}seen.add(k);out.push(r)};
  const V=l=>pickV(L.videos,fmtBy('v',l)),A=l=>pickA(L.audios,fmtBy('a',l)),nt=(w,x)=>x&&x.fb?'wanted '+w+', using '+x.f.label:'';
  const mk=(vl,al)=>{const v=V(vl),a=A(al);return v&&a&&{kind:'video',v:v.f,a:a.f,fb:v.fb||a.fb,txt:[nt(vl,v),nt(al,a)].filter(Boolean).join('; ')}};
  if(c.cat.vm){c.qp.forEach(l=>add(mk(l,QA)));if(c.oa)c.ox.forEach(l=>add(mk(l,c.oa.label)))}
  if(c.cat.vo)c.vo.forEach(l=>{const v=V(l);add(v&&{kind:'vonly',v:v.f,a:null,fb:v.fb,txt:nt(l,v)})});
  if(c.cat.ao)c.ao.forEach(l=>{const a=A(l);add(a&&{kind:'audio',v:null,a:a.f,fb:a.fb,txt:nt(l,a)})});
  out.miss=miss;out.dup=out.dup||0;return out}
function defVM(c){const V=agg('videos'),H=V.filter(e=>e.f.fam==='h264'),all=e=>e.ids.length===Q.ok.length,bH=H.find(all)||H[0],b=V.find(all)||V[0];
  if(bH&&fmtBy('a',QA))c.qp.add(bH.f.label);else if(b)c.ox.add(b.f.label)}
function defaults(c,k){const V=agg('videos'),A=agg('audios');
  if(k==='vm'&&!c.qp.size&&!c.ox.size)defVM(c);
  if(k==='vo'&&!c.vo.size){const e=V.find(x=>x.ids.length===Q.ok.length)||V[0];if(e)c.vo.add(e.f.label)}
  if(k==='ao'&&!c.ao.size){const e=A.find(x=>x.f.label===MP3)||A[0];if(e)c.ao.add(e.f.label)}}
async function openQuality(items,meta){
  items=items.filter(Boolean);if(!items.length)return;
  Q={items,by:new Map(items.map(i=>[i.id,i])),meta,info:new Map(),mode:'same',cur:0,each:new Map(),open:new Set(),compat:true,loading:true,n:0,bad:0,acc:new Set(['qp']),multi:false};
  modal('<div id="qb"></div>');$('#modal').className='modal wide';renderQ();const q=Q;let i=0;
  const w=async()=>{while(Q===q&&i<items.length){const it=items[i++];try{const f=await api('/api/formats?id='+it.id);q.info.set(it.id,f);if(it.fileSrc){it.title=f.title;it.thumb=f.thumb||it.thumb}}catch(e){q.bad++}q.n++;if(Q===q)renderQ()}};
  await Promise.all([w(),w(),w(),w()]);if(Q!==q)return;
  q.ok=items.filter(i=>q.info.has(i.id));q.loading=false;
  if(q.ok.length){const A=agg('audios'),c=mkCtx();c.oa=(A.find(e=>e.f.ext==='m4a')||A[0]||{}).f||null;defVM(c);
    q.same=c;q.ok.forEach(i=>q.each.set(i.id,cloneCtx(c)))}
  renderQ()}
function subList(lst,e){const have=new Set(e.ids),miss=Q.ok.filter(i=>!have.has(i.id)).map(i=>{const r=(lst==='videos'?pickV:pickA)(Q.info.get(i.id)[lst],e.f);return `<div class="r">\u26a0 ${esc(i.title)} \u2192 ${r?esc(r.f.label):'none'}</div>`});
  return `<div class="sub"><b class="g">Has it (${e.ids.length})</b>${e.ids.map(id=>`<div class="g">\u2713 ${esc(Q.by.get(id).title)}</div>`).join('')}${miss.length?`<b class="r">Will use the nearest quality (${miss.length})</b>${miss.join('')}`:''}</div>`}
function renderQ(){const q=Q,body=$('#qb');if(!q||!body)return;
  if(q.loading){body.innerHTML=`<h2 style="font-size:20px">Checking qualities\u2026</h2><p class="mut">${q.n} of ${q.items.length} videos</p><div class="bar"><i style="width:${q.n/q.items.length*100}%"></i></div>`;return}
  if(!q.ok.length){body.innerHTML='<p class="err">None of the selected videos could be read.</p>'+closeBtn();return}
  const sc=[...body.querySelectorAll('.qlist')].map(x=>x.scrollTop),N=q.ok.length,cur=q.ok[q.cur],c=ctxOf(cur.id),same=q.mode==='same',cn=same&&N>1;
  const rs=q.ok.map(i=>resAll(i.id)),jobs=rs.flat(),fb=jobs.filter(r=>r.fb).length+rs.reduce((t,r)=>t+r.dup,0),miss=rs.reduce((t,r)=>t+(r.miss||0),0);
  /* space estimate from everything ticked */
  const sz=r=>(r.v?r.v.size||0:0)+(r.a?r.a.size||0:0),by={video:[],vonly:[],audio:[]};jobs.forEach(r=>by[r.kind].push(r));
  const sum=l=>l.reduce((t,r)=>t+sz(r),0),fin=sum(jobs),peak=Math.max(0,...by.video.map(sz)),need=fin+peak,unk=jobs.filter(r=>!sz(r)).length;
  const brk=[['video','Video + audio'],['vonly','Video only'],['audio','Audio only']].filter(([k])=>by[k].length).map(([k,n])=>`${n}: <b>${ms(sum(by[k]))}</b> \u00b7 ${by[k].length} file${by[k].length>1?'s':''}`).join('<br>');
  const strip=N>1?`<div class="strip">${q.ok.map((it,i)=>{const r=rs[i],g=r.length&&!r.some(x=>x.fb)&&!r.miss&&!r.dup;return `<div class="chip ${same?'':'pick1'} ${!same&&i===q.cur?'on':''}" data-i="${i}"><button class="x" data-rm="${i}" title="Remove this video">\u00d7</button><img src="${esc(it.thumb)}" alt=""><div>${esc(it.title)}</div><div class="${g?'g':'r'}">${r.length?r.length+' file'+(r.length>1?'s':'')+(g?' \u2713':r.miss?' \u26a0 some missing':' \u26a0 nearest'):'\u2717 nothing to download'}</div></div>`}).join('')}</div>`:'';
  const info=(e,sk,fn)=>{const has=cn?e.ids.length===N:e.ids.includes(cur.id),tot=cn?q.ok.reduce((t,i)=>t+fn(i.id),0):fn(cur.id),sh=q.open.has(sk);
    return{has,sh,html:cn?`<b class="${has?'g':'r'}">available in ${e.ids.length} of ${N} videos</b> \u00b7 <span class="${has?'g':'r'}">${ms(tot)} in total</span> <button class="alt" data-show="${esc(sk)}">${sh?'Hide':'Show videos'}</button>`:has?`<span class="g">${ms(tot)}</span>`:'<span class="r">not available \u00b7 nearest is used</span>'}};
  const crow=(set,e,fn,text,lst)=>{const x=info(e,set+'|'+e.f.label,fn);
    return `<label class="opt"><input type="checkbox" data-set="${set}" data-l="${esc(e.f.label)}" ${c[set].has(e.f.label)?'checked':''}><span class="${x.has?'g':'r'}">${esc(text)}</span><span class="c">${x.html}</span></label>${x.sh?subList(lst,e):''}`};
  const arow=e=>{const x=info(e,'oa|'+e.f.label,id=>szA(id,e.f));
    return `<label class="opt"><input type="radio" name="oa" data-oa="1" data-l="${esc(e.f.label)}" ${c.oa&&c.oa.label===e.f.label?'checked':''}><span class="${x.has?'g':'r'}">${esc(e.f.label)}</span><span class="c">${x.html}</span></label>${x.sh?subList('audios',e):''}`};
  const V=agg('videos'),A=agg('audios'),H=V.filter(e=>e.f.fam==='h264'),qa=fmtBy('a',QA);
  const accH=(k,t,n,inner)=>{const o=q.acc.has(k);return `<div class="blk"><button class="accb" data-acc="${k}" type="button"><span>${o?'\u25be':'\u25b8'} ${t}</span>${n?`<span class="cnt">${n}</span>`:''}</button>${o?inner:''}</div>`};
  const multiH=`<div class="row" style="margin-top:8px;align-items:center"><label class="tg ${q.multi?'on':''}"><input type="checkbox" id="qmulti" ${q.multi?'checked':''}> Select multiple</label><span class="mut">${q.multi?'Tick as many qualities as you like.':'Pick one quality.'}</span></div>`;
  const secQP=accH('qp','Quick picks \u00b7 video + audio',c.qp.size,`<div class="qlist">${qa?(H.map(e=>crow('qp',e,id=>szV(id,e.f)+szA(id,qa),e.f.x?`${e.f.label} + best audio`:`${e.f.h}p${e.f.fps>30?e.f.fps:''} H.264 + AAC 128k`,'videos')).join('')||'<div class="sub">No quick picks for this video.</div>'):'<div class="sub">AAC is not available for these videos.</div>'}</div>`);
  const secOX=accH('ox','Other combinations \u00b7 video + audio',c.ox.size,`<div class="cols"><div><b>Video quality</b><div class="qlist">${V.map(e=>crow('ox',e,id=>szV(id,e.f)+(c.oa?szA(id,c.oa):0),`${e.f.label} + ${c.oa?c.oa.label:'?'}`,'videos')).join('')}</div></div>
    <div><b>Audio quality</b><div class="qlist">${A.map(arow).join('')}</div></div></div>`);
  const secVO=accH('vo','Video only (no audio)',c.vo.size,`<div class="qlist">${V.map(e=>crow('vo',e,id=>szV(id,e.f),e.f.label,'videos')).join('')}</div>`);
  const secAO=accH('ao','Audio only',c.ao.size,`<div class="qlist">${A.map(e=>crow('ao',e,id=>szA(id,e.f),e.f.label,'audios')).join('')}</div>`);
  const secDest=`<div class="blk"><h3 class="sh">Save to${!same?' <span class="mut">(this video)</span>':''}</h3>
    <div class="dst"><span class="mut">Folder:</span> <b>${esc(c.dest.base||OUT)}</b> ${c.dest.base?'':'<span class="tag tm">default</span>'}</div>
    <div class="row"><button class="alt" data-fold="1" type="button">\ud83d\udcc1 Custom folder</button>${c.dest.base?'<button class="alt" data-fdef="1" type="button">Use default folder</button>':''}</div>
    <label style="display:block;margin-top:8px"><input type="checkbox" data-sub="1" ${c.dest.useSub?'checked':''}> Save in a new folder${q.meta.playlist?' (named after the playlist)':''}</label>
    ${c.dest.useSub?`<input type="text" class="fname" data-name="1" value="${esc(c.dest.name)}" placeholder="Folder name"><div class="mut" style="margin-top:4px">Files will be saved in: <b id="dfinal">${esc(destTxt(c))}</b></div>`:''}</div>`;
  body.innerHTML=`<h2 style="font-size:20px">Choose quality</h2>${N===1?`<div class="row" style="align-items:center;margin:6px 0"><img src="${esc(cur.thumb||'')}" alt="" style="width:64px;aspect-ratio:16/9;object-fit:cover;border-radius:6px;background:#eef2ff"><b style="font-size:12.5px">${esc(cur.title)}</b></div>`:''}<div class="mut">${N} video${N>1?'s':''}${q.meta.playlist?' \u00b7 playlist: '+esc(q.meta.playlist):''}${q.bad?' \u00b7 '+q.bad+' could not be read':''}</div>
   ${N>1?`<div class="seg row" style="margin-top:8px"><button data-mode="same" class="${same?'on':''}">Same for all</button><button data-mode="each" class="${same?'':'on'}">Choose for each video</button></div>`:''}
   ${strip}${!same?`<div class="mut"><b>${esc(cur.title)}</b></div>`:''}
   ${multiH}${secQP}${secOX}${secVO}${secAO}${secDest}
   ${!same&&N>1?`<div class="row" style="margin-top:8px"><button class="alt" id="qall">Use this choice for all ${N} videos</button></div>`:''}
   <div class="sum">${jobs.length?`<b>${jobs.length} file${jobs.length>1?'s':''}</b> from ${N} video${N>1?'s':''}, downloaded one after another`:'<b class="r">Nothing selected: tick at least one quality above.</b>'}${jobs.length&&!miss&&!fb?' \u00b7 <b class="g">all have the chosen quality</b>':''}${fb?` \u00b7 <b class="r">${fb} will use the nearest available quality</b>`:''}${miss?` \u00b7 <b class="r">${miss} not available, skipped</b>`:''}
     ${brk?`<br>${brk}`:''}
     <br>Space needed: <b>${ms(need)}</b>${peak?` = ${ms(fin)} for the finished files + ${ms(peak)} temporary working space (one video at a time)`:' for the finished files'}${unk?` \u00b7 ${unk} size${unk>1?'s':''} unknown`:''}
     <br>Free space in the default folder: ${FREE!=null?`<b class="${FREE>=need?'g':'r'}">${mb(FREE)}</b>${FREE>=need?'':' \u00b7 not enough for this selection'}`:'<span class="g">no limit reported</span>'} \u00b7 rough download time <b>${fin?'~'+hm(fin/BPS):'unknown'}</b> (merging adds more)
     <br>${KEEPV||KEEPA?`Finished videos are deleted after ${KEEPV} hours, audio-only files after ${KEEPA} hours.`:'Finished files stay in their folder until you delete them.'}</div>
   ${by.video.length?`<label style="display:block;margin-top:8px"><input type="checkbox" id="cp" ${q.compat?'checked':''}> Make merged files play everywhere (converts AV1/VP9 to H.264; slower)</label>`:''}
   <div class="row" style="margin-top:10px"><button id="qgo" ${jobs.length?'':'disabled'}>Start download (${jobs.length})</button><button class="alt" onclick="closeModal()">Cancel</button></div>`;
  body.querySelectorAll('.qlist').forEach((x,i)=>x.scrollTop=sc[i]||0)}
$('#modal').addEventListener('change',e=>{const t=e.target;if(!Q)return;
  if(t.id==='cp'){Q.compat=t.checked;return}
  if(Q.loading||!Q.ok||!Q.ok.length)return;const c=ctxOf(Q.ok[Q.cur].id);
  if(t.dataset.cat){const k=t.dataset.cat;c.cat[k]=t.checked?1:0;if(t.checked)defaults(c,k);return renderQ()}
  if(t.id==='qmulti'){Q.multi=t.checked;if(!Q.multi)[Q.same,...Q.each.values()].forEach(oneOf);return renderQ()}
  if(t.dataset.set){const s=c[t.dataset.set];if(t.checked){if(!Q.multi)['qp','ox','vo','ao'].forEach(k=>c[k].clear());s.add(t.dataset.l)}else s.delete(t.dataset.l);sync(c);return renderQ()}
  if(t.dataset.oa){c.oa=fmtBy('a',t.dataset.l);return renderQ()}
  if(t.dataset.sub){c.dest.useSub=t.checked;return renderQ()}});
$('#modal').addEventListener('input',e=>{const t=e.target;if(!Q||Q.loading||!Q.ok||!t.dataset||!t.dataset.name)return;
  const c=ctxOf(Q.ok[Q.cur].id);c.dest.name=t.value;const f=$('#dfinal');if(f)f.textContent=destTxt(c)});
$('#modal').addEventListener('click',e=>{if(!Q||Q.loading)return;const t=e.target,ch=t.closest('.chip');
  const ab=t.closest('[data-acc]');if(ab){const k=ab.dataset.acc;Q.acc.has(k)?Q.acc.delete(k):Q.acc.add(k);return renderQ()}
  if(t.dataset.show){e.preventDefault();Q.open.has(t.dataset.show)?Q.open.delete(t.dataset.show):Q.open.add(t.dataset.show);return renderQ()}
  if(t.dataset.fold){const q=Q,c=ctxOf(q.ok[q.cur].id);return pickFolder({start:c.dest.base||OUT,title:'Choose a folder for the downloads'},p=>{c.dest.base=p;if(Q===q)renderQ()})}
  if(t.dataset.fdef){ctxOf(Q.ok[Q.cur].id).dest.base='';return renderQ()}
  if(t.dataset.rm!==undefined){const id=Q.ok[+t.dataset.rm].id;Q.ok=Q.ok.filter(i=>i.id!==id);Q.items=Q.items.filter(i=>i.id!==id);if(Q.meta.fromSel){SEL.delete(id);paint()}
    if(!Q.ok.length)return closeModal();Q.cur=Math.min(Q.cur,Q.ok.length-1);return renderQ()}
  if(t.id==='qall'){const c=cloneCtx(ctxOf(Q.ok[Q.cur].id));Q.same=cloneCtx(c);Q.ok.forEach(i=>Q.each.set(i.id,cloneCtx(c)));return renderQ()}
  if(t.dataset.mode){Q.mode=t.dataset.mode;return renderQ()}
  if(ch&&Q.mode==='each'){Q.cur=+ch.dataset.i;return renderQ()}
  if(t.id==='qgo'&&!t.disabled)startQ()});
async function startQ(){const items=[];
  Q.ok.forEach(it=>{const i=Q.info.get(it.id),pk=a=>({id:a.id,src:a.src,conv:a.conv,br:a.br,label:a.label,ext:a.ext}),c=ctxOf(it.id),
    dest={base:c.dest.base||'',sub:c.dest.useSub?(c.dest.name.trim()||'New folder'):''};
    resAll(it.id).forEach(r=>items.push({id:it.id,title:i.title,thumb:it.thumb,duration:i.duration,channel:i.channel,kind:r.kind,v:r.v?{id:r.v.id,label:r.v.label,fam:r.v.fam,h:r.v.h}:null,a:r.a?pk(r.a):null,est_bytes:(r.v?r.v.size||0:0)+(r.a?r.a.size||0:0),v_bytes:r.v?r.v.size||0:0,a_bytes:r.a?(r.a.dsize||r.a.size||0):0,fb:r.txt||null,dest}))});
  if(!items.length)return alert('Nothing to download.');
  const b=$('#qgo');if(b)b.disabled=true;
  try{await post('/api/download',{items,compat:Q.compat,playlist:Q.meta.playlist||null});
    if(Q.meta.fromSel){SEL.clear();paint()}closeModal();loadJobs();toast('Download started')}catch(e){alert(e.message);if(b)b.disabled=false}}
function closeModal(){Q=null;$('#ov').classList.remove('show');$('#modal').innerHTML='';$('#modal').className='modal'}
function modal(h){$('#modal').className='modal';$('#modal').innerHTML=h;$('#ov').classList.add('show')}
const closeBtn=()=>'<div class="row" style="margin-top:10px"><button class="alt" onclick="closeModal()">Close</button></div>';
$('#ov').onclick=e=>{if(e.target.id==='ov')closeModal()};

/* folder picker: works like a small file manager, no typing of paths */
let FP=null;
function pickFolder(o,cb){FP={mode:o.mode||'dir',ext:o.ext||'',title:o.title||'Choose folder',cb,data:null,err:'',busy:0};$('#ov2').classList.add('show');fpLoad(o.start||'')}
async function fpLoad(p){const f=FP;f.busy=1;renderFP();
  try{const d=await api('/api/browse?'+new URLSearchParams({path:p||'',files:f.mode==='file'?'1':'0',ext:f.ext}));if(FP!==f)return;f.data=d;f.err=d.error||''}catch(e){f.err=e.message}
  f.busy=0;if(FP===f)renderFP()}
function closeFP(){FP=null;$('#ov2').classList.remove('show');$('#modal2').innerHTML=''}
function renderFP(){const f=FP;if(!f)return;const d=f.data,dir=f.mode==='dir';
  if(!d){$('#modal2').innerHTML=`<h2 style="font-size:20px">${esc(f.title)}</h2><p class="mut">${f.err?'<span class="err">'+esc(f.err)+'</span>':'Loading\u2026'}</p><div class="row"><button class="alt" id="fpx">Cancel</button></div>`;return}
  $('#modal2').innerHTML=`<h2 style="font-size:20px">${esc(f.title)}</h2>
   <div class="fpath">${esc(d.path)}</div>
   <div class="roots">${d.roots.map(r=>`<button class="alt" data-p="${esc(r.path)}" data-k="d">${esc(r.name)}</button>`).join('')}</div>
   ${f.err?`<div class="err">${esc(f.err)}</div>`:''}${dir&&d.writable===false?'<div class="r">\u26a0 This folder may not be writable.</div>':''}
   <div class="fplist">
     ${d.parent?`<div class="fi" data-p="${esc(d.parent)}" data-k="d">\u2b06 Up one level</div>`:''}
     ${d.dirs.map(x=>`<div class="fi" data-p="${esc(x.path)}" data-k="d">\ud83d\udcc1 ${esc(x.name)}</div>`).join('')}
     ${d.files.map(x=>`<div class="fi" data-p="${esc(x.path)}" data-k="f">\ud83d\udcc4 ${esc(x.name)}</div>`).join('')}
     ${!d.dirs.length&&!d.files.length?`<div class="fi mut">${dir?'No folders here. You can still use this folder or make a new one.':'Nothing here.'}</div>`:''}
   </div>
   <div class="row" style="margin-top:10px">${dir?'<button class="alt" id="fpnew">New folder</button>':''}<button class="alt" id="fpx">Cancel</button>${dir?'<button id="fpuse">Use this folder</button>':''}</div>`}
$('#modal2').addEventListener('click',async e=>{const f=FP;if(!f)return;const t=e.target,it=t.closest('[data-p]');
  if(it){if(it.dataset.k==='f'){const p=it.dataset.p;closeFP();return f.cb(p)}return fpLoad(it.dataset.p)}
  if(t.id==='fpx')return closeFP();
  if(t.id==='fpuse'&&f.data){const p=f.data.path;closeFP();return f.cb(p)}
  if(t.id==='fpnew'&&f.data){const n=prompt('Name of the new folder');if(!n||!n.trim())return;
    try{const r=await post('/api/mkdir',{path:f.data.path,name:n.trim()});fpLoad(r.path)}catch(x){alert(x.message)}}});
$('#ov2').onclick=e=>{if(e.target.id==='ov2')closeFP()};

/* downloads */
const stageTxt={queued:'Waiting',downloading:'Downloading',merging:'Merging',uploading:'Saving to folder',cancelling:'Cancelling',cancelled:'Cancelled',expired:'Deleted (time limit)',deleted:'Deleted',confirm:'Unfinished job found',done:'Finished',error:'Stopped'};
const stageLabel=j=>j.stage==='merging'&&j.kind==='audio'?'Converting to MP3':(stageTxt[j.stage]||j.stage);
const jobPct=j=>j.stage==='downloading'?j.dl:j.stage==='merging'?j.merge:j.stage==='uploading'?j.up:0;
const stCls={done:'ok',downloading:'run',error:'err',pending:'mut'};
const lk=(t,u)=>u?`<div class="lk"><a href="${u}" target="_blank" rel="noopener">${t}</a><button onclick="navigator.clipboard.writeText('${u}')">Copy link</button></div>`:'';
const r30=t=>Math.round(t/30)*30;
const stepH=(s,k)=>{const bar=k!=='p'&&s.status!=='pending',pct=Math.max(0,Math.min(100,s.pct||0)),m=[];
  if(bar)m.push(`<b>${Math.floor(pct)}%</b>`);
  if(s.status==='downloading'&&(k==='v'||k==='a')&&s.spd)m.push(sp(s.spd));
  if(s.t0)m.push(`<b class="el" data-s="${s.t0}" data-f="${s.t1||''}"></b>`);
  if(s.status==='downloading'&&s.eta)m.push(`about <span class="left" data-s="${r30(s.eta)}"></span> left`);
  else if(s.status==='pending'&&s.est)m.push('estimated '+hm(s.est));
  const c=k==='m'||k==='c'?'m':k==='s'?'u':'';
  return `<div class="st"><div class="sl"><span class="${stCls[s.status]||'mut'}">${esc(s.text)}</span><span class="sr">${m.join(' \u00b7 ')}</span></div>${bar?`<div class="bar s ${c}"><i style="width:${pct}%"></i></div>`:''}</div>`};
function stepsHtml(j){const S=j.steps||{},o=[],dl=[S.v,S.a].filter(Boolean),fx=s=>j.paused?{...s,eta:0,spd:0}:s,live=LIVE.includes(j.stage);
  const dlDone=dl.length>0&&dl.every(x=>x.status==='done');
  /* downloading: ONE bar for video + audio together; once it is finished only merging + saving remain (two bars) */
  if(dl.length&&!(dlDone&&live)){const act=dl.some(x=>x.status!=='pending'),
    t0=Math.min(...dl.map(x=>x.t0||Infinity)),t1=dlDone?Math.max(...dl.map(x=>x.t1||0)):0,
    eta=Math.max(0,...dl.map(x=>x.status==='downloading'?x.eta||0:0)),
    s={status:dlDone?'done':act?'downloading':'pending',text:'Downloading',pct:dlDone?100:Math.min(99.9,j.dl||0),spd:j.speed||0,eta,t0:isFinite(t0)?t0:0,t1,est:dl.reduce((t,x)=>t+(x.est||0),0)};
    o.push(stepH(fx(s),'v'))}
  for(const k of ['m','c','s']){let st=S[k];if(!st)continue;
    if(live&&dlDone&&st.status==='pending')st={...st,status:'downloading',pct:0,eta:0};
    o.push(stepH(fx(st),k))}
  return o.join('')}
function jobHtml(j){const au=j.kind==='audio',vo=j.kind==='vonly',ql=au?j.a.label:vo?j.v.label:j.v.label+' + '+j.a.label,live=LIVE.includes(j.stage),fin=END.includes(j.stage);
  return `<img src="${esc(j.thumb)}" alt=""><div>${j.pos?`<span class="tag tv" title="Order of this video: the first one has priority">#${j.pos}</span> `:''}<b>${esc(j.title)}</b>
   <div class="mut"><span class="tag ${au?'ta':vo?'tm':'tv'}">${au?'Audio only':vo?'Video only':'Video + audio'}</span> ${esc(ql)}${j.playlist?' \u00b7 playlist: '+esc(j.playlist):''}</div>
   ${j.dest&&j.stage!=='done'?`<div class="mut">Folder: ${esc(j.dest)}</div>`:''}
   ${j.fallback?`<div class="mut">Nearest quality used: ${esc(j.fallback)}</div>`:''}
   <div class="${j.stage==='error'?'err':'mut'}"><b>${esc(stageLabel(j))}</b>${live&&j.stage!=='cancelling'?' '+Math.floor(jobPct(j))+'%':''}${j.note&&j.stage!=='done'?' \u2014 '+esc(j.note):''}</div>
   ${j.stage==='queued'?`<div class="mut">Starts in about <span class="left" data-s="${r30(j.start_at)}"></span> \u00b7 done around ${clk(r30(j.eta_at))}</div>`:''}
   ${j.started&&j.stage!=='queued'?`<div class="mut">Time taken <b class="el" data-s="${j.started}" data-f="${fin&&j.finished?j.finished:''}"></b>${live&&!j.paused?` \u00b7 about <span class="left" data-s="${r30(j.eta_at)}"></span> left \u00b7 done around ${clk(r30(j.eta_at))}`:''}</div>`:''}
   ${j.stage==='downloading'?`<div class="mut">${mb(j.done_b)} of ${mb(j.total_b)}${j.speed?' \u00b7 <b>'+sp(j.speed)+'</b> now':''}</div>`:''}
   ${(live||j.stage==='error')?stepsHtml(j):''}
   ${j.stage==='confirm'?`<div class="ask"><b>Continue this job?</b><div class="lnk"><button onclick="act('${j.id}','resume')">Continue</button><button class="alt" onclick="act('${j.id}','skip')">No, mark it complete</button></div></div>`:''}
   ${j.stage==='error'?`<div class="lnk"><button onclick="act('${j.id}','resume')">Retry</button><button class="alt" onclick="act('${j.id}','skip')">Mark complete</button></div>`:''}
   ${j.stage==='done'?lk(au?'Audio file':vo?'Video file (no audio)':'Merged video + audio',j.direct)+`${j.path?`<div class="mut">Saved: ${esc(j.path)}</div>`:''}${j.expires_at?`<div class="mut">Deleted automatically in <span class="left" data-s="${r30(j.expires_at)}"></span></div>`:''}<div class="lnk"><button onclick="del('${j.id}')">Delete now</button></div>`:''}
   ${['queued','confirm','error'].includes(j.stage)||(live&&j.stage!=='cancelling')?`<div class="lnk">${(j.stage==='queued'||(live&&j.stage!=='cancelling'))?(j.paused?`<button onclick="act('${j.id}','unpause')">&#9654; Resume</button>`:`<button class="alt" onclick="act('${j.id}','pause')">&#10074;&#10074; Pause</button>`):''}<button class="alt" onclick="cancelJob('${j.id}',${live})">Cancel${live?' and delete files':''}</button></div>`:''}</div>`}
const jobEls=new Map();
const verb=j=>j.stage==='downloading'?'Downloading':j.stage==='merging'?(j.kind==='audio'?'Converting':'Merging'):j.stage==='uploading'?'Saving':'Cancelling';
function renderSummary(d){
  const s=d.summary,live=d.jobs.filter(j=>LIVE.includes(j.stage)),wait=d.jobs.filter(j=>j.stage==='queued');
  $('#gspd').hidden=false;$('#gspdv').textContent=sp(s.speed)||'0 KB/s';
  const w=s.smart,gsw=$('#gsw');if(w&&w.kind){gsw.hidden=false;gsw.textContent=(w.kind==='switch'?'Switching video in ':w.kind==='pause'?'Limiting 2nd video in ':'Releasing 2nd video in ')+w.left+'s'}else gsw.hidden=true;
  let h='';
  if(!(s.active+s.queued))h='<span class="mut">Nothing downloading.</span>';
  else{
    h=live.map(j=>`<div class="ql"><span class="run">${verb(j)}</span> ${esc(j.title)} <b>${Math.floor(jobPct(j))}%</b>${j.stage==='downloading'&&j.speed?' \u00b7 '+sp(j.speed):''}</div>`).join('');
    if(s.queued)h+=`<div class="ql"><span class="mut">Waiting (${s.queued}):</span> ${wait.slice(0,3).map(j=>esc(trimT(j.title,40))).join(', ')}${s.queued>3?' +'+(s.queued-3)+' more':''}</div>`;
    h+=`<div class="mut" style="margin-top:4px">Everything, merging included, finishes in about <span class="left" data-s="${r30(s.finish_at)}"></span> (around ${clk(r30(s.finish_at))})</div>`;
  }
  $('#qsum').innerHTML=h;
  $('#pallbar').hidden=!(s.active+s.queued);
  $('#stopbar').hidden=!s.stopped;$('#stopn').textContent=s.stopped+' download'+(s.stopped>1?'s':'');$('#cnt').textContent='Continue all ('+s.stopped+')';
}
let HOLDUI=0;      /* a tap on a card stops that card from being redrawn for a moment, so the tap is never lost */
document.addEventListener('pointerdown',e=>{if(e.target.closest&&e.target.closest('#jobs'))HOLDUI=Date.now()+900},true);
let LASTDONE=-1,LIB=[];
function applyJobs(d){
  skew=d.now-Date.now()/1000;
  const L=d.jobs.filter(j=>!['done','expired','deleted'].includes(j.stage)),box=$('#jobs');
  renderSummary(d);
  const nd=d.jobs.filter(j=>j.stage==='done').length;if(nd!==LASTDONE){LASTDONE=nd;if($('#dl').classList.contains('show'))loadLib()}
  if(!L.length){box.innerHTML='<div class="empty">Nothing downloading.</div>';jobEls.clear()}
  else{
    const e0=box.querySelector('.empty');if(e0)e0.remove();
    L.forEach((j,i)=>{const h=jobHtml(j);let o=jobEls.get(j.id);
      if(!o){o={el:document.createElement('div'),html:''};o.el.className='job';jobEls.set(j.id,o)}
      if(o.html!==h&&Date.now()>HOLDUI&&!o.el.querySelector(':active')){o.el.innerHTML=h;o.html=h}
      if(box.children[i]!==o.el)box.insertBefore(o.el,box.children[i]||null)});
    const ids=new Set(L.map(j=>j.id));for(const[id,o]of jobEls)if(!ids.has(id)){o.el.remove();jobEls.delete(id)}
  }
  tock();noteUpdate(d)}
async function loadJobs(){if(!online)return;try{applyJobs(await api('/api/jobs'))}catch(e){}}
/* live updates pushed by the program every second (also while this tab is in the background) */
let ES=null,LASTMSG=0;
function startStream(){if(ES||!window.EventSource)return;
  ES=new EventSource(API+'/api/stream');ES.onmessage=e=>{LASTMSG=Date.now();try{applyJobs(JSON.parse(e.data))}catch(x){}}}
function tock(){const t=now();
  document.querySelectorAll('.el').forEach(e=>e.textContent=dur(Math.max(0,(+e.dataset.f||t)-+e.dataset.s))||'0:00');
  document.querySelectorAll('.left').forEach(e=>e.textContent=+e.dataset.s-t>1?hm(+e.dataset.s-t):'a moment')}
async function act(id,w){try{await api('/api/jobs/'+id+'/'+w,{method:'POST'});HOLDUI=0;loadJobs()}catch(e){alert(e.message)}}
function cancelJob(id,live){if(!live||confirm('Cancel this download? Everything downloaded for it is deleted.'))act(id,'cancel')}
function del(id){if(confirm('Delete this file from your device now?'))act(id,'delete')}
$('#pall').onclick=()=>api('/api/jobs/pause_all',{method:'POST'}).then(()=>{HOLDUI=0;loadJobs()}).catch(e=>alert(e.message));
$('#rall').onclick=()=>api('/api/jobs/unpause_all',{method:'POST'}).then(()=>{HOLDUI=0;loadJobs()}).catch(e=>alert(e.message));
$('#cxa').onclick=()=>{if(confirm('Cancel every waiting and running download and delete their files?'))api('/api/jobs/cancel_all',{method:'POST'}).then(loadJobs).catch(e=>alert(e.message))};
$('#cnt').onclick=async()=>{const b=$('#cnt');b.disabled=true;try{await api('/api/jobs/resume_all',{method:'POST'});await loadJobs()}catch(e){alert(e.message)}b.disabled=false};

/* one single notification: what is downloading + what is waiting (needs this page open in a tab) */
let NOTE_ON=false,NOTE_DISMISSED=false,NOTE_KEY='',NOTE_LAST='',NOTE_WAS=false,NOTE_T=null,NOTE_BUSY=false,SWREG=null;
async function noteReg(){if(SWREG)return SWREG;if(!('serviceWorker' in navigator))return null;
  try{await navigator.serviceWorker.register('/sw.js');SWREG=await navigator.serviceWorker.ready}catch(e){}return SWREG}
function bellUi(){$('#bell').classList.toggle('on',NOTE_ON);$('#bell').title=NOTE_ON?'Notifications are on (click to turn off)':'Turn on notifications'}
async function enableNotes(){
  if(!('Notification' in window)){alert('Progress notifications are shown by the app itself (see your notification bar).');return false}
  if(!window.isSecureContext){alert('Notifications only work when you open this page as http://localhost:... or http://127.0.0.1:...');return false}
  let p=Notification.permission;if(p==='default')p=await Notification.requestPermission();
  if(p!=='granted'){alert('Notifications are blocked. Allow them for this site in Chrome (lock icon next to the address, Permissions).');NOTE_ON=false;LS.set('note','0');bellUi();return false}
  NOTE_ON=true;NOTE_DISMISSED=false;NOTE_LAST='';LS.set('note','1');await noteReg();bellUi();return true}
function disableNotes(){NOTE_ON=false;LS.set('note','0');noteClose();bellUi()}
async function noteClose(){try{const r=await noteReg();if(r)(await r.getNotifications({tag:'tube-status'})).forEach(n=>n.close())}catch(e){}}
async function noteShow(title,body,fin){
  const o={body,tag:'tube-status',silent:!fin,renotify:!!fin,requireInteraction:!fin};
  try{const r=await noteReg();if(r){await r.showNotification(title,o);return}}catch(e){}
  try{new Notification(title,o)}catch(e){}}
function noteText(d){
  const s=d.summary,live=d.jobs.filter(j=>LIVE.includes(j.stage)),wait=d.jobs.filter(j=>j.stage==='queued'),L=[];
  live.forEach(j=>L.push((j.stage==='downloading'?'\u2b07 Downloading':j.stage==='merging'?(j.kind==='audio'?'\ud83c\udfb5 Converting':'\u2699 Merging'):j.stage==='uploading'?'\ud83d\udcbe Saving':'\u2716 Cancelling')+': '+trimT(j.title,60)+' \u2014 '+Math.floor(jobPct(j))+'%'+(j.stage==='downloading'&&j.speed?' \u00b7 '+sp(j.speed):'')));
  if(s.queued)L.push('\u23f3 Waiting ('+s.queued+'): '+wait.slice(0,3).map(j=>trimT(j.title,32)).join(', ')+(s.queued>3?' +'+(s.queued-3)+' more':''));
  if(s.stopped)L.push('\u26a0 Stopped: '+s.stopped);
  return{title:'Content Downloader'+(s.speed>0?' \u00b7 \u2193 '+sp(s.speed):''),body:L.join('\n')}}
async function noteUpdate(d){
  if(!NOTE_ON||!('Notification' in window)||Notification.permission!=='granted')return;
  const s=d.summary,active=s.active+s.queued>0,key=d.jobs.filter(j=>LIVE.includes(j.stage)).map(j=>j.id).join(',');
  if(key!==NOTE_KEY){NOTE_KEY=key;NOTE_DISMISSED=false}
  if(active){NOTE_WAS=true;clearTimeout(NOTE_T);if(NOTE_DISMISSED)return;
    const t=noteText(d),sig=t.title+'|'+t.body;if(sig===NOTE_LAST||NOTE_BUSY)return;
    NOTE_BUSY=true;NOTE_LAST=sig;try{await noteShow(t.title,t.body,false)}finally{NOTE_BUSY=false}}
  else if(NOTE_WAS){NOTE_WAS=false;NOTE_DISMISSED=false;NOTE_LAST='';
    await noteShow('Content Downloader',s.stopped?'Finished. '+s.stopped+' stopped - open the page to retry.':'\u2713 All downloads finished',true);
    clearTimeout(NOTE_T);NOTE_T=setTimeout(noteClose,20000)}}
if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('message',e=>{if(e.data&&e.data.type==='note-closed')NOTE_DISMISSED=true});
$('#bell').onclick=()=>NOTE_ON?disableNotes():enableNotes();
if(LS.get('note')==='1'&&'Notification' in window&&Notification.permission==='granted'){NOTE_ON=true;noteReg()}
bellUi();
if(navigator.locks)navigator.locks.request('tube-keepalive',()=>new Promise(()=>{})).catch(()=>{});

/* speed graph: click the speed in the header */
let GR=null;
const GRR=[[300,'5 min'],[1800,'30 min'],[3600,'1 hour'],[21600,'6 hours']];
function openGraph(){if(!online)return;GR={secs:+LS.get('grsecs')||300,d:null};modal('<div id="gr"><p class="mut">Loading\u2026</p></div>');$('#modal').className='modal wide';drawGraph()}
async function drawGraph(){const g=GR;if(!g||!$('#gr'))return;
  try{const d=await api('/api/speedlog?secs='+g.secs);if(GR===g&&$('#gr')){g.d=d;renderGraph()}}catch(e){if(GR===g&&$('#gr'))$('#gr').innerHTML='<p class="err">'+esc(e.message)+'</p>'+closeBtn()}
  clearTimeout(g.t);g.t=setTimeout(()=>{if(GR===g&&$('#gr'))drawGraph()},2000)}
function niceMax(v){const m=v/1e6,st=[.5,1,2,5,10,20,50,100,200,500,1000];return(st.find(x=>x>=m)||Math.ceil(m))}
function renderGraph(){const g=GR,d=g.d,box=$('#gr');if(!box||!d)return;
  const W=640,H=230,L=52,R=12,T=12,B=26,x0=d.now-d.secs,X=t=>L+(t-x0)/d.secs*(W-L-R),top=niceMax(Math.max(1,...d.points.map(p=>p[1]))),Y=v=>T+(1-v/1e6/top)*(H-T-B);
  const pts=d.points,line=pts.map((p,i)=>(i?'L':'M')+X(p[0]).toFixed(1)+' '+Y(p[1]).toFixed(1)).join(' '),
    area=pts.length?line+` L${X(pts[pts.length-1][0]).toFixed(1)} ${Y(0)} L${X(pts[0][0]).toFixed(1)} ${Y(0)} Z`:'';
  const grid=[0,.5,1].map(f=>`<line x1="${L}" x2="${W-R}" y1="${Y(f*top*1e6)}" y2="${Y(f*top*1e6)}" stroke="#d3dbe7" stroke-width="1"/><text x="${L-6}" y="${Y(f*top*1e6)+4}" text-anchor="end" font-size="11" fill="#5d6b82">${+(f*top).toFixed(2)} MB/s</text>`).join('');
  const tl=[0,.5,1].map(f=>{const t=x0+f*d.secs;return `<text x="${L+f*(W-L-R)}" y="${H-8}" text-anchor="${f===0?'start':f===1?'end':'middle'}" font-size="11" fill="#5d6b82">${new Date(t*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:d.secs<=1800?'2-digit':undefined})}</text>`}).join('');
  const cur=pts.length?pts[pts.length-1][1]:0;
  box.innerHTML=`<h2 style="font-size:20px">Internet speed</h2>
   <div class="seg row" style="margin:8px 0">${GRR.map(r=>`<button data-gr="${r[0]}" class="${r[0]===g.secs?'on':''}" type="button">${r[1]}</button>`).join('')}</div>
   <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;background:#f6f8fc;border-radius:10px" role="img" aria-label="Download speed history">${grid}${tl}${area?`<path d="${area}" fill="rgba(47,75,255,.15)"/>`:''}${pts.length?`<path d="${line}" fill="none" stroke="#2f4bff" stroke-width="2" stroke-linejoin="round"/>`:`<text x="${W/2}" y="${H/2}" text-anchor="middle" fill="#5d6b82" font-size="13">No downloads in this time range</text>`}</svg>
   <div class="grid" style="margin-top:10px;grid-template-columns:repeat(auto-fill,minmax(150px,1fr))">
     <div class="sum"><div class="mut">Now</div><b>${sp(cur)||'0 KB/s'}</b></div>
     <div class="sum"><div class="mut">Average</div><b>${sp(d.avg)||'0 KB/s'}</b></div>
     <div class="sum"><div class="mut">Peak</div><b>${sp(d.peak)||'0 KB/s'}</b></div>
     <div class="sum"><div class="mut">Data used (${esc(GRR.find(r=>r[0]===g.secs)[1])})</div><b>${d.range_bytes?mb(d.range_bytes):'0 MB'}</b></div>
     <div class="sum"><div class="mut">Data used so far</div><b>${d.total_bytes?mb(d.total_bytes):'0 MB'}</b></div></div>
   <div class="mut" style="margin-top:6px">Counted since ${new Date(d.since*1000).toLocaleString()}.</div>${closeBtn()}`}
$('#modal').addEventListener('click',e=>{const t=e.target;if(t.dataset&&t.dataset.gr&&GR){GR.secs=+t.dataset.gr;LS.set('grsecs',String(GR.secs));drawGraph()}});
$('#gspd').onclick=openGraph;
$('#gspd').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openGraph()}};

/* settings */
$('#gear').onclick=async()=>{modal('<p class="mut">Loading\u2026</p>');
  try{renderSettings(await api('/api/settings'))}catch(e){$('#modal').innerHTML='<p class="err">'+esc(e.message)+'</p>'+closeBtn()}};
function renderSettings(s){
  $('#modal').innerHTML=`<h2 style="font-size:22px">Settings</h2><div class="set">
   <label class="lb" for="s_out">Save downloads in</label>
   <div class="row"><input type="text" id="s_out" value="${esc(s.out)}" spellcheck="false"><button class="alt" id="s_outb" type="button">Browse</button></div>
   <div class="mut">Default: ${esc(s.out_default)} ${s.out_custom?'<button class="alt sm" id="s_outr" type="button">Use default</button>':''}</div>
   <label class="lb">Switch away from slow downloads</label>
   <div class="row"><button class="tg" id="s_smart" type="button" aria-pressed="false">Auto-switch: <b id="s_smartst">Off</b></button></div>
   <div class="two" style="margin-top:8px"><label>Minimum speed (MB/s)<input type="number" id="s_mmb" min="0" step="any" value="${s.min_mb}"></label><label>Wait (seconds)<input type="number" id="s_wsec" min="1" step="any" value="${s.wait_s}"></label></div>
   <div class="mut">When on, the first video is the priority. If its speed stays below the minimum for the wait time, the next video starts downloading too. When the first video is fast again for the wait time, the second one is paused until the first is slow again or finished. While the second video is running, the first one only needs 50% of the minimum speed to take over again, so it does not keep switching back and forth.</div>
   <label class="lb">Parallel work</label>
   <div class="row"><label class="tg"><input type="checkbox" id="s_pdl" ${s.par_dl?'checked':''}> Allow downloading several videos at once</label>
     <label class="mut">Number <input type="number" id="s_pn" min="1" max="8" step="1" value="${s.par_n}" style="width:70px"></label></div>
   <div class="row" style="margin-top:6px"><label class="tg"><input type="checkbox" id="s_dm" ${s.dl_merge?'checked':''}> Allow downloading while another video is merging</label></div>
   <div class="row" style="margin-top:6px"><label class="tg"><input type="checkbox" id="s_pm" ${s.par_merge?'checked':''}> Allow merging several videos at once</label>
     <label class="mut">Number <input type="number" id="s_mn" min="1" max="8" step="1" value="${s.merge_n}" style="width:70px"></label></div>
   <div class="two" style="margin-top:8px"><label>Second video speed while the first is fast (KB/s, 1 = almost paused)<input type="number" id="s_skb" min="1" step="any" value="${s.second_kb}"></label><label>Speed of extra videos (KB/s, 1 = almost paused)<input type="number" id="s_ekb" min="1" step="any" value="${s.extra_kb}"></label></div>
   <div class="two" style="margin-top:8px"><label>Speed of extra merges (% of full speed)<input type="number" id="s_mpc" min="5" max="100" step="any" value="${s.merge_pct}"></label></div>
   <div class="mut">With everything unticked, videos download one after another. When a video has finished downloading, the next one starts downloading while it merges (second box). Auto-switch above can still start a second download when the first is slow. Videos or merges beyond what these options allow are never stopped: they only run slowly (extra videos at the KB/s above, extra merges at the % above) until they are within the limit again.</div>
   <label class="lb">Delete finished files automatically (hours, 0 = never)</label>
   <div class="two"><label>Videos<input type="number" id="s_kv" min="0" step="any" value="${s.keep_video}"></label><label>Audio only<input type="number" id="s_ka" min="0" step="any" value="${s.keep_audio}"></label></div>
   <div class="row" style="margin-top:14px"><button id="s_save" type="button">Save settings</button><button class="alt" onclick="closeModal()" type="button">Close</button></div>
   <div id="s_msg" class="mut" style="margin-top:8px"></div></div>`;
  $('#s_outb').onclick=()=>pickFolder({start:$('#s_out').value||OUT,title:'Save downloads in'},p=>{const i=$('#s_out');if(i)i.value=p});
  const rb=$('#s_outr');if(rb)rb.onclick=()=>{$('#s_out').value=s.out_default};
  /* the parallel-work options are saved the moment you change them */
  const autoSave=async()=>{const m=$('#s_msg');try{await post('/api/settings',{par_dl:$('#s_pdl').checked,par_n:$('#s_pn').value||1,dl_merge:$('#s_dm').checked,par_merge:$('#s_pm').checked,merge_n:$('#s_mn').value||1,second_kb:$('#s_skb').value||300,extra_kb:$('#s_ekb').value||400,merge_pct:$('#s_mpc').value||25});if(m){m.className='mut';m.innerHTML='<span class="g">Saved \u2713</span>'}}catch(e){if(m){m.className='mut';m.innerHTML='<span class="err">'+esc(e.message)+'</span>'}}};
  ['s_pdl','s_pn','s_dm','s_pm','s_mn','s_skb','s_ekb','s_mpc'].forEach(id=>{$('#'+id).onchange=autoSave});
  let smartOn=!!s.smart;const smartUi=()=>{const b=$('#s_smart');if(!b)return;b.classList.toggle('on',smartOn);b.setAttribute('aria-pressed',String(smartOn));$('#s_smartst').textContent=smartOn?'On':'Off'};
  smartUi();
  $('#s_smart').onclick=async()=>{const want=!smartOn;try{await post('/api/settings',{smart:want,min_mb:$('#s_mmb').value||0,wait_s:$('#s_wsec').value||10});smartOn=want;smartUi()}catch(e){alert(e.message)}};
  $('#s_save').onclick=async()=>{const m=$('#s_msg');m.className='mut';m.textContent='Saving\u2026';
    try{const r=await post('/api/settings',{out:$('#s_out').value.trim(),keep_video:$('#s_kv').value||0,keep_audio:$('#s_ka').value||0,smart:smartOn,min_mb:$('#s_mmb').value||0,wait_s:$('#s_wsec').value||10,par_dl:$('#s_pdl').checked,par_n:$('#s_pn').value||1,dl_merge:$('#s_dm').checked,par_merge:$('#s_pm').checked,merge_n:$('#s_mn').value||1,second_kb:$('#s_skb').value||300,extra_kb:$('#s_ekb').value||400,merge_pct:$('#s_mpc').value||25});
      OUT=r.out;m.innerHTML='<span class="g">Saved \u2713</span>';ping()}catch(e){m.innerHTML='<span class="err">'+esc(e.message)+'</span>'}};
}
function ytPoll(){if(!$('#ylog'))return;
  api('/api/ytdlp').then(y=>{const l=$('#ylog');if(!l)return;
    l.hidden=!y.log.length;l.textContent=y.log.join('\n');l.scrollTop=l.scrollHeight;
    $('#yv').textContent=y.version||'not installed';
    if(y.state==='running')setTimeout(ytPoll,1000);else ping()}).catch(()=>setTimeout(ytPoll,1500))}

/* videos from a file: any format, links are detected anywhere in its text */
async function inflate(u8){const r=new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate-raw')));return new Uint8Array(await r.arrayBuffer())}
async function unzipText(b){const out=[],dv=new DataView(b.buffer,b.byteOffset,b.byteLength),td=new TextDecoder();let e=-1;
  for(let i=b.length-22;i>=Math.max(0,b.length-70000);i--)if(dv.getUint32(i,true)===0x06054b50){e=i;break}
  if(e<0)return out;let p=dv.getUint32(e+16,true);const n=dv.getUint16(e+10,true);
  for(let k=0;k<n&&dv.getUint32(p,true)===0x02014b50;k++){
    const m=dv.getUint16(p+10,true),cs=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true),nm=td.decode(b.subarray(p+46,p+46+nl));p+=46+nl+el+cl;
    if(/\.(png|jpe?g|gif|bmp|webp|ico|mp[34]|ttf|otf|woff2?)$/i.test(nm)||cs>3e7)continue;
    try{const ds=lo+30+dv.getUint16(lo+26,true)+dv.getUint16(lo+28,true),raw=b.subarray(ds,ds+cs);
      out.push(td.decode(m===8?await inflate(raw):raw))}catch(x){}}
  return out}
async function fileText(f){const b=new Uint8Array(await f.arrayBuffer()),out=[];
  out.push(b[0]===0xFF&&b[1]===0xFE?new TextDecoder('utf-16le').decode(b):b[0]===0xFE&&b[1]===0xFF?new TextDecoder('utf-16be').decode(b):new TextDecoder('utf-8').decode(b));
  if(b[0]===0x50&&b[1]===0x4B)try{out.push(...await unzipText(b))}catch(e){}
  return out.join('\n')}
function ytFind(txt){
  let s=txt.replace(/\\\//g,'/').replace(/\\u0026/gi,'&').replace(/\\u003d/gi,'=').replace(/&amp;/gi,'&');
  if(/\u0000/.test(s))s+='\n'+s.replace(/\u0000/g,'');
  s+='\n'+s.replace(/%([0-9a-f]{2})/gi,(m,h)=>String.fromCharCode(parseInt(h,16)));
  const vids=new Set(),pls=new Set(),re=/(?<![\w.-])(?:https?:\/\/)?(?:[\w-]+\.)*(?:youtube(?:-nocookie)?\.com|youtu\.be)\/[^\s"'<>)\]\\,]*/gi;
  for(const m of s.matchAll(re)){const u=m[0];let x=/youtu\.be\/([\w-]{11})/i.exec(u)||/[?&]v=([\w-]{11})/.exec(u)||/\/(?:shorts|live|embed|v|e)\/([\w-]{11})/.exec(u);
    if(x)vids.add(x[1]);else{x=/[?&]list=([\w-]+)/.exec(u);if(x&&!/^(WL|LL)$/.test(x[1]))pls.add(x[1])}}
  return{vids,pls}}
const extIdJs=u=>'x~'+btoa(unescape(encodeURIComponent(u))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const hostOf=u=>{try{return new URL(u).hostname.replace(/^www\./,'')}catch(e){return u}};
const isYtUrl=u=>/(^|\.)(youtube(-nocookie)?\.com|youtu\.be)$/i.test(hostOf(u));
let FL=null;
function fileModal(){const f=FL;if(!f)return;const n=f.sel.size,sc=$('#fl')?$('#fl').scrollTop:0;
  modal(`<h2 style="font-size:16px">Links found in the file</h2><div class="mut">${f.items.length} video${f.items.length===1?'':'s'}${f.pend?' \u00b7 reading titles\u2026':''}</div>
   <div class="row" style="margin:8px 0"><button class="alt sm" id="fsa" type="button">Select all</button><button class="alt sm" id="fsn" type="button">Select none</button></div>
   <div class="qlist" id="fl" style="max-height:48vh">${f.items.map(v=>`<label class="fli"><input type="checkbox" data-id="${esc(v.id)}" ${f.sel.has(v.id)?'checked':''}>${v.thumb?`<img src="${esc(v.thumb)}" alt="">`:'<img alt="">'}<span class="t"><b>${esc(v.title)}</b><span class="mut">${esc(v.url?hostOf(v.url):'YouTube')}</span></span></label>`).join('')}</div>
   <div class="row" style="margin-top:10px"><button id="fgo" type="button" ${n?'':'disabled'}>Continue (${n})</button><button class="alt" onclick="closeModal()" type="button">Cancel</button></div>`);
  $('#modal').className='modal wide';
  $('#fsa').onclick=()=>{f.items.forEach(v=>f.sel.add(v.id));fileModal()};$('#fsn').onclick=()=>{f.sel.clear();fileModal()};
  $('#fl').onchange=e=>{const t=e.target;if(!t.dataset.id)return;t.checked?f.sel.add(t.dataset.id):f.sel.delete(t.dataset.id);const b=$('#fgo');b.disabled=!f.sel.size;b.textContent='Continue ('+f.sel.size+')'};
  $('#fl').scrollTop=sc;
  $('#fgo').onclick=()=>{const L=f.items.filter(v=>f.sel.has(v.id));L.forEach(v=>ITEMS.set(v.id,v));FL=null;openQuality(L,{})}}
async function resolveExt(f){const todo=f.items.filter(v=>v.url);let i=0;f.pend=todo.length;
  const w=async()=>{while(FL===f&&i<todo.length){const v=todo[i++];
    try{const d=await api('/api/search?'+new URLSearchParams({q:v.url,site:'youtube',offset:0,n:50}));if(FL!==f)return;
      if(d.results.length===1){v.title=d.results[0].title||v.title;v.thumb=d.results[0].thumb||'';}
      else if(d.results.length>1){const at=f.items.indexOf(v);const add=d.results.filter(x=>!f.items.some(y=>y.id===x.id)).map(x=>({...x,fileSrc:1,url:v.url}));f.items.splice(at,1,...add);f.sel.delete(v.id);add.forEach(x=>f.sel.add(x.id))}}
    catch(e){}f.pend--;if(FL===f&&$('#fl'))fileModal()}};
  await Promise.all([w(),w(),w()])}
async function handleFiles(files){if(!files.length)return;
  const vids=new Set(),pls=new Set(),ext=[];$('#msg').textContent='Reading file\u2026';
  for(const f of files){try{const t=await fileText(f),r=ytFind(t);r.vids.forEach(x=>vids.add(x));r.pls.forEach(x=>pls.add(x));
    for(const m of t.matchAll(/https?:\/\/[^\s"'<>)\]\\,;]+/gi)){const u=m[0].replace(/[.,!?]+$/,'');if(!isYtUrl(u)&&!ext.includes(u))ext.push(u)}}catch(x){}}
  if(!vids.size&&!pls.size&&!ext.length){$('#msg').innerHTML='<span class="err">No links found in the file.</span>';return}
  const L=new Map();vids.forEach(id=>L.set(id,{type:'video',id,title:'Video '+id,thumb:`https://i.ytimg.com/vi/${id}/mqdefault.jpg`,fileSrc:1}));
  let n=0;for(const p of pls){$('#msg').textContent=`Reading playlist ${++n} of ${pls.size}\u2026`;
    try{const d=await api(`/api/playlist?id=${p}&all=1`);d.results.forEach(x=>{if(!L.has(x.id))L.set(x.id,{...x,fileSrc:1})})}catch(x){}}
  ext.forEach(u=>{const id=extIdJs(u);if(!L.has(id))L.set(id,{type:'video',id,title:u.length>70?u.slice(0,67)+'\u2026':u,thumb:'',fileSrc:1,url:u})});
  const items=[...L.values()];
  $('#msg').innerHTML=`<span class="g">Found ${items.length} video link${items.length===1?'':'s'} in the file.</span>`;
  FL={items,sel:new Set(items.map(v=>v.id)),pend:0};fileModal();resolveExt(FL)}
$('#attach').onclick=()=>$('#fileIn').click();
$('#fileIn').onchange=e=>{const f=[...e.target.files];e.target.value='';handleFiles(f)};
let dragN=0;const hasFiles=e=>e.dataTransfer&&[...(e.dataTransfer.types||[])].includes('Files');
addEventListener('dragenter',e=>{if(hasFiles(e)){dragN++;$('#drop').classList.add('show')}});
addEventListener('dragleave',e=>{if(hasFiles(e)){dragN=Math.max(0,dragN-1);if(!dragN)$('#drop').classList.remove('show')}});
addEventListener('dragover',e=>{if(hasFiles(e))e.preventDefault()});
addEventListener('drop',e=>{if(!hasFiles(e))return;e.preventDefault();dragN=0;$('#drop').classList.remove('show');handleFiles([...e.dataTransfer.files])});


/* ===== downloads panel, library on the phone ===== */
function showDl(open){$('#dl').classList.toggle('show',open);document.body.classList.toggle('noscroll',open);if(open){loadJobs();loadLib()}}
$('#dlbtn').onclick=()=>showDl(true);$('#dlclose').onclick=()=>showDl(false);
const fsz=b=>b>1e9?(b/1e9).toFixed(2)+' GB':(b/1e6).toFixed(1)+' MB';
async function loadLib(){try{const d=await api('/api/library'),L=d.items||[];LIB=L;$('#libh').hidden=!L.length;
  $('#lib').innerHTML=L.map(f=>`<div class="lf" data-id="${f.id}"><div class="lth">${f.thumb?`<img src="${esc(f.thumb)}" alt="">`:`<span>${f.kind==='audio'?'\u266A':'\u25B6'}</span>`}</div><div class="lfi"><b>${esc(f.title||f.name)}</b><div class="mut">${esc(f.ext.toUpperCase())} \u00b7 ${fsz(f.size)} \u00b7 ${new Date(f.mtime*1000).toLocaleDateString()}</div><div class="mut pth">${esc(f.dir||'')}</div></div></div>`).join('')}catch(e){}}
$('#lib').onclick=e=>{const r=e.target.closest('.lf');if(!r)return;const f=LIB.find(x=>x.id===r.dataset.id);if(!f)return;
  modal(`<b>${esc(f.title||f.name)}</b><div class="mut" style="margin-top:4px">${esc(f.ext.toUpperCase())} \u00b7 ${fsz(f.size)}</div><div class="fpath">${esc(f.path||'')}</div><div class="row" style="margin-top:10px"><button id="lplay" type="button">Play</button><button class="alt" id="ldel" type="button">Delete</button><button class="alt" onclick="closeModal()" type="button">Close</button></div>`);
  $('#lplay').onclick=()=>{const t=f.kind==='audio'?'audio':'video';modal(`<${t} src="/lib/${f.id}" controls autoplay playsinline></${t}>${closeBtn()}`)};
  $('#ldel').onclick=()=>{if(!confirm('Delete this file from your phone?'))return;
    (f.jid?api('/api/jobs/'+f.jid+'/delete',{method:'POST'}):post('/api/library/delete',{id:f.id})).then(()=>{closeModal();loadLib()}).catch(x=>alert(x.message))}};

/* ===== search history ===== */
let HIST=[];
function renderHist(){$('#hist').hidden=!HIST.length;
  $('#histl').innerHTML=HIST.slice(0,12).map(q=>`<span class="chp"><a data-q="${esc(q)}">${esc(q)}</a><i data-x="${esc(q)}">\u00d7</i></span>`).join('')}
async function loadHist(){try{HIST=(await api('/api/history')).items;renderHist()}catch(e){}}
async function addHist(q){try{HIST=(await post('/api/history',{q})).items;renderHist()}catch(e){}}
$('#histl').onclick=async e=>{const a=e.target.closest('a'),x=e.target.closest('i');
  if(a){$('#q').value=a.dataset.q;search()}
  else if(x){try{HIST=(await post('/api/history/del',{q:x.dataset.x})).items;renderHist()}catch(_){}}};
$('#histclr').onclick=async()=>{try{await post('/api/history/clear');HIST=[];renderHist()}catch(e){}};

/* ===== channels ===== */
let MODE='s',CH=[];
document.querySelectorAll('#mode button').forEach(b=>b.onclick=()=>{MODE=b.dataset.m;
  document.querySelectorAll('#mode button').forEach(x=>x.classList.toggle('on',x===b));
  $('#q').placeholder=ph();
  $('#results').classList.toggle('list',MODE==='c');
  if($('#q').value.trim())search()});
const initial=n=>esc((String(n||'?').trim()[0]||'?').toUpperCase());
const avHtml=(c,cls)=>`<span class="av ${cls||''}">${c.logo?`<img src="${esc(c.logo)}" alt="">`:initial(c.name)}</span>`;
const subsTxt=n=>n?(n>=1e6?(n/1e6).toFixed(n>=1e7?0:1)+'M':n>=1e3?(n/1e3).toFixed(n>=1e4?0:1)+'K':n)+' subscribers':'';
const chSub=c=>esc([c.handle,subsTxt(c.subs)].filter(Boolean).join(' \u00b7 '));
const chCard=c=>`<div class="chc" data-id="${c.id}">${avHtml(c)}<div class="chi"><b>${esc(c.name)}</b><div class="mut" data-sub>${chSub(c)}</div>${c.desc?`<div class="mut desc">${esc(c.desc)}</div>`:''}</div><button class="alt sm" data-yt="1" type="button">YouTube</button></div>`;
async function chSearch(q){
  R=null;$('#crumb').innerHTML='';$('#results').innerHTML='';$('#more').hidden=true;$('#msg').textContent='Loading\u2026';$('#results').classList.add('list');
  try{const d=await api('/api/channels?'+new URLSearchParams({q}));CH=d.results||[];$('#msg').textContent=CH.length?'':'No channels found.';
    $('#results').innerHTML=CH.map(chCard).join('');fillLogos(CH)}
  catch(e){$('#msg').innerHTML='<span class="err">'+esc(e.message)+'</span>'}}
async function fillLogos(list){const todo=list.filter(c=>!(c.logo&&c.subs)).slice(0,12);let i=0;
  const work=async()=>{while(i<todo.length){const c=todo[i++];
    if(!document.querySelector(`.chc[data-id="${c.id}"]`))return;
    try{const ch=(await api('/api/channel?'+new URLSearchParams({id:c.id,n:1}))).channel||{};
      if(ch.logo&&!c.logo)c.logo=ch.logo;if(ch.subs&&!c.subs)c.subs=ch.subs;
      const el=document.querySelector(`.chc[data-id="${c.id}"]`);
      if(el){const av=el.querySelector('.av');if(c.logo&&!av.querySelector('img'))av.innerHTML=`<img src="${esc(c.logo)}" alt="">`;el.querySelector('[data-sub]').innerHTML=chSub(c)}}catch(e){}}};
  await Promise.all([work(),work(),work()])}
let CHFROM=null;
function chCrumb(){const c=R.ch||{},ext=!!R.url;
  $('#crumb').innerHTML=`<div class="chh"><button class="alt sm" id="bk" type="button">\u2190 Back</button>${avHtml({name:c.name||'?',logo:c.logo||''},'big')}<div class="chi"><b id="chn">${esc(c.name||R.title||'')}</b><div class="mut" id="chs">${esc(subsTxt(c.subs))}</div></div></div>
   <div class="seg" id="chtabs" style="margin-top:8px"><button class="tg ${R.tab==='videos'?'on':''}" data-t="videos" type="button">Videos</button> ${ext?'':`<button class="tg ${R.tab==='playlists'?'on':''}" data-t="playlists" type="button">Playlists</button> <button class="tg ${R.tab==='live'?'on':''}" data-t="live" type="button">Live</button>`}</div>
   <div class="row" style="margin-top:8px">${ext?'':'<input type="text" id="chq" placeholder="Search in this channel" autocomplete="off"><button class="sm" id="chgo" type="button">Search</button>'}<button class="alt sm" id="chyt" type="button">${ext?'Open site':'Open on YouTube'}</button></div>`;
  $('#bk').onclick=chBack;$('#chyt').onclick=()=>{location.href=ext?R.url:'https://www.youtube.com/channel/'+R.id};
  const reset=()=>{R.items=[];R.next=0;R.loaded=0;R.more=false;R.err=0;$('#results').innerHTML='';load()};
  document.querySelectorAll('#chtabs button').forEach(b=>b.onclick=()=>{R.tab=b.dataset.t;R.cq='';chCrumb();reset()});
  if(!ext){const go=()=>{R.tab='videos';R.cq=$('#chq').value.trim();reset()};$('#chgo').onclick=go;$('#chq').onkeydown=e=>{if(e.key==='Enter')go()};if(R.cq)$('#chq').value=R.cq}}
function openCh(c){back=null;R={mode:'ch',id:c.id,title:c.name,items:[],next:0,cq:'',tab:'videos',ch:c};$('#results').classList.remove('list');chCrumb();$('#results').innerHTML='';load()}
function openChX(c){back=null;R={mode:'ch',id:'',url:c.url,title:c.name||c.url,items:[],next:0,cq:'',tab:'videos',ch:{name:c.name||'',logo:'',subs:0}};$('#results').classList.remove('list');chCrumb();$('#results').innerHTML='';load()}
function chBack(){if(CHFROM){R=CHFROM;CHFROM=null;$('#crumb').innerHTML='';$('#results').classList.remove('list');paint();return}R=null;$('#crumb').innerHTML='';$('#msg').textContent='';$('#more').hidden=true;$('#results').classList.add('list');$('#results').innerHTML=CH.map(chCard).join('');fillLogos(CH)}
function chHead(ch){if(!R||R.mode!=='ch')return;
  if(ch.logo&&!R.ch.logo){R.ch.logo=ch.logo;const av=document.querySelector('#crumb .av');if(av)av.innerHTML=`<img src="${esc(ch.logo)}" alt="">`}
  if(ch.name&&$('#chn'))$('#chn').textContent=ch.name;if(ch.subs&&$('#chs'))$('#chs').textContent=subsTxt(ch.subs)}
$('#results').addEventListener('click',e=>{const c=e.target.closest('.chc');if(!c)return;
  if(e.target.closest('[data-yt]')){location.href='https://www.youtube.com/channel/'+c.dataset.id;return}
  const ch=CH.find(x=>x.id===c.dataset.id);if(ch){CHFROM=null;openCh(ch)}});

/* ===== availability message ===== */
function healthUi(st){const b=$('#hb');
  if(st==='busy'||st==='offline'){b.hidden=false;
    $('#hbt').textContent=st==='busy'?'High traffic':'No internet connection';
    $('#hbm').innerHTML=st==='busy'
      ?'YouTube is very busy right now, so videos can\u2019t be loaded for the moment.<br><br><b>What to do</b><br>1. Wait 5\u201310 minutes, then tap <b>Try again</b>.<br>2. Still not working? Clear the app\u2019s data: open your phone\u2019s <b>Settings \u2192 Apps \u2192 CONTENT DOWNLOADER \u2192 Storage \u2192 Clear data</b> (on some phones: <b>Storage &amp; cache</b>), then open the app again. Videos you saved stay in the Download/Content Downloader folder.'
      :'Check your connection, then tap <b>Try again</b>.'}
  else b.hidden=true}

/* ===== site filter ===== */
let SITE=LS.get('site')||'youtube',SITES=null;
const siteName=s=>s==='youtube'?'YouTube':s.charAt(0).toUpperCase()+s.slice(1);
function ph(){return MODE==='c'?(SITE==='youtube'?'Search YouTube channels':'Paste a channel or profile link from '+siteName(SITE)):(SITE==='youtube'?'Search YouTube or paste a video / playlist link':'Search '+siteName(SITE)+' or paste a link from any site')}
function siteUi(){$('#sitebtn').textContent='Site: '+siteName(SITE);
  $('#q').placeholder=ph();$('#mode').hidden=false}
async function pickSite(){
  modal('<h2 style="font-size:16px">Site</h2><div class="mut">Used for search. A link from any site always works.</div><input type="text" id="sq" placeholder="Find a site (TikTok, Vimeo, Instagram\u2026)" style="width:100%;margin:8px 0"><div class="qlist" id="sl" style="max-height:50vh"><div class="sub">Loading\u2026</div></div>'+closeBtn());
  if(!SITES){try{SITES=(await api('/api/sites')).items}catch(e){SITES=[]}}
  const draw=()=>{const t=($('#sq').value||'').toLowerCase().trim();
    const L=[{n:'youtube',k:'ytsearch'}].concat(SITES.filter(s=>s.n!=='youtube')).filter(s=>!t||s.n.includes(t)||siteName(s.n).toLowerCase().includes(t)).slice(0,150);
    $('#sl').innerHTML=L.map(s=>`<div class="opt" data-site="${esc(s.n)}"><b>${esc(siteName(s.n))}</b><span class="c">${s.k?'search + links':'links only'}</span></div>`).join('')||'<div class="sub">No site found</div>'};
  $('#sq').oninput=draw;draw();
  $('#sl').onclick=e=>{const o=e.target.closest('[data-site]');if(!o)return;SITE=o.dataset.site;LS.set('site',SITE);closeModal();siteUi();if($('#q').value.trim())search()}}
$('#sitebtn').onclick=pickSite;siteUi();
$('#hbretry').onclick=async()=>{try{await post('/api/health/retry');$('#hbm').textContent='Checking\u2026'}catch(e){}};

function toast(t){let e=$('#toast');if(!e){e=document.createElement('div');e.id='toast';document.body.appendChild(e)}e.textContent=t;e.classList.add('show');clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('show'),2200)}
/* badge on the arrow */
const _aj=applyJobs;applyJobs=function(d){_aj(d);const n=(d.summary.active||0)+(d.summary.queued||0),nb=$('#dlnb');nb.hidden=!n;nb.textContent=n};

/* phone back button */
window.__back=function(){
  if($('#ov2').classList.contains('show')){closeFP();return true}
  if($('#ov').classList.contains('show')){closeModal();return true}
  if($('#dl').classList.contains('show')){showDl(false);return true}
  if(R&&R.mode==='ch'){chBack();return true}
  if(R&&R.mode==='pl'&&back&&$('#bk')){$('#bk').click();return true}
  return false};

ping();setInterval(ping,3000);setInterval(tock,1000);
setInterval(()=>{if(online&&Date.now()-LASTMSG>4000)loadJobs()},2000);
</script>
</body>
</html>
'''


if __name__ == "__main__":
    main()
