#!/usr/bin/env python3
"""
Tube to Drive  -  LOCAL edition
================================
Same web interface as the Colab version, but everything runs on YOUR device:
search, playlists, quality list, downloads, merging, MP3 conversion, queue,
cancel / resume / retry.  Nothing is sent to Colab, Google Drive or any other
server except YouTube itself.

Install once (Termux):
    pkg update && pkg upgrade
    pkg install python ffmpeg
    python -m pip install -U "yt-dlp[default]"
    termux-setup-storage

Install once (Windows / macOS / Linux):
    install Python 3 and ffmpeg, then:  python -m pip install -U "yt-dlp[default]"

Run:
    python yt_batch.py
The page opens by itself; if not, open the address printed in the terminal.

Everything else (save folder, cookies.txt, auto-delete, notifications,
reinstalling yt-dlp) is changed from the Settings button on the page.

Options (all optional):
    --out DIR               where finished files go (also editable in Settings)
    --cookies FILE          cookies.txt location (also editable in Settings)
    --port 8765             port of the local page
    --host 127.0.0.1        use 0.0.0.0 to open the page from another device
    --no-browser            do not open the browser automatically
    --keep-video-hours N    auto-delete finished videos after N hours (0 = never)
    --keep-audio-hours N    auto-delete finished audio after N hours (0 = never)
"""

import argparse
import base64
import importlib
import json
import mimetypes
import os
import re
import shutil
import string
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse as up
import urllib.request as ureq
import signal
import traceback
from collections import deque
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

YTDLP_DIR = os.environ.get("CD_YTDLP_DIR", "")
if YTDLP_DIR and YTDLP_DIR not in sys.path:
    sys.path.insert(0, YTDLP_DIR)

try:
    import yt_dlp
except ImportError:
    yt_dlp = None          # the page can install it from Settings

# ----------------------------------------------------------------------------
# configuration (can be changed with the options above or in Settings)
# ----------------------------------------------------------------------------
HOME = Path.home()
HERE = Path(__file__).resolve().parent
TERMUX_DL = HOME / "storage" / "downloads"
# Same folder as the old script on Termux; ~/Downloads/YouTube everywhere else.
DEFAULT_OUT = Path(os.environ["CD_OUT"]) if os.environ.get("CD_OUT") else (
    TERMUX_DL / "Content Downloader" if TERMUX_DL.exists() else HOME / "Downloads" / "Content Downloader")

CONFIG_DIR = HOME / ".tube_local"          # settings + queue live here, whatever the save folder is
SETTINGS_FILE = CONFIG_DIR / "settings.json"
LEGACY_WORK = CONFIG_DIR / "work"      # where older versions kept temporary files
WORK_DIR = LEGACY_WORK                   # becomes <save folder>/.tube_work (hidden) once settings are applied
JOBS_FILE = CONFIG_DIR / "jobs.json"
DATA_FILE = CONFIG_DIR / "data.json"       # everything in one file: settings, queue, progress of every stream

OUTPUT_DIR = DEFAULT_OUT
COOKIE_CANDS = []
KEEP_VIDEO = 0.0          # hours, 0 = keep forever
KEEP_AUDIO = 0.0
SET = {"out": "", "cookies": "", "keep_video": 0.0, "keep_audio": 0.0,
       "smart": False, "min_mb": 1.0, "wait_s": 10.0,
       "par_dl": False, "par_n": 2, "dl_merge": True, "par_merge": False, "merge_n": 2,
       "second_kb": 300.0, "extra_kb": 400.0, "merge_pct": 25.0}
SMART = {"go": False, "info": None}     # True = the monitor allows a second video to start (the first one is too slow)
MAINT = {"on": False}     # True while yt-dlp is being reinstalled
YT = {"state": "idle", "log": []}

# running totals used for AVERAGE speeds (ETA only; the screen shows live speed)
STAT = {"dl_b": 0.0, "dl_s": 0.0, "enc_m": 0.0, "enc_s": 0.0}


def avg_bps():
    """average download speed over everything downloaded so far (bytes/second)"""
    if STAT["dl_s"] > 3 and STAT["dl_b"] > 2e5:
        return max(2e5, STAT["dl_b"] / STAT["dl_s"])
    return 8e6


def enc_rate():
    """average H.264 re-encode speed: seconds of video per second of work"""
    if STAT["enc_s"] > 3:
        return max(0.2, STAT["enc_m"] / STAT["enc_s"])
    return 2.8


LIVE = ("downloading", "merging", "uploading", "cancelling")
END = ("done", "error", "cancelled", "expired", "deleted")
CLEARABLE = ("done", "cancelled", "expired", "deleted")

JOBS = {}
CV = threading.Condition(threading.RLock())     # protects JOBS
NEXT_Q = [1]
PERSIST_LOCK = threading.Lock()


class Either:
    """acts like one Event that is set when any of the given events is set"""

    def __init__(self, *ev):
        self.ev = ev

    def is_set(self):
        return any(e.is_set() for e in self.ev)


def _up(j):
    e = j.get("_upause")
    return bool(e and e.is_set())


class JobCancelled(Exception):
    pass


class PauseAbort(Exception):
    """raised inside yt-dlp's progress hook to stop a transfer on purpose while the video is paused"""


class ApiError(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.code = code


# ----------------------------------------------------------------------------
# settings
# ----------------------------------------------------------------------------
def read_data():
    """data.json (or its backup copy); the older settings.json + jobs.json are still read once so nothing is lost"""
    for f in (DATA_FILE, DATA_FILE.with_suffix(".bak")):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            if isinstance(d, dict):
                return d
        except Exception:
            pass
    d = {"settings": {}, "jobs": []}
    try:
        d["settings"] = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        d["jobs"] = json.loads(JOBS_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return d


def load_settings():
    d = read_data().get("settings")
    if not isinstance(d, dict) or not d:
        return
    for k in ("out", "cookies"):
        if isinstance(d.get(k), str):
            SET[k] = d[k]
    for k in ("keep_video", "keep_audio"):
        try:
            SET[k] = max(0.0, float(d.get(k) or 0))
        except (TypeError, ValueError):
            pass
    SET["smart"] = bool(d.get("smart"))
    for k in ("par_dl", "dl_merge", "par_merge"):
        if k in d:
            SET[k] = bool(d[k])
    for k in ("par_n", "merge_n"):
        try:
            SET[k] = min(8, max(1, int(d.get(k) if d.get(k) is not None else SET[k])))
        except (TypeError, ValueError):
            pass
    for k in ("second_kb", "extra_kb"):
        try:
            SET[k] = max(1.0, float(d.get(k) if d.get(k) is not None else SET[k]))    # old "0 = pause" becomes 1 KB/s
        except (TypeError, ValueError):
            pass
    try:
        SET["merge_pct"] = min(100.0, max(5.0, float(d.get("merge_pct") if d.get("merge_pct") is not None else SET["merge_pct"])))
    except (TypeError, ValueError):
        pass
    for k, lo in (("min_mb", 0.0), ("wait_s", 1.0)):
        try:
            SET[k] = max(lo, float(d.get(k) if d.get(k) is not None else SET[k]))
        except (TypeError, ValueError):
            pass


def save_settings():
    persist()


def apply_settings():
    global OUTPUT_DIR, KEEP_VIDEO, KEEP_AUDIO
    OUTPUT_DIR = Path(os.path.abspath(os.path.expanduser(SET["out"]))) if SET["out"] else DEFAULT_OUT
    KEEP_VIDEO, KEEP_AUDIO = SET["keep_video"], SET["keep_audio"]
    cands = []
    if SET["cookies"]:
        cands.append(Path(SET["cookies"]).expanduser())
    cands += [OUTPUT_DIR / "cookies.txt", TERMUX_DL / "cookies.txt",
              HOME / "storage" / "shared" / "Download" / "cookies.txt", HOME / "cookies.txt",
              Path("/sdcard/Download/cookies.txt"), HERE / "cookies.txt", Path.cwd() / "cookies.txt"]
    COOKIE_CANDS[:] = cands
    global WORK_DIR
    WORK_DIR = OUTPUT_DIR / ".tube_work"


def ensure_work():
    """temporary download folder: a hidden folder inside the default save folder"""
    global WORK_DIR
    try:
        WORK_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        WORK_DIR = LEGACY_WORK            # save folder not writable: fall back to the old place
        WORK_DIR.mkdir(parents=True, exist_ok=True)
        return
    if os.name == "nt":
        try:
            subprocess.run(["attrib", "+h", str(WORK_DIR)], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, check=False)
        except Exception:
            pass


def job_work(j):
    """temporary folder of one job (the folder it started in, so resuming after a restart still finds it)"""
    return Path(j["work"]) if j.get("work") else LEGACY_WORK / j["id"]


# ----------------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------------
ANSI = re.compile(r"\x1b\[[0-9;]*m")


def clean_err(exc):
    s = ANSI.sub("", str(exc)).strip()
    s = re.sub(r"^(ERROR:\s*)+", "", s)
    s = re.sub(r"^\[youtube\]\s*[\w-]+:\s*", "", s)
    return s[:400] or exc.__class__.__name__


def trunc_bytes(s, n):
    b = s.encode("utf-8")[:n]
    return b.decode("utf-8", "ignore")


def safe_name(s, n=120):
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]', " ", s or "")
    s = re.sub(r"\s+", " ", s).strip(" .")
    return trunc_bytes(s, n).rstrip(" .") or "video"


def unique_path(p):
    p = Path(p)
    if not p.exists():
        return p
    for i in range(2, 10000):
        q = p.with_name(f"{p.stem} ({i}){p.suffix}")
        if not q.exists():
            return q
    return p


def free_bytes():
    try:
        return shutil.disk_usage(OUTPUT_DIR).free
    except Exception:
        return None


def have_ffmpeg():
    return bool(shutil.which("ffmpeg"))


def thumb_of(vid):
    return f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"


def ytdlp_version():
    try:
        return yt_dlp.version.__version__ if yt_dlp else ""
    except Exception:
        return ""


def need_ytdlp():
    if MAINT["on"]:
        raise RuntimeError("yt-dlp is being reinstalled. Please wait a minute.")
    if yt_dlp is None:
        raise RuntimeError("yt-dlp is not installed yet. It installs automatically, please wait a minute or restart the app.")


def check_dir(s):
    """folder path -> Path that exists and can be written to (created if needed)"""
    s = (s or "").strip()
    if not s:
        raise ApiError("The folder path is empty")
    p = Path(os.path.abspath(os.path.expanduser(s)))
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ApiError("Cannot create that folder: " + str(e)[:200])
    try:
        fd, tmp = tempfile.mkstemp(dir=str(p), prefix=".w")
        os.close(fd)
        os.remove(tmp)
    except OSError:
        raise ApiError("That folder is not writable: " + str(p))
    return p


def resolve_dest(base, sub):
    if base:
        p = check_dir(base)
    else:
        try:
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise ApiError("Cannot create the save folder: " + str(e)[:200])
        p = OUTPUT_DIR
    if sub:
        p = check_dir(str(p / safe_name(sub, 100)))
    return p


# ----------------------------------------------------------------------------
# yt-dlp wrapper
# ----------------------------------------------------------------------------
def current_cookies():
    """first cookies.txt that exists right now (checked live, so a file added later is found)"""
    for c in COOKIE_CANDS:
        try:
            if c.is_file():
                return c
        except OSError:
            pass
    return None


COOKIE_RE = re.compile(
    r"sign in|log in|login|cookies|not a bot|age[- ]restricted|confirm your age|verify your age|"
    r"members[- ]only|private video|requires? authentication|only available to", re.I)


CTX = threading.local()      # CTX.ck = True while serving a request that should use cookies.txt


def ck_on():
    return bool(getattr(CTX, "ck", False))


class Y:
    """One YoutubeDL per call. Every call gets its own copy of cookies.txt so
    parallel threads never fight over the file."""

    def __init__(self, extra=None, country="", cookies=False):
        need_ytdlp()
        self.tmp = None
        o = {
            "quiet": True,
            "no_warnings": True,
            "noprogress": True,
            "socket_timeout": 25,
            "retries": 5,
        }
        ck = current_cookies() if (cookies or ck_on()) else None     # cookies are opt-in per call
        if ck:
            fd, self.tmp = tempfile.mkstemp(suffix=".txt")
            os.close(fd)
            shutil.copyfile(ck, self.tmp)
            o["cookiefile"] = self.tmp
        if country:
            o["geo_bypass_country"] = country
        if extra:
            o.update(extra)
        try:
            self.ydl = yt_dlp.YoutubeDL(o)
        except BaseException:
            self._rm()
            raise

    def _rm(self):
        if self.tmp:
            try:
                os.remove(self.tmp)
            except OSError:
                pass

    def __enter__(self):
        return self.ydl.__enter__()

    def __exit__(self, *a):
        try:
            self.ydl.__exit__(*a)
        finally:
            self._rm()
        return False


# ----------------------------------------------------------------------------
# reinstall yt-dlp from the page
# ----------------------------------------------------------------------------
def _say(s):
    YT["log"].append(s)
    del YT["log"][:-200]


def run_pip(args):
    cmd = [sys.executable, "-m", "pip"] + args + ["--disable-pip-version-check"]

    def once(extra):
        p = subprocess.Popen(cmd + extra, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors="replace")
        out = []
        for line in p.stdout:
            line = line.rstrip()
            if line:
                out.append(line)
                _say(line[:300])
        return p.wait(), "\n".join(out)

    rc, txt = once([])
    if rc != 0 and "externally-managed" in txt.lower():
        _say("Retrying with --break-system-packages ...")
        rc, txt = once(["--break-system-packages"])
    return rc


INSTALL_PROGRESS = {"stage": "", "done": 0, "total": 0}


def ytdlp_latest_info():
    req = ureq.Request("https://pypi.org/pypi/yt-dlp/json", headers={"User-Agent": "ContentDownloader"})
    with ureq.urlopen(req, timeout=30) as r:
        j = json.loads(r.read().decode("utf-8"))
    for f in j.get("urls", []):
        if f.get("packagetype") == "bdist_wheel" and str(f.get("url", "")).endswith(".whl"):
            return {"version": j["info"]["version"], "size": int(f.get("size") or 0), "url": f["url"]}
    raise RuntimeError("Could not find the yt-dlp download on PyPI.")


def install_wheel(info=None):
    """download the newest yt-dlp wheel and unpack it into YTDLP_DIR (replaces the old one)"""
    import zipfile
    if not YTDLP_DIR:
        raise RuntimeError("No install folder for yt-dlp.")
    info = info or ytdlp_latest_info()
    INSTALL_PROGRESS.update(stage="Downloading yt-dlp " + info["version"], done=0, total=info["size"])
    tmp = Path(YTDLP_DIR + ".tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    whl = tmp / "yt_dlp.whl"
    req = ureq.Request(info["url"], headers={"User-Agent": "ContentDownloader"})
    with ureq.urlopen(req, timeout=60) as r, open(whl, "wb") as f:
        while True:
            b = r.read(65536)
            if not b:
                break
            f.write(b)
            INSTALL_PROGRESS["done"] += len(b)
    INSTALL_PROGRESS["stage"] = "Unpacking yt-dlp"
    ex = tmp / "pkg"
    with zipfile.ZipFile(whl) as z:
        z.extractall(ex)
    shutil.rmtree(YTDLP_DIR, ignore_errors=True)
    os.replace(ex, YTDLP_DIR)
    shutil.rmtree(tmp, ignore_errors=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    (CONFIG_DIR / "ytdlp_last.txt").write_text(str(time.time()))
    INSTALL_PROGRESS["stage"] = "done"


def auto_update_loop():
    """reinstall yt-dlp every 4 days (also if it is missing)"""
    while True:
        time.sleep(60)
        try:
            last = float((CONFIG_DIR / "ytdlp_last.txt").read_text())
        except Exception:
            last = 0.0
        if yt_dlp is None or time.time() - last >= 4 * 86400:
            try:
                start_reinstall()
                time.sleep(1800)       # after an attempt, wait before trying again
            except Exception:
                pass                   # a download is running: try again in a minute


def _reinstall():
    global yt_dlp
    try:
        _say("Stopping yt-dlp ...")
        yt_dlp = None
        for m in [m for m in list(sys.modules)
                  if m in ("yt_dlp", "yt_dlp_plugins") or m.startswith(("yt_dlp.", "yt_dlp_plugins."))]:
            sys.modules.pop(m, None)
        _say("Installing the newest yt-dlp ...")
        install_wheel()
        importlib.invalidate_caches()
        import yt_dlp                      # binds the module-level name (declared global above)
        with FORMATS_LOCK:
            FORMATS.clear()
        with LISTS_LOCK:
            LISTS.clear()
        _say(f"Done. yt-dlp {ytdlp_version()} is ready.")
        YT["state"] = "ok"
    except Exception as e:
        _say("ERROR: " + clean_err(e))
        YT["state"] = "error"
        if yt_dlp is None:
            try:
                importlib.invalidate_caches()
                import yt_dlp
            except Exception:
                pass
    finally:
        with CV:
            MAINT["on"] = False
            CV.notify_all()


def start_reinstall():
    with CV:
        if YT["state"] == "running":
            raise ApiError("Already running")
        if any(j["stage"] in LIVE for j in JOBS.values()):
            raise ApiError("Wait for the running download to finish, or cancel it, then try again.")
        MAINT["on"] = True
        YT["state"] = "running"
        YT["log"] = []
    threading.Thread(target=_reinstall, daemon=True).start()
    return {"ok": True}


def ytdlp_status():
    return {"state": YT["state"], "log": YT["log"][-80:], "version": ytdlp_version(),
            "installed": yt_dlp is not None}


# ----------------------------------------------------------------------------
# folder browser (works like a small file manager)
# ----------------------------------------------------------------------------
def browse_roots():
    seen, out = set(), []

    def add(name, p):
        p = Path(p)
        try:
            ok = p.is_dir()
        except OSError:
            ok = False
        k = str(p)
        if ok and k not in seen:
            seen.add(k)
            out.append({"name": name, "path": k})
            return True
        return False

    add("Default folder", OUTPUT_DIR)
    add("Downloads", TERMUX_DL)
    add("Internal storage", "/storage/emulated/0") or add("Internal storage", "/sdcard")
    add("Home", HOME)
    if os.name == "nt":
        for L in string.ascii_uppercase:
            add(L + ":", L + ":\\")
    else:
        add("Root", "/")
    return out


def api_browse(qs):
    want_files = qs.get("files") == "1"
    ext = (qs.get("ext") or "").lower()
    p = (qs.get("path") or "").strip()
    path = Path(os.path.abspath(os.path.expanduser(p))) if p else OUTPUT_DIR
    try:
        while not path.is_dir() and path != path.parent:
            path = path.parent
        if not path.is_dir():
            path = HOME
    except OSError:
        path = HOME
    dirs, files, err = [], [], ""
    try:
        with os.scandir(path) as it:
            for e in it:
                if e.name.startswith("."):
                    continue
                try:
                    if e.is_dir():
                        dirs.append({"name": e.name, "path": str(Path(path) / e.name)})
                    elif want_files and e.is_file() and (not ext or e.name.lower().endswith(ext)):
                        files.append({"name": e.name, "path": str(Path(path) / e.name)})
                except OSError:
                    continue
    except OSError as ex:
        err = "Cannot open this folder: " + str(ex)[:150]
    dirs.sort(key=lambda x: x["name"].lower())
    files.sort(key=lambda x: x["name"].lower())
    return {
        "path": str(path),
        "parent": str(path.parent) if path.parent != path else "",
        "dirs": dirs[:3000],
        "files": files[:3000],
        "roots": browse_roots(),
        "writable": os.access(path, os.W_OK),
        "error": err,
    }


def api_mkdir(b):
    base = Path(os.path.abspath(os.path.expanduser(str(b.get("path") or ""))))
    if not base.is_dir():
        raise ApiError("The parent folder does not exist")
    name = str(b.get("name") or "").strip()
    if not name:
        raise ApiError("Type a folder name")
    p = base / safe_name(name, 100)
    try:
        p.mkdir(exist_ok=True)
    except OSError as e:
        raise ApiError("Cannot create the folder: " + str(e)[:200])
    return {"path": str(p)}


def api_settings_get():
    ck = current_cookies()
    return {
        "out": str(OUTPUT_DIR), "out_default": str(DEFAULT_OUT), "out_custom": bool(SET["out"]),
        "cookies": SET["cookies"], "cookies_found": str(ck) if ck else "",
        "keep_video": KEEP_VIDEO, "keep_audio": KEEP_AUDIO,
        "smart": bool(SET["smart"]), "min_mb": SET["min_mb"], "wait_s": SET["wait_s"],
        "par_dl": bool(SET["par_dl"]), "par_n": SET["par_n"], "dl_merge": bool(SET["dl_merge"]),
        "par_merge": bool(SET["par_merge"]), "merge_n": SET["merge_n"],
        "second_kb": SET["second_kb"], "extra_kb": SET["extra_kb"], "merge_pct": SET["merge_pct"],
        "ffmpeg": have_ffmpeg(), "yt": ytdlp_status(),
    }


def api_settings_set(b):
    new = dict(SET)
    if "out" in b:
        o = str(b["out"] or "").strip()
        new["out"] = "" if (not o or Path(os.path.abspath(os.path.expanduser(o))) == DEFAULT_OUT) \
            else str(check_dir(o))
        if not new["out"]:
            check_dir(str(DEFAULT_OUT))
    if "cookies" in b:
        c = str(b["cookies"] or "").strip()
        if c:
            cp = Path(os.path.abspath(os.path.expanduser(c)))
            if not cp.is_file():
                raise ApiError("No cookies.txt file at that path")
            new["cookies"] = str(cp)
        else:
            new["cookies"] = ""
    for k in ("keep_video", "keep_audio"):
        if k in b:
            try:
                new[k] = max(0.0, float(b[k] or 0))
            except (TypeError, ValueError):
                raise ApiError("Hours must be a number")
    if "smart" in b:
        new["smart"] = bool(b["smart"])
    for k in ("par_dl", "dl_merge", "par_merge"):
        if k in b:
            new[k] = bool(b[k])
    for k, lo, nm in (("second_kb", 1.0, "Second video speed"), ("extra_kb", 1.0, "Extra videos speed")):
        if k in b:
            try:
                new[k] = max(lo, float(b[k]))
            except (TypeError, ValueError):
                raise ApiError(nm + " must be a number")
    if "merge_pct" in b:
        try:
            new["merge_pct"] = min(100.0, max(5.0, float(b["merge_pct"])))
        except (TypeError, ValueError):
            raise ApiError("Merge speed must be a number")
    for k, nm in (("par_n", "Number of parallel downloads"), ("merge_n", "Number of parallel merges")):
        if k in b:
            try:
                new[k] = min(8, max(1, int(float(b[k]))))
            except (TypeError, ValueError):
                raise ApiError(nm + " must be a number")
    for k, lo, nm in (("min_mb", 0.0, "Minimum speed"), ("wait_s", 1.0, "Wait seconds")):
        if k in b:
            try:
                new[k] = max(lo, float(b[k]))
            except (TypeError, ValueError):
                raise ApiError(nm + " must be a number")
    SET.update(new)
    apply_settings()
    ensure_work()
    save_settings()
    return api_settings_get()


# ----------------------------------------------------------------------------
# search / playlists
# ----------------------------------------------------------------------------
DATE_CODE = {"hour": 1, "today": 2, "week": 3, "month": 4, "year": 5}
TYPE_CODE = {"video": 1, "playlist": 3}
DUR_CODE = {"short": 1, "long": 2, "medium": 3}


def search_url(q, typ, date, dur):
    """YouTube results page with the same filters as the website."""
    f = b""
    if date in DATE_CODE:
        f += bytes([0x08, DATE_CODE[date]])
    if typ in TYPE_CODE:
        f += bytes([0x10, TYPE_CODE[typ]])
    if dur in DUR_CODE:
        f += bytes([0x18, DUR_CODE[dur]])
    url = "https://www.youtube.com/results?search_query=" + up.quote_plus(q)
    if f:
        sp = base64.b64encode(bytes([0x12, len(f)]) + f).decode()
        url += "&sp=" + up.quote(sp, safe="")
    return url


PL_PREFIX = ("PL", "OL", "RD", "UU", "FL", "LL")


def parse_entry(e, allow_playlist):
    """flat yt-dlp entry -> card for the page (or None)"""
    if not e:
        return None
    eid = str(e.get("id") or "")
    title = e.get("title") or ""
    url = e.get("url") or e.get("webpage_url") or ""
    if len(eid) == 11 and re.fullmatch(r"[\w-]{11}", eid):
        if title in ("[Private video]", "[Deleted video]"):
            return None
        return {
            "type": "video",
            "id": eid,
            "title": title or "Video " + eid,
            "thumb": thumb_of(eid),
            "duration": e.get("duration"),
            "channel": e.get("channel") or e.get("uploader") or "",
        }
    if allow_playlist and len(eid) > 11 and not eid.startswith("UC") and (
            eid.startswith(PL_PREFIX) or "/playlist?list=" in url):
        th = ""
        tl = e.get("thumbnails") or []
        if tl:
            th = tl[-1].get("url") or ""
        return {
            "type": "playlist",
            "id": eid,
            "title": title or "Playlist",
            "thumb": th,
            "channel": e.get("channel") or e.get("uploader") or "",
            "count": e.get("playlist_count") or e.get("n_entries"),
        }
    return None


LISTS = {}
LISTS_LOCK = threading.Lock()


def get_list(key, url, need, country, allow_playlist):
    """Flat list of cards for a search or playlist. need=None -> everything.
    Results are cached for 10 minutes so 'Load more' is instant."""
    ck = (key, country, ck_on())
    with LISTS_LOCK:
        ent = LISTS.get(ck)
    if ent and time.time() - ent["t"] < 600 and (
        ent["done"] or (need is not None and len(ent["items"]) >= need)
    ):
        return ent
    n = None if need is None else max(need + 12, 36)
    while True:
        extra = {"extract_flat": "in_playlist", "skip_download": True}
        if n:
            extra["playlistend"] = n
        try:
            with Y(extra, country) as ydl:
                info = ydl.extract_info(url, download=False)
        except Exception as exc:
            raise ApiError(clean_err(exc))
        info = info or {}
        raw = [e for e in (info.get("entries") or []) if e]
        seen, items = set(), []
        for e in raw:
            c = parse_entry(e, allow_playlist)
            if c and c["id"] not in seen:
                seen.add(c["id"])
                items.append(c)
        done = n is None or len(raw) < n
        ent = {
            "t": time.time(),
            "items": items,
            "done": done,
            "title": info.get("title") or "",
            "channel": info.get("channel") or info.get("uploader") or "",
            "count": info.get("playlist_count") or (len(items) if done else None),
        }
        if done or need is None or len(items) >= need or n >= 400:
            break
        n += 60
    if ent["items"]:                    # never cache an empty answer
        with LISTS_LOCK:
            LISTS[ck] = ent
    return ent


def page_of(ent, offset, n):
    items = ent["items"]
    page = items[offset: offset + n]
    return {
        "results": page,
        "next": offset + len(page),
        "more": offset + n < len(items) or not ent["done"],
    }


VID_RES = [
    re.compile(r"youtu\.be/([\w-]{11})", re.I),
    re.compile(r"[?&]v=([\w-]{11})"),
    re.compile(r"/(?:shorts|live|embed|v|e)/([\w-]{11})"),
]
LINK_RE = re.compile(r"(?:youtu\.be/|youtube\.com/|youtube-nocookie\.com/)", re.I)


def parse_link(q):
    if not LINK_RE.search(q):
        return None
    vid = None
    for r in VID_RES:
        m = r.search(q)
        if m:
            vid = m.group(1)
            break
    m = re.search(r"[?&]list=([\w-]+)", q)
    lst = m.group(1) if m and m.group(1) not in ("WL", "LL") else None
    if not vid and not lst:
        return None
    return vid, lst


def dur_ok(c, dur):
    d = c.get("duration")
    if not dur or d is None:
        return True
    return d < 240 if dur == "short" else d > 1200 if dur == "long" else 240 <= d <= 1200


def search_with_fallback(q, typ, date, dur, need, country):
    """Results page first (supports every filter). If YouTube gives nothing for a
    term, try the search API with the original and then a cleaned-up query."""
    key = "s:" + json.dumps([q, typ, date, dur])
    err = None
    try:
        ent = get_list(key, search_url(q, typ, date, dur), need, country, True)
        if ent["items"]:
            return ent
    except ApiError as e:
        err = e
    if typ != "playlist" and not date:
        tries = [re.sub(r"\s+", " ", q).strip()]
        cleaned = re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", q)).strip()
        if cleaned and cleaned not in tries:
            tries.append(cleaned)
        for qq in tries:
            try:
                ent = get_list("ys:" + json.dumps([qq]), "ytsearch200:" + qq, need, country, False)
            except ApiError as e:
                err = err or e
                continue
            items = [c for c in ent["items"] if dur_ok(c, dur)]
            if items:
                return dict(ent, items=items, done=ent["done"] and not dur)
    if err:
        raise err
    return {"items": [], "done": True, "title": "", "channel": "", "count": 0}


def _int(v, d):
    try:
        return int(v)
    except (TypeError, ValueError):
        return d


def api_search(qs, country):
    q = (qs.get("q") or "").strip()
    typ = qs.get("type") or "all"
    date = qs.get("date") or ""
    dur = qs.get("dur") or ""
    offset = max(0, _int(qs.get("offset"), 0))
    n = max(1, min(50, _int(qs.get("n"), 12)))
    if not q:
        return {"results": [], "next": 0, "more": False}
    link = parse_link(q)
    if link:
        if offset:
            return {"results": [], "next": offset, "more": False}
        vid, lst = link
        res = []
        if vid:
            try:
                f = get_formats(vid, country)
                res.append({"type": "video", "id": vid, "title": f["title"], "thumb": f["thumb"],
                            "duration": f["duration"], "channel": f["channel"]})
            except Exception:
                res.append({"type": "video", "id": vid, "title": "Video " + vid,
                            "thumb": thumb_of(vid), "duration": None, "channel": ""})
        if lst:
            ent = get_list("pl:" + lst, "https://www.youtube.com/playlist?list=" + lst, 1, country, False)
            res.append({"type": "playlist", "id": lst, "title": ent["title"] or "Playlist",
                        "thumb": thumb_of(ent["items"][0]["id"]) if ent["items"] else "",
                        "channel": ent["channel"], "count": ent["count"]})
        return {"results": res, "next": len(res), "more": False}
    ent = search_with_fallback(q, typ, date, dur, offset + n, country)
    return page_of(ent, offset, n)


def api_playlist(qs, country):
    pid = qs.get("id") or ""
    if not re.fullmatch(r"[\w-]{10,60}", pid):
        raise ApiError("Bad playlist id")
    url = "https://www.youtube.com/playlist?list=" + pid
    if qs.get("all"):
        ent = get_list("pl:" + pid, url, None, country, False)
        return {"results": ent["items"], "title": ent["title"]}
    offset = max(0, _int(qs.get("offset"), 0))
    n = max(1, min(50, _int(qs.get("n"), 12)))
    ent = get_list("pl:" + pid, url, offset + n, country, False)
    return page_of(ent, offset, n)


# ----------------------------------------------------------------------------
# formats
# ----------------------------------------------------------------------------
FAM = {"h264": "H.264", "vp9": "VP9", "av1": "AV1"}
FORMATS = {}
FORMATS_LOCK = threading.Lock()
MP3_RATES = (320, 192, 128)


def fam_of(vcodec):
    v = (vcodec or "").lower()
    if v.startswith("avc"):
        return "h264"
    if v.startswith("vp09") or v.startswith("vp9"):
        return "vp9"
    if v.startswith("av01") or v.startswith("av1"):
        return "av1"
    return None


def get_formats(vid, country):
    ck = (vid, country, ck_on())
    with FORMATS_LOCK:
        c = FORMATS.get(ck)
    if c and time.time() - c[0] < 900:
        return c[1]
    try:
        with Y({"noplaylist": True, "skip_download": True}, country) as ydl:
            info = ydl.extract_info("https://www.youtube.com/watch?v=" + vid, download=False)
    except Exception as exc:
        raise ApiError(clean_err(exc))
    dur = info.get("duration") or 0
    vids, auds = {}, {}
    for f in info.get("formats") or []:
        if f.get("has_drm") or (f.get("protocol") or "").startswith(("m3u8", "mhtml")):
            continue
        note = (f.get("format_note") or "") + " " + str(f.get("format_id") or "")
        if "Premium" in note or "drc" in note.lower() or "storyboard" in note.lower():
            continue
        vc = f.get("vcodec") or "none"
        ac = f.get("acodec") or "none"
        tbr = f.get("tbr") or f.get("abr") or 0
        size = f.get("filesize") or f.get("filesize_approx") or (
            int(tbr * 1000 / 8 * dur) if tbr and dur else 0)
        fid = str(f["format_id"])
        if vc != "none" and ac == "none" and f.get("height"):
            fam = fam_of(vc)
            if not fam:
                continue
            h = int(f["height"])
            fps = int(round(f.get("fps") or 30))
            label = f"{h}p{fps if fps > 30 else ''} {FAM[fam]}"
            e = {"id": fid, "label": label, "fam": fam, "h": h, "fps": fps, "size": size}
            if label not in vids or (tbr, size) > vids[label][0]:
                vids[label] = ((tbr, size), e)
        elif ac != "none" and vc == "none":
            ext = f.get("ext")
            if ext not in ("m4a", "webm"):
                continue
            abr = int(round(f.get("abr") or tbr or 0))
            if not abr:
                continue
            if ext == "m4a":                       # AAC: normalise 129.5 -> 128 so every video shares one label
                abr = 48 if abr <= 80 else 128 if abr <= 190 else 256
                label = f"AAC {abr}k"
            else:
                label = f"WEBM {abr}k"
            e = {"id": fid, "src": fid, "conv": False, "br": None, "label": label,
                 "ext": ext, "abr": abr, "size": size}
            rank = (f.get("language_preference") or 0, size)
            if label not in auds or rank > auds[label][0]:
                auds[label] = (rank, e)
    videos = sorted((x[1] for x in vids.values()), key=lambda e: (-e["h"], -e["fps"]))
    audios = [x[1] for x in auds.values()]
    if audios:
        best = max(audios, key=lambda e: (e["abr"], e["ext"] == "m4a"))
        for br in MP3_RATES:
            audios.append({"id": f"{best['src']}-mp3-{br}", "src": best["src"], "conv": True,
                           "br": br, "label": f"MP3 {br}k", "ext": "mp3", "abr": br,
                           "size": int(dur * br * 1000 / 8) if dur else 0,
                           "dsize": best["size"]})
    if not videos and not audios:
        raise ApiError("No downloadable formats were found for this video.")
    out = {
        "title": info.get("title") or "Video " + vid,
        "thumb": thumb_of(vid),
        "duration": dur,
        "channel": info.get("channel") or info.get("uploader") or "",
        "videos": videos,
        "audios": audios,
    }
    with FORMATS_LOCK:
        FORMATS[ck] = (time.time(), out)
    return out


# ----------------------------------------------------------------------------
# job store
# ----------------------------------------------------------------------------
def public(j):
    return {k: v for k, v in j.items() if not k.startswith("_")}


BAK = {"t": 0.0}


def persist():
    """writes data.json: settings + every video (stage, progress, which pieces of each stream are finished)"""
    flush_all()
    with PERSIST_LOCK:
        try:
            with CV:
                data = []
                for j in JOBS.values():
                    p = public(j)
                    p["steps"] = {k: dict(v) for k, v in (j.get("steps") or {}).items()}
                    if j.get("stage") in ("done", "cancelled", "expired", "deleted"):
                        p.pop("parts", None)
                    data.append(p)
            blob = {"version": 3, "saved": time.time(), "settings": dict(SET), "jobs": data,
                    "stat": dict(STAT), "traffic": (globals().get("SPEED") or {}).get("total", 0)}
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            tmp = DATA_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(blob), encoding="utf-8")
            if DATA_FILE.exists() and time.time() - BAK["t"] > 60:      # a second copy, in case a crash cuts a write
                shutil.copyfile(DATA_FILE, DATA_FILE.with_suffix(".bak"))
                BAK["t"] = time.time()
            os.replace(tmp, DATA_FILE)
        except Exception:
            pass


def upd(j, **kw):
    with CV:
        j.update(kw)
        j["updated"] = time.time()


def step_init(j, key, text, est):
    with CV:
        j["steps"][key] = {"status": "pending", "text": text, "est": round(est, 1), "pct": 0, "spd": 0}


def step(j, key, status, text, eta=None, pct=None, spd=None):
    """update one step; remembers when it started / finished (separate time and % per step)"""
    now = time.time()
    with CV:
        s = j["steps"].get(key) or {}
        if status == "downloading" and not s.get("t0"):
            s["t0"] = now
        if status in ("done", "error") and not s.get("t1"):
            s["t1"] = now
        s["status"], s["text"] = status, text
        if eta is not None:
            s["eta"] = eta
        if pct is not None:
            s["pct"] = round(pct, 1)
        if spd is not None:
            s["spd"] = spd
        if status == "done":
            s["pct"], s["spd"] = 100, 0
        j["steps"][key] = s
        j["updated"] = now


def step_pct(j, key, pct):
    with CV:
        s = (j.get("steps") or {}).get(key)
        if s is not None:
            s["pct"] = round(pct, 1)


def load_jobs():
    dd = read_data()
    for k, v in (dd.get("stat") or {}).items():
        if k in STAT and isinstance(v, (int, float)):
            STAT[k] = float(v)
    try:
        SPEED["total"] = int(dd.get("traffic") or 0)
    except (TypeError, ValueError):
        pass
    data = dd.get("jobs") or []
    if not isinstance(data, list) or not data:
        return
    top = 0
    for j in data:
        j["_cancel"] = threading.Event()
        j["_pause"] = threading.Event()
        j["_upause"] = threading.Event()
        j["paused"] = False
        j["_limit"] = 0
        j["_phase"] = None
        j["_proc"] = None
        top = max(top, j.get("qseq") or 0)
        st = j.get("stage")
        if st == "cancelling":
            j["stage"] = "cancelled"
            shutil.rmtree(job_work(j), ignore_errors=True)
        elif st in LIVE or st == "queued":
            j["stage"] = "confirm"
            j["note"] = "Stopped when the program closed. What is already downloaded is saved: press Continue to carry on from there"
        elif st == "done" and not (j.get("file") and Path(j["file"]).exists()):
            j["stage"] = "deleted"
        JOBS[j["id"]] = j
    NEXT_Q[0] = top + 1


def _n(x):
    try:
        return max(0, int(x or 0))
    except (TypeError, ValueError):
        return 0


def make_job(it, compat, playlist, dest, use_cookies=False):
    vid = str(it.get("id") or "")
    if not re.fullmatch(r"[\w-]{11}", vid):
        raise ApiError("Bad video id")
    kind = it.get("kind")
    if kind not in ("video", "vonly", "audio"):
        raise ApiError("Bad download type")
    ok_id = re.compile(r"[\w.\-]{1,40}")
    v, a = it.get("v"), it.get("a")
    if kind in ("video", "vonly"):
        if not isinstance(v, dict) or not ok_id.fullmatch(str(v.get("id", ""))):
            raise ApiError("Bad video format")
        v = {"id": str(v["id"]), "label": str(v.get("label") or ""),
             "fam": str(v.get("fam") or ""), "h": v.get("h")}
    else:
        v = None
    if kind in ("video", "audio"):
        if not isinstance(a, dict) or not ok_id.fullmatch(str(a.get("src", ""))):
            raise ApiError("Bad audio format")
        a = {"id": str(a.get("id") or a["src"]), "src": str(a["src"]), "conv": bool(a.get("conv")),
             "br": _n(a.get("br")) or 192, "label": str(a.get("label") or ""),
             "ext": str(a.get("ext") or "")}
    else:
        a = None
    with CV:
        q = NEXT_Q[0]
        NEXT_Q[0] += 1
    return {
        "id": uuid.uuid4().hex[:12],
        "vid": vid,
        "title": str(it.get("title") or vid)[:300],
        "thumb": thumb_of(vid),
        "duration": it.get("duration") or 0,
        "channel": str(it.get("channel") or "")[:200],
        "kind": kind, "v": v, "a": a,
        "compat": bool(compat),
        "playlist": str(playlist)[:300] if playlist else None,
        "dest": str(dest),
        "fallback": (str(it.get("fb"))[:300] if it.get("fb") else None),
        "v_bytes": _n(it.get("v_bytes")), "a_bytes": _n(it.get("a_bytes")),
        "est_bytes": _n(it.get("est_bytes")),
        "use_cookies": bool(use_cookies), "cookie_need": False, "cookie_ask": "",
        "stage": "queued", "note": "", "qseq": q, "updated": time.time(),
        "steps": {}, "dl": 0, "merge": 0, "up": 0, "done_b": 0, "total_b": 0, "speed": 0,
        "started": None, "finished": None, "start_at": 0, "eta_at": 0,
        "expires_at": None, "file": None, "path": None,
        "_cancel": threading.Event(), "_pause": threading.Event(), "_upause": threading.Event(), "paused": False,
        "work": "", "_limit": 0, "_phase": None, "_proc": None,
    }


def plan(j):
    """estimated seconds of every step, from AVERAGE speeds"""
    kind = j["kind"]
    bps = avg_bps()
    dur = j.get("duration") or 0
    vb, ab = j.get("v_bytes") or 0, j.get("a_bytes") or 0
    if not (vb or ab) and j.get("est_bytes"):
        vb, ab = (j["est_bytes"], 0) if kind == "vonly" else (0, j["est_bytes"]) if kind == "audio" \
            else (j["est_bytes"] * 0.85, j["est_bytes"] * 0.15)
    p = {"p": 4.0}
    if kind in ("video", "vonly"):
        p["v"] = vb / bps
    if kind in ("video", "audio"):
        p["a"] = ab / bps
    if kind == "video":
        enc = j.get("compat") and (j.get("v") or {}).get("fam") != "h264"
        p["m"] = dur / enc_rate() if enc else 2 + (vb + ab) / 8e7
    if kind == "audio" and (j.get("a") or {}).get("conv"):
        p["c"] = 2 + dur / 40
    p["s"] = 1 + (vb + ab) / 1e8
    return p


def est_seconds(j):
    return sum(plan(j).values())


def remaining(j, now):
    """seconds left for a running job = what is left of each step"""
    pl = plan(j)
    steps = j.get("steps") or {}
    if not steps:
        return sum(pl.values())
    r = 0.0
    for k, s in steps.items():
        if s["status"] == "done":
            continue
        if s["status"] == "downloading":
            r += max(1.0, (s.get("eta") or now + pl.get(k, 1)) - now)
        else:
            r += s.get("est") or pl.get(k, 1)
    return r


def schedule(now):
    """Fills start_at / eta_at of every job and returns (active, queued, finish_at)."""
    with CV:
        act = [j for j in JOBS.values() if j["stage"] in LIVE]
        que = sorted((j for j in JOBS.values() if j["stage"] == "queued"), key=lambda x: x["qseq"])
        cur = now
        for j in act:
            rem = remaining(j, now)
            j["eta_at"] = now + rem
            cur = max(cur, now + rem)
        for j in que:
            j["start_at"] = cur
            cur += est_seconds(j)
            j["eta_at"] = cur
        return len(act), len(que), cur


def _rank(j):
    st = j["stage"]
    return 0 if st in LIVE else 1 if st in ("confirm", "error") else 2 if st == "queued" else 3


def jobs_payload(host, limit=80):
    now = time.time()
    a, q, fin = schedule(now)
    with CV:
        allj = list(JOBS.values())
        stopped = sum(1 for j in allj if j["stage"] in ("confirm", "error"))
        speed = sum((j.get("speed") or 0) for j in allj if j["stage"] == "downloading")
        allj.sort(key=lambda j: (_rank(j), j["qseq"] if _rank(j) < 3 else -(j.get("updated") or 0)))
        order = sorted((j for j in allj if j["stage"] in ("downloading", "queued")), key=lambda x: x["qseq"])
        pos = {j["id"]: i + 1 for i, j in enumerate(order)}
        out = []
        for j in allj[:limit]:
            p = public(j)
            p.pop("parts", None)
            p["pos"] = pos.get(j["id"], 0)
            p["steps"] = {k: dict(v) for k, v in (j.get("steps") or {}).items()}
            if j["stage"] == "done" and j.get("file"):
                p["direct"] = f"http://{host}/files/{j['id']}"
            if j["stage"] == "error" and j.get("cookie_need"):
                p["cookie_ask"] = str(current_cookies() or "")
            out.append(p)
    return {"now": now, "jobs": out,
            "summary": {"active": a, "queued": q, "stopped": stopped, "speed": speed, "finish_at": fin,
                        "smart": SMART.get("info")}}


# ----------------------------------------------------------------------------
# worker
# ----------------------------------------------------------------------------
RECOVER_FACTOR = 0.5            # while the second video runs, the first one only needs 50% of the minimum speed to take over again
FAST_CONN = 8                  # connections used for ONE file (jobs still run one after another)
FAST_CHUNK = 4 * 1024 * 1024   # every request asks for 4 MB, so each one starts at full speed


FLUSHERS = set()      # running fast downloads: each writes its list of finished pieces when asked


def flush_all():
    for f in list(FLUSHERS):
        try:
            f()
        except Exception:
            pass


def fast_ok(f):
    return bool(f.get("url")) and (f.get("protocol") or "") in ("https", "http") \
        and not f.get("fragments") and not f.get("has_drm")


def fast_download(f, path, cancel, report, pause=None, limit=None, state=None, save=None):
    """Downloads ONE stream over several connections at once (ranged requests written into one file).
    `state` (kept in data.json) remembers which 4 MB pieces are finished, so after a stop, a restart or days
    later only the missing pieces are downloaded. Raises on any problem. Returns the file size."""
    state = state if state is not None else {}
    path = str(path)
    if state.get("complete") and state.get("path") == path and os.path.exists(path) \
            and os.path.getsize(path) == state.get("total"):
        report(state["total"], state["total"], 0)
        return state["total"]
    url = f["url"]
    hdrs = {str(k): str(v) for k, v in (f.get("http_headers") or {}).items()}
    req = ureq.Request(url, headers=dict(hdrs, Range="bytes=0-0"))
    with ureq.urlopen(req, timeout=20) as r:
        cr = r.headers.get("Content-Range") or ""
        r.read(1)
    if "/" not in cr or not cr.split("/")[-1].isdigit():
        raise RuntimeError("server does not support ranges")
    total = int(cr.split("/")[-1])
    if total <= 0:
        raise RuntimeError("unknown size")
    chunks = [(a, min(a + FAST_CHUNK, total) - 1) for a in range(0, total, FAST_CHUNK)]
    done_set = set()
    partial = {}                         # piece number -> next byte to fetch (pieces that are already part-way)
    if (state.get("total") == total and state.get("chunk") == FAST_CHUNK and state.get("path") == path
            and os.path.exists(path) and os.path.getsize(path) == total):
        try:
            raw = bytes.fromhex(state.get("done") or "")
        except ValueError:
            raw = b""
        done_set = {i for i in range(len(chunks)) if i // 8 < len(raw) and (raw[i // 8] >> (i % 8)) & 1}
        for k, v in (state.get("partial") or {}).items():       # a half-finished piece carries on where it stopped
            try:
                i, v = int(k), int(v)
            except (TypeError, ValueError):
                continue
            if 0 <= i < len(chunks) and i not in done_set and chunks[i][0] < v <= chunks[i][1]:
                partial[i] = v
    else:
        with open(path, "wb") as fo:
            fo.truncate(total)
    state.update(total=total, chunk=FAST_CHUNK, path=path, complete=False)
    lock = threading.Lock()
    stop = threading.Event()
    todo = deque(i for i in range(len(chunks)) if i not in done_set)
    st = {"done": sum(chunks[i][1] - chunks[i][0] + 1 for i in done_set)
          + sum(v - chunks[i][0] for i, v in partial.items()), "err": None}

    def flush():                         # called by persist(): the saved list of finished pieces is always current
        with lock:
            snapshot()

    def snapshot():                      # called with `lock` held
        ba = bytearray((len(chunks) + 7) // 8)
        for i in done_set:
            ba[i // 8] |= 1 << (i % 8)
        state["done"] = ba.hex()
        state["partial"] = {str(i): v for i, v in partial.items() if i not in done_set}

    tl = threading.Lock()
    tst = {"t": 0.0}

    def throttle(n):
        """shared speed limit of this file (all connections together); limit() gives bytes/s, 0 = none"""
        rate = limit() if limit else 0
        if not rate:
            tst["t"] = 0.0
            return
        with tl:
            now = time.time()
            tst["t"] = max(tst["t"], now - 0.25) + n / rate
            dead = tst["t"] - 0.25
        while time.time() < dead and not stop.is_set() and not cancel.is_set() and limit():
            time.sleep(0.1)

    def hold():
        while pause is not None and pause.is_set() and not stop.is_set() and not cancel.is_set():
            time.sleep(0.3)

    def worker(fd):
        while not stop.is_set() and not cancel.is_set():
            hold()
            with lock:
                if not todo:
                    return
                idx = todo.popleft()
            a, b = chunks[idx]
            pos, tries = max(a, partial.get(idx, a)), 0
            while pos <= b and not stop.is_set() and not cancel.is_set():
                hold()                                   # paused: no connection is open while waiting
                try:
                    rq = ureq.Request(url, headers=dict(hdrs, Range=f"bytes={pos}-{b}"))
                    paused_out = False
                    with ureq.urlopen(rq, timeout=20) as r:
                        if r.status != 206:
                            raise RuntimeError("range not honoured")
                        while pos <= b:
                            if pause is not None and pause.is_set():
                                paused_out = True        # close this connection; reopen from `pos` after the pause
                                break
                            n = min(1 << 18, b - pos + 1)
                            lim = limit() if limit else 0
                            if lim:
                                n = min(n, max(1024, int(lim / 4)))
                                throttle(n)
                            buf = r.read(n)
                            if stop.is_set() or cancel.is_set():
                                return
                            if not buf:
                                break
                            with lock:
                                fd.seek(pos)
                                fd.write(buf)
                                st["done"] += len(buf)
                                partial[idx] = pos + len(buf)
                            pos += len(buf)
                            tries = 0
                    if paused_out:
                        continue
                    if pos <= b:
                        raise RuntimeError("connection closed early")
                except Exception as e:
                    if getattr(e, "code", None) in (401, 403, 404, 410):     # the link expired: needs fresh links
                        st["err"] = e
                        stop.set()
                        return
                    tries += 1
                    if tries > 8:
                        st["err"] = e
                        stop.set()
                        return
                    time.sleep(min(4, tries))
            if pos > b:
                with lock:
                    done_set.add(idx)
                    partial.pop(idx, None)

    FLUSHERS.add(flush)
    with open(path, "r+b", buffering=0) as fd:       # unbuffered: a piece marked finished really is on disk
        ths = [threading.Thread(target=worker, args=(fd,), daemon=True) for _ in range(min(FAST_CONN, max(1, len(todo))))]
        for t in ths:
            t.start()
        samples = deque([(time.time(), st["done"])])
        last_save = time.time()
        try:
            while any(t.is_alive() for t in ths):
                time.sleep(0.5)
                now = time.time()
                with lock:
                    done = st["done"]
                if pause is not None and pause.is_set():
                    samples.clear()
                    samples.append((now, done))
                    report(done, total, 0)
                else:
                    samples.append((now, done))
                    while len(samples) > 2 and now - samples[0][0] > 3:
                        samples.popleft()
                    t0, b0 = samples[0]
                    report(done, total, (done - b0) / (now - t0) if now > t0 else 0)
                if save and now - last_save >= 2:
                    last_save = now
                    with lock:
                        snapshot()
                    save()
        finally:
            stop.set()
            for t in ths:
                t.join(timeout=5)
            FLUSHERS.discard(flush)
            with lock:
                snapshot()
            if save:
                save()
    if cancel.is_set():
        raise JobCancelled()
    if st["err"]:
        raise st["err"]
    if len(done_set) != len(chunks):
        raise RuntimeError("incomplete download")
    state["complete"] = True
    if save:
        save()
    return total


def find_file(work, fid):
    for n in sorted(os.listdir(work)):
        if n.startswith(fid + ".") and not n.endswith((".part", ".ytdl", ".temp", ".tmp")):
            return str(Path(work) / n)
    return None


def _proc_suspend(p, on):
    """freeze / unfreeze a running process (Linux, macOS, Termux, Windows)"""
    try:
        if os.name == "nt":
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x0800, False, p.pid)
            if h:
                (ctypes.windll.ntdll.NtSuspendProcess if on else ctypes.windll.ntdll.NtResumeProcess)(h)
                ctypes.windll.kernel32.CloseHandle(h)
        else:
            os.kill(p.pid, signal.SIGSTOP if on else signal.SIGCONT)
    except Exception:
        pass


def _merge_governor(p, j, stop):
    """Runs next to ffmpeg. j["_mlimit"] = allowed share of full speed in percent (0 = no limit)."""
    frozen = False
    try:
        while not stop.is_set():
            if _up(j):                                   # paused by you: freeze ffmpeg completely
                if not frozen:
                    _proc_suspend(p, True)
                    frozen = True
                stop.wait(0.3)
                continue
            pct = int(j.get("_mlimit") or 0)
            if pct <= 0 or pct >= 100:
                if frozen:
                    _proc_suspend(p, False)
                    frozen = False
                stop.wait(0.3)
                continue
            run = 0.3 * pct / 100.0
            if frozen:
                _proc_suspend(p, False)
                frozen = False
            if stop.wait(run):
                break
            _proc_suspend(p, True)
            frozen = True
            stop.wait(0.3 - run)
    finally:
        if frozen:
            _proc_suspend(p, False)


def run_ffmpeg(j, cmd, dur, field, skey):
    """runs ffmpeg, updates the progress % + that step's own estimate, returns seconds taken"""
    cancel = j["_cancel"]
    t0 = time.time()
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors="replace", bufsize=1)
    except FileNotFoundError:
        raise RuntimeError("ffmpeg is not installed (Termux: pkg install ffmpeg)")
    j["_proc"] = p
    gstop = threading.Event()
    threading.Thread(target=_merge_governor, args=(p, j, gstop), daemon=True).start()
    tail = []
    prog_key = re.compile(r"^(frame|fps|stream_\S+|bitrate|total_size|out_time\S*|dup_frames|drop_frames|speed|progress)=")
    try:
        for line in p.stdout:
            if cancel.is_set():
                _proc_suspend(p, False)
                p.terminate()
                break
            line = line.strip()
            m = re.match(r"out_time_(?:us|ms)=(\d+)", line)
            if m:
                if dur:
                    pct = min(99.0, int(m.group(1)) / 1e6 / dur * 100)
                    if field:
                        upd(j, **{field: pct})
                    el = time.time() - t0
                    if skey:
                        if pct >= 3 and el > 1:
                            step(j, skey, "downloading", j["steps"][skey]["text"],
                                 eta=t0 + el * 100 / pct, pct=pct)
                        else:
                            step_pct(j, skey, pct)
            elif line and not prog_key.match(line):
                tail.append(line)
                tail = tail[-6:]
        rc = p.wait()
    finally:
        gstop.set()
        j["_proc"] = None
    if cancel.is_set():
        raise JobCancelled()
    if rc != 0:
        raise RuntimeError("ffmpeg failed: " + " | ".join(tail[-3:]))
    if field:
        upd(j, **{field: 100})
    return time.time() - t0


def copy_with_progress(src, dst, j):
    src, dst = Path(src), Path(dst)
    try:
        os.replace(src, dst)           # same disk: instant
        upd(j, up=100)
        return
    except OSError:
        pass
    total = src.stat().st_size or 1
    done = 0
    try:
        with open(src, "rb") as fi, open(dst, "wb") as fo:
            while True:
                if j["_cancel"].is_set():
                    raise JobCancelled()
                while _up(j):
                    if j["_cancel"].is_set():
                        raise JobCancelled()
                    time.sleep(0.3)
                b = fi.read(1 << 20)
                if not b:
                    break
                fo.write(b)
                done += len(b)
                pct = min(99.0, done * 100 / total)
                upd(j, up=pct)
                step_pct(j, "s", pct)
    except BaseException:
        try:
            dst.unlink()
        except OSError:
            pass
        raise
    src.unlink()
    upd(j, up=100)


def run_job(j):
    jid = j["id"]
    cancel = j["_cancel"]
    ensure_work()
    work = job_work(j) if j.get("work") else (LEGACY_WORK / jid if (LEGACY_WORK / jid).exists() else WORK_DIR / jid)
    j["work"] = str(work)
    work.mkdir(parents=True, exist_ok=True)
    kind = j["kind"]
    v = j.get("v") or {}
    a = j.get("a") or {}
    dur = j.get("duration") or 0
    final = None
    try:
        pl = plan(j)
        with CV:
            j["steps"] = {}
        # every stage gets its own line, its own %, its own time taken and its own estimate
        step_init(j, "p", "Preparing: waiting", pl["p"])
        if kind in ("video", "vonly"):
            step_init(j, "v", "Video stream: waiting", pl["v"])
        if kind in ("video", "audio"):
            step_init(j, "a", "Audio stream: waiting", pl["a"])
        if kind == "video":
            step_init(j, "m", "Merge: waiting", pl["m"])
        if kind == "audio" and a.get("conv"):
            step_init(j, "c", f"Convert to MP3 {a.get('br')}k: waiting", pl["c"])
        step_init(j, "s", "Save to folder: waiting", pl["s"])
        step(j, "p", "downloading", "Preparing: reading video info...", eta=time.time() + pl["p"])

        use_ck = bool(j.get("use_cookies"))
        if use_ck and not current_cookies():
            raise RuntimeError("cookies.txt was not found any more. Put it back and try again.")

        # ---------------- 1. download the streams ----------------
        want = []
        if kind in ("video", "vonly"):
            want.append(("v", v["id"]))
        if kind in ("video", "audio"):
            want.append(("a", a["src"]))
        fkey = {fid: key for key, fid in want}
        names = {"v": "Video stream", "a": "Audio stream"}
        sizes = {"v": j.get("v_bytes") or 0, "a": j.get("a_bytes") or 0}
        prog, paths, fin = {}, {}, set()
        est = j.get("est_bytes") or (sizes["v"] + sizes["a"])
        first = [False]

        rl_state = {}
        pabort = [False]

        def hook(d):
            if cancel.is_set():
                raise JobCancelled()
            if not d.get("_fast"):
                t_p = None
                while j["_pause"].is_set() or j["_upause"].is_set():     # paused (by you / by the switch)
                    if cancel.is_set():
                        raise JobCancelled()
                    if j["_upause"].is_set():
                        t_p = t_p or time.time()
                        if time.time() - t_p > 2:        # a real pause: stop the transfer completely, carry on later
                            pabort[0] = True
                            raise PauseAbort()
                    time.sleep(0.3)
                lim = j.get("_limit") or 0
                if lim and d.get("status") == "downloading":
                    fid0 = str((d.get("info_dict") or {}).get("format_id") or "")
                    dn0 = d.get("downloaded_bytes") or 0
                    r0 = rl_state
                    if r0.get("lim") != lim or r0.get("fid") != fid0 or dn0 < r0.get("b", 0):
                        r0.update(t=time.time(), b=dn0, lim=lim, fid=fid0)
                    while True:
                        lim = j.get("_limit") or 0
                        if not lim or cancel.is_set() or j["_pause"].is_set() or j["_upause"].is_set():
                            break
                        if r0.get("lim") != lim:
                            r0.update(t=time.time(), b=dn0, lim=lim)
                        need = (dn0 - r0["b"]) / lim - (time.time() - r0["t"])
                        if need <= 0:
                            break
                        time.sleep(min(need, 0.3))
                    if cancel.is_set():
                        raise JobCancelled()
                else:
                    rl_state.clear()
            now = time.time()
            if not first[0]:
                first[0] = True
                step(j, "p", "done", "Preparing: ready \u2713")
            fid = str((d.get("info_dict") or {}).get("format_id") or "")
            key = fkey.get(fid)
            st = d.get("status")
            inst = None                      # live (instantaneous) speed from yt-dlp
            if st == "downloading":
                done = d.get("downloaded_bytes") or 0
                tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                prog[fid] = [done, tot]
                inst = d.get("speed")
                if key:
                    t0 = (j["steps"].get(key) or {}).get("t0") or now
                    el = now - t0
                    total_k = tot or sizes[key]
                    # AVERAGE speed of this stream so far (global average at the very start): used for ETA only
                    rate = done / el if el >= 3 and done > 0 else avg_bps()
                    pct = min(99.9, done * 100 / total_k) if total_k else 0
                    step(j, key, "downloading", f"{names[key]}: downloading...",
                         eta=(now + max(0, total_k - done) / max(rate, 1e4)) if total_k else None,
                         pct=pct, spd=inst or 0)
            elif st == "finished":
                done = d.get("total_bytes") or d.get("downloaded_bytes") or prog.get(fid, [0, 0])[0]
                prog[fid] = [done, done]
                paths[fid] = d.get("filename")
                fin.add(fid)
                inst = 0
                if key:
                    step(j, key, "done", f"{names[key]}: downloaded \u2713")
                    s = j["steps"][key]
                    el = (s.get("t1") or now) - (s.get("t0") or now)
                    if el > 1 and done > 5e4:
                        STAT["dl_b"] += done
                        STAT["dl_s"] += el
            dn = sum(p[0] for p in prog.values())
            known = sum(max(p[0], p[1]) for p in prog.values())
            total = known if len(prog) >= len(want) else max(known, est)
            pct = 100.0 if len(fin) >= len(want) else (min(99.0, dn * 100 / total) if total else 0)
            kw = {"dl": pct, "done_b": dn, "total_b": total}
            if inst is not None:
                kw["speed"] = inst
            upd(j, **kw)

        opts = {
            "format": ",".join(fid for _, fid in want),
            "outtmpl": str(work / "%(format_id)s.%(ext)s"),
            "noplaylist": True,
            "continuedl": True,
            "retries": 8,
            "fragment_retries": 8,
            "concurrent_fragment_downloads": 16,   # fragmented streams: many pieces at once
            "http_chunk_size": 4194304,            # 4 MB ranged requests: every piece starts at full speed, so it stays steady
            "buffersize": 1 << 18,
            "progress_hooks": [hook],
        }
        watch = "https://www.youtube.com/watch?v=" + j["vid"]
        pabort[0] = False

        def wait_resume():
            """a video you paused stays paused here, also while it is only preparing"""
            while _up(j):
                if cancel.is_set():
                    raise JobCancelled()
                time.sleep(0.3)

        def extract():
            with Y({"noplaylist": True, "skip_download": True}, "", use_ck) as ydl:
                inf = ydl.extract_info(watch, download=False) or {}
            return {str(x.get("format_id")): x for x in (inf.get("formats") or [])}

        try:
            wait_resume()
            # fast path: each stream over several connections at once (falls back to plain yt-dlp on any problem)
            fast = {}
            try:
                fast = extract()
            except Exception:
                if cancel.is_set():
                    raise JobCancelled()
            parts = j.setdefault("parts", {})          # saved in data.json: which pieces of each stream are finished
            for _key, fid in want:
                wait_resume()
                fm = fast.get(fid)
                if not fm or not fast_ok(fm):
                    continue
                fpath = str(work / f"{fid}.{fm.get('ext') or 'bin'}")
                info = {"format_id": fid}
                stt = parts.setdefault(fid, {})
                ok = False
                for attempt in range(3):
                    try:
                        size = fast_download(fm, fpath, cancel, lambda dn, tt, sp, fid=fid, info=info: hook(
                            {"status": "downloading", "downloaded_bytes": dn, "total_bytes": tt,
                             "speed": sp, "info_dict": info, "_fast": True}), Either(j["_pause"], j["_upause"]),
                            lambda: j.get("_limit") or 0, stt, persist)
                        hook({"status": "finished", "filename": fpath, "total_bytes": size, "info_dict": info})
                        ok = True
                        break
                    except JobCancelled:
                        raise
                    except Exception as fe:
                        if cancel.is_set():
                            raise JobCancelled()
                        print("[fast download] format %s, try %d: %s" % (fid, attempt + 1, clean_err(fe)))
                        if attempt == 2:
                            break
                        wait_resume()
                        time.sleep(2)
                        try:
                            fm = extract().get(fid) or fm        # fresh links: the old ones may have expired
                        except Exception:
                            if cancel.is_set():
                                raise JobCancelled()
                if not ok:
                    print("[fast download] using yt-dlp for format %s instead" % fid)
                    prog.pop(fid, None)
                    parts.pop(fid, None)
                    try:
                        os.remove(fpath)
                    except OSError:
                        pass
            left = [fid for _k, fid in want if fid not in fin]
            while left:
                wait_resume()
                opts["format"] = ",".join(left)
                pabort[0] = False
                try:
                    with Y(opts, "", use_ck) as ydl:       # cookies only if the user allowed it for this job
                        ydl.download([watch])
                    break
                except Exception:
                    if cancel.is_set():
                        raise JobCancelled()
                    if pabort[0]:                          # stopped on purpose because you paused it
                        left = [fid for _k, fid in want if fid not in fin]
                        continue
                    raise
        except Exception:
            if cancel.is_set():
                raise JobCancelled()
            raise
        if cancel.is_set():
            raise JobCancelled()
        if not first[0]:
            step(j, "p", "done", "Preparing: ready \u2713")
        files = {}
        for key, fid in want:
            p = paths.get(fid)
            if not p or not os.path.exists(p):
                p = find_file(work, fid)
            if not p:
                raise RuntimeError(f"Download of format {fid} produced no file")
            files[key] = p
            if (j["steps"].get(key) or {}).get("status") != "done":
                step(j, key, "done", f"{names[key]}: downloaded \u2713")
        upd(j, dl=100, speed=0)
        post_gate(j)           # the next video may start downloading while this one merges / saves

        # ---------------- 2. merge / convert ----------------
        if kind == "video":
            fam = v.get("fam")
            h264 = fam == "h264" or j.get("compat")
            need_enc = j.get("compat") and fam != "h264"
            container = "mp4" if h264 else "mkv"
            out = work / f"merged.{container}"
            cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-nostats",
                   "-progress", "pipe:1", "-i", files["v"], "-i", files["a"],
                   "-map", "0:v:0", "-map", "1:a:0"]
            if need_enc:
                cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p"]
            else:
                cmd += ["-c:v", "copy"]
            if a.get("conv"):
                cmd += ["-c:a", "libmp3lame", "-b:a", f"{a.get('br') or 192}k"]
            elif container == "mp4" and a.get("ext") != "m4a":
                cmd += ["-c:a", "aac", "-b:a", "192k"]
            else:
                cmd += ["-c:a", "copy"]
            if container == "mp4":
                cmd += ["-movflags", "+faststart"]
            cmd.append(str(out))
            upd(j, stage="merging", merge=0, speed=0)
            step(j, "m", "downloading",
                 "Merge: converting to H.264 and joining..." if need_enc else "Merge: joining video and audio...",
                 eta=time.time() + pl.get("m", 2), pct=0)
            took = run_ffmpeg(j, cmd, dur, "merge", "m")
            if need_enc and dur and took > 1:
                STAT["enc_m"] += dur
                STAT["enc_s"] += took
            step(j, "m", "done", "Merge: finished \u2713")
            ext = container
        elif kind == "vonly":
            out = Path(files["v"])
            ext = out.suffix.lstrip(".") or "mp4"
        else:
            if a.get("conv"):
                out = work / "audio.mp3"
                upd(j, stage="merging", merge=0, speed=0)
                step(j, "c", "downloading", f"Convert to MP3 {a.get('br')}k: working...",
                     eta=time.time() + pl.get("c", 2), pct=0)
                run_ffmpeg(j, ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-nostats",
                               "-progress", "pipe:1", "-i", files["a"], "-vn",
                               "-c:a", "libmp3lame", "-b:a", f"{a.get('br') or 192}k", str(out)],
                           dur, "merge", "c")
                step(j, "c", "done", "Convert: finished \u2713")
                ext = "mp3"
            else:
                out = Path(files["a"])
                ext = out.suffix.lstrip(".") or a.get("ext") or "m4a"

        # ---------------- 3. save into the chosen folder ----------------
        ql = a.get("label") if kind == "audio" else v.get("label") if kind == "vonly" \
            else f"{v.get('label')} + {a.get('label')}"
        name = f"{safe_name(j['title'], 120)} [{j['vid']}] {safe_name(ql, 60)}.{ext}"
        dest = Path(j.get("dest") or OUTPUT_DIR)
        try:
            dest.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(f"Cannot use the folder {dest}: {e}")
        final = unique_path(dest / name)
        upd(j, stage="uploading", up=0, speed=0)
        step(j, "s", "downloading", "Save to folder: working...", eta=time.time() + pl.get("s", 1), pct=0)
        copy_with_progress(out, final, j)
        step(j, "s", "done", "Save to folder: finished \u2713")
        shutil.rmtree(work, ignore_errors=True)
        keep = KEEP_AUDIO if kind == "audio" else KEEP_VIDEO
        now = time.time()
        upd(j, stage="done", finished=now, file=str(final), path=str(final), note="",
            dl=100, merge=100, up=100, speed=0, cookie_need=False,
            expires_at=(now + keep * 3600) if keep else None)
    except JobCancelled:
        if final:
            try:
                Path(final).unlink()
            except OSError:
                pass
        shutil.rmtree(work, ignore_errors=True)
        upd(j, stage="cancelled", note="", speed=0)
    except Exception as exc:
        msg = clean_err(exc)
        for k, s in list(j["steps"].items()):
            if s["status"] == "downloading":
                step(j, k, "error", s["text"])
        # a cookies.txt problem: ask the user first, never use the file silently
        need = bool(COOKIE_RE.search(msg)) and not j.get("use_cookies")
        upd(j, stage="error", note=msg, speed=0, cookie_need=need)
    finally:
        j["_proc"] = None
        persist()


def _begin(j):
    """mark a queued job as started (called with CV held)"""
    j["stage"] = "downloading"
    j["started"] = time.time()
    j["finished"] = None
    j["note"] = ""
    j["dl"] = j["merge"] = j["up"] = 0
    j["done_b"] = 0
    j["speed"] = 0
    j["total_b"] = j.get("est_bytes") or 0
    j["_cancel"].clear()
    j["_pause"].clear()
    j["_limit"] = 0
    j["_mlimit"] = 0
    j["_phase"] = "dl"
    if not (j.get("work") and Path(j["work"]).exists()):
        j["work"] = ""


def dl_cap():
    """how many videos may download at the same time"""
    if SET["par_dl"]:
        return max(1, int(SET["par_n"]))
    return 2 if SET["smart"] else 1


def post_cap():
    """how many videos may merge / save at the same time"""
    return max(1, int(SET["merge_n"])) if SET["par_merge"] else 1


def _count(phase):
    return sum(1 for x in JOBS.values() if x.get("_phase") == phase)


def post_gate(j):
    """Called when a video has finished downloading. Frees its download slot (so the next video can
    start) and waits for a free merge / save slot."""
    cancel = j["_cancel"]
    shown = False
    with CV:
        j["_phase"] = "wait"
        CV.notify_all()
        while True:
            if cancel.is_set():
                raise JobCancelled()
            ok = _count("post") < post_cap() and (SET["dl_merge"] or _count("dl") == 0)
            if ok:
                j["_phase"] = "post"
                CV.notify_all()
                break
            if not shown:
                shown = True
                a = j.get("a") or {}
                j["stage"] = "merging" if (j["kind"] == "video" or (j["kind"] == "audio" and a.get("conv"))) \
                    else "uploading"
                j["note"] = "Waiting for its turn"
                j["speed"] = 0
                j["updated"] = time.time()
            CV.wait(0.5)
    if shown:
        upd(j, note="")


def _run_thread(j):
    try:
        run_job(j)
    except Exception as exc:       # never let a job thread die silently
        upd(j, stage="error", note=clean_err(exc), speed=0)
    finally:
        with CV:
            j["_phase"] = None
            CV.notify_all()


def dispatcher():
    """Starts queued videos in order. Downloads: 1 at a time (more only if allowed in Settings or if the
    slow-download switch asks for it). Merging / saving of a finished video runs next to the next download."""
    while True:
        with CV:
            while True:
                j = None
                que = [x for x in JOBS.values() if x["stage"] == "queued" and not _up(x)]
                if que and not MAINT["on"]:
                    n_dl = sum(1 for x in JOBS.values() if x.get("_phase") == "dl" and not _up(x))
                    ok = n_dl < dl_cap()
                    if ok and not SET["dl_merge"] and (_count("wait") or _count("post")):
                        ok = False
                    if ok and n_dl > 0 and not SET["par_dl"]:
                        ok = bool(SET["smart"] and SMART["go"])
                    if ok:
                        j = min(que, key=lambda x: x["qseq"])
                        _begin(j)
                        if n_dl > 0 and not SET["par_dl"]:
                            SMART["go"] = False
                        break
                CV.wait(1.0)
        persist()
        threading.Thread(target=_run_thread, args=(j,), daemon=True).start()


def _apply(j, pause, limit, note, merge=0):
    """slow one video down: limit = download speed in bytes/s, merge = share of full merge speed in percent
    (0 = full speed). Nothing is ever frozen completely."""
    new = (bool(pause), int(limit or 0), int(merge or 0))
    cur = (j["_pause"].is_set(), int(j.get("_limit") or 0), int(j.get("_mlimit") or 0))
    held = new != (False, 0, 0)
    if cur == new and (not held or j.get("note") == note):
        return
    if new[0]:
        j["_pause"].set()
    else:
        j["_pause"].clear()
    j["_limit"] = new[1]
    j["_mlimit"] = new[2]
    if held:
        upd(j, note=note, speed=0 if new[0] else (j.get("speed") or 0))
        j["_rnote"] = note
    else:
        if j.get("_rnote") and j.get("note") == j["_rnote"]:
            upd(j, note="")
        j["_rnote"] = ""


def rate_tick(st):
    """Decides, every second, which videos run at full speed. Order = the order the videos were selected
    (playlist order): first, second, third ...
    DOWNLOADS: as many videos as 'several at once' allows run at full speed (1 normally, 2 with auto-switch).
      Every further video that is already downloading is slowed down (Settings: speed of extra videos).
      Auto-switch (only when 'several at once' is off): if the first video stays below the minimum speed for the
      wait time, the second one starts too; when the first is fast again for the wait time, the second one is
      limited (Settings: second video speed) until the first is slow again.
    MERGES: as many merges as 'merge several at once' allows run at full speed; further merges that are already
      running are slowed to a share of full speed (Settings).
    If 'download while merging' is off but both are running, the older video wins and the other side is slowed."""
    with CV:
        live = sorted((j for j in JOBS.values() if j["stage"] == "downloading" and not _up(j)), key=lambda x: x["qseq"])
        posts = sorted((j for j in JOBS.values() if j.get("_phase") == "post"), key=lambda x: x["qseq"])
        queued = any(j["stage"] == "queued" and not _up(j) for j in JOBS.values())
        alljobs = list(JOBS.values())
    SMART["info"] = None
    busy = {j["id"] for j in live} | {j["id"] for j in posts}
    for j in alljobs:
        if j["id"] not in busy:
            _apply(j, False, 0, "")
    cap = dl_cap()
    smart_on = bool(SET["smart"]) and not SET["par_dl"]
    extra_bps = int(SET["extra_kb"] * 1000)
    second_bps = int(SET["second_kb"] * 1000)
    pct = int(SET["merge_pct"])
    # download while merging switched off, but both are running: the older video keeps full speed
    conf_dl = conf_post = False
    if not SET["dl_merge"] and live and posts:
        if posts[0]["qseq"] < live[0]["qseq"]:
            conf_dl = True
        else:
            conf_post = True
    for i, j in enumerate(posts):
        if conf_post or i >= post_cap():
            _apply(j, False, 0, "Slowed to %d%% speed: merging is limited" % pct, pct)
        else:
            _apply(j, False, 0, "")
    if not live:
        SMART["go"] = False
        st.update(pid=None, slow=None, fast=None, held=False)
        return
    now = time.time()
    prim = live[0]
    if st.get("pid") != prim["id"]:
        st.update(pid=prim["id"], slow=None, fast=None, held=False)
    wait = SET["wait_s"]
    slow_long = fast_long = False
    if smart_on:
        isdl = (prim.get("done_b") or 0) > 0
        thr = SET["min_mb"] * 1e6
        if len(live) > 1:
            thr *= RECOVER_FACTOR          # a second video is running: ONE steady limit of 50% of the minimum (no flip-flop)
        if isdl and (prim.get("speed") or 0) < thr:
            st["slow"] = st.get("slow") or now
            st["fast"] = None
        elif isdl:
            st["fast"] = st.get("fast") or now
            st["slow"] = None
        else:
            st["slow"] = st["fast"] = None
            st["held"] = False
        slow_long = bool(st.get("slow")) and now - st["slow"] >= wait
        fast_long = bool(st.get("fast")) and now - st["fast"] >= wait
        if fast_long:
            st["held"] = True
        elif slow_long:
            st["held"] = False
    else:
        st.update(slow=None, fast=None, held=False)
    for i, j in enumerate(live):
        if conf_dl or i >= cap:
            _apply(j, False, extra_bps, "Slowed to %d KB/s: only the first video downloads at full speed" % SET["extra_kb"])
        elif i >= 1 and smart_on and st.get("held"):
            _apply(j, False, second_bps, "Limited to %d KB/s: the first video is downloading fast" % SET["second_kb"])
        else:
            _apply(j, False, 0, "")
    can_start = queued and len(live) < cap
    SMART["go"] = bool(smart_on and slow_long and can_start)
    info = None
    if smart_on:
        others = live[1:cap]
        if st.get("slow"):
            left = max(0, int(wait - (now - st["slow"]) + 0.99))
            if others and st.get("held"):
                info = {"kind": "resume", "left": left}
            elif not others and can_start:
                info = {"kind": "switch", "left": left}
        elif st.get("fast") and others and not st.get("held"):
            info = {"kind": "pause", "left": max(0, int(wait - (now - st["fast"]) + 0.99))}
    SMART["info"] = info
    if SMART["go"]:
        with CV:
            CV.notify_all()


def smart_loop():
    st = {}
    last = ""
    while True:
        time.sleep(1)
        try:
            rate_tick(st)
        except Exception:
            tb = traceback.format_exc()
            if tb != last:                 # show a problem once in the console instead of hiding it
                last = tb
                print("[speed control] " + tb)


# ---- speed history (for the graph that opens when you click the speed on the page)
SPEED = {"pts": deque(maxlen=21600), "total": 0, "t0": time.time(), "last": {}}     # pts: (time, bytes/s, bytes)
SPEED_LOCK = threading.Lock()


def sampler():
    last_t = time.time()
    while True:
        time.sleep(1)
        now = time.time()
        dt = max(0.2, now - last_t)
        last_t = now
        b = 0
        with CV:
            for j in list(JOBS.values()):
                d = j.get("done_b") or 0
                jid = j["id"]
                if j["stage"] == "downloading":
                    prev = SPEED["last"].get(jid, 0)
                    if d > prev:
                        b += d - prev
                    SPEED["last"][jid] = d
                elif jid in SPEED["last"]:
                    prev = SPEED["last"].pop(jid)
                    if d > prev:
                        b += d - prev
        with SPEED_LOCK:
            SPEED["pts"].append((now, b / dt, b))
            SPEED["total"] += b


def api_speedlog(qs):
    secs = min(21600, max(30, _int(qs.get("secs"), 300)))
    now = time.time()
    lo = now - secs
    with SPEED_LOCK:
        raw = [p for p in SPEED["pts"] if p[0] >= lo]
        total = SPEED["total"]
    bucket = max(1, -(-secs // 300))
    acc = {}
    for t, bps, by in raw:
        k = int((t - lo) // bucket)
        a = acc.setdefault(k, [0.0, 0])
        a[0] += bps
        a[1] += 1
    pts = [[round(lo + k * bucket + bucket / 2, 1), round(v[0] / v[1])] for k, v in sorted(acc.items())]
    used = sum(p[2] for p in raw)
    return {"now": now, "secs": secs, "bucket": bucket, "points": pts,
            "range_bytes": used, "total_bytes": total, "since": SPEED["t0"],
            "peak": max((p[1] for p in raw), default=0),
            "avg": used / max(1.0, min(secs, now - SPEED["t0"]))}


def sweeper():
    while True:
        time.sleep(30)
        now = time.time()
        with CV:
            due = [j for j in JOBS.values()
                   if j["stage"] == "done" and j.get("expires_at") and j["expires_at"] <= now]
        for j in due:
            try:
                Path(j["file"]).unlink()
            except OSError:
                pass
            upd(j, stage="expired")
        if due:
            persist()


# ----------------------------------------------------------------------------
# job actions
# ----------------------------------------------------------------------------
def cancel_job(j):
    with CV:
        st = j["stage"]
        if st in ("queued", "confirm", "error"):
            j["stage"] = "cancelled"
            j["note"] = ""
        elif st in LIVE and st != "cancelling":
            j["stage"] = "cancelling"
            j["_cancel"].set()
            j["_upause"].clear()
            j["paused"] = False
            p = j.get("_proc")
            if p:
                try:
                    p.terminate()
                except Exception:
                    pass
        else:
            return
        cancelled = j["stage"] == "cancelled"
    if cancelled:
        shutil.rmtree(job_work(j), ignore_errors=True)


def resume_job(j):
    with CV:
        if j["stage"] not in ("confirm", "error"):
            return
        j["stage"] = "queued"
        j["note"] = ""
        j["cookie_need"] = False
        j["qseq"] = NEXT_Q[0]
        NEXT_Q[0] += 1
        j["_cancel"].clear()
        CV.notify_all()


def skip_job(j):
    with CV:
        if j["stage"] not in ("confirm", "error"):
            return
        ok = bool(j.get("file") and Path(j["file"]).exists())
        j["stage"] = "done" if ok else "cancelled"
        j["note"] = ""
        if ok:
            j["finished"] = j.get("finished") or time.time()
    if not ok:
        shutil.rmtree(job_work(j), ignore_errors=True)


def delete_job_file(j):
    with CV:
        if j["stage"] != "done":
            return
    try:
        Path(j["file"]).unlink()
    except OSError:
        pass
    upd(j, stage="deleted")


PAUSE_NOTE_U = "Paused by you"


def pause_job(j, on):
    with CV:
        if on:
            if j["stage"] not in LIVE and j["stage"] != "queued" or j["stage"] == "cancelling":
                return
            if j["_upause"].is_set():
                return
            j["_upause"].set()
            j["paused"] = True
            j["note"] = PAUSE_NOTE_U
            j["speed"] = 0
            j["updated"] = time.time()
        else:
            if not j["_upause"].is_set():
                return
            j["_upause"].clear()
            j["paused"] = False
            if j.get("note") == PAUSE_NOTE_U:
                j["note"] = ""
            j["updated"] = time.time()
        CV.notify_all()


def do_job_action(jid, what):
    with CV:
        j = JOBS.get(jid)
    if not j:
        raise ApiError("Unknown download", 404)
    if what == "resume":
        resume_job(j)
    elif what == "skip":
        skip_job(j)
    elif what == "cookies":              # the user said YES to using cookies.txt for this job
        with CV:
            if j["stage"] == "error":
                j["use_cookies"] = True
        resume_job(j)
    elif what == "nocookies":
        upd(j, cookie_need=False)
    elif what == "cancel":
        cancel_job(j)
    elif what == "pause":
        pause_job(j, True)
    elif what == "unpause":
        pause_job(j, False)
    elif what == "delete":
        delete_job_file(j)
    else:
        raise ApiError("Unknown action", 404)
    persist()


def do_bulk(what):
    with CV:
        jobs = sorted(JOBS.values(), key=lambda x: x["qseq"])
    if what == "pause_all":
        for j in jobs:
            pause_job(j, True)
    elif what == "unpause_all":
        for j in jobs:
            pause_job(j, False)
    elif what == "cancel_all":
        for j in jobs:
            if j["stage"] not in END:
                cancel_job(j)
    elif what == "resume_all":
        for j in jobs:
            resume_job(j)
    elif what == "clear":
        with CV:
            gone = [j for j in JOBS.values() if j["stage"] in CLEARABLE]
            for j in gone:
                JOBS.pop(j["id"], None)
        for j in gone:
            shutil.rmtree(job_work(j), ignore_errors=True)
    persist()


def start_downloads(body):
    items = body.get("items")
    if not isinstance(items, list) or not items:
        raise ApiError("Nothing to download")
    cache, jobs = {}, []
    use_ck = bool(body.get("use_cookies"))
    if use_ck and not current_cookies():
        raise ApiError("Use cookies.txt is on, but no cookies.txt file was found. Choose it in Settings or turn the button off.")
    for it in items[:2000]:
        if not isinstance(it, dict):
            raise ApiError("Bad request")
        d = it.get("dest") if isinstance(it.get("dest"), dict) else {}
        key = (str(d.get("base") or "").strip(), str(d.get("sub") or "").strip())
        if key not in cache:
            cache[key] = resolve_dest(*key)
        jobs.append(make_job(it, body.get("compat"), body.get("playlist"), cache[key], use_ck))
    with CV:
        for j in jobs:
            JOBS[j["id"]] = j
        CV.notify_all()
    persist()
    return {"ok": True, "count": len(jobs)}


# ----------------------------------------------------------------------------
# HTTP server
# ----------------------------------------------------------------------------
LOOPBACK = {"localhost", "127.0.0.1", "[::1]", "::1"}
BIND_HOST = "127.0.0.1"

SW_JS = """
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
async function tell(msg){
  const all=await self.clients.matchAll({type:'window',includeUncontrolled:true});
  all.forEach(c=>c.postMessage(msg));
  return all;
}
self.addEventListener('notificationclose',e=>{e.waitUntil(tell({type:'note-closed'}))});
self.addEventListener('notificationclick',e=>{
  e.waitUntil((async()=>{
    const all=await tell({type:'note-closed'});
    for(const c of all){ if('focus' in c){ return c.focus(); } }
    if(self.clients.openWindow){ return self.clients.openWindow('/'); }
  })());
});
"""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "TubeLocal"

    def log_message(self, *a):
        pass

    # -- plumbing
    def _send(self, code, body, ctype, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8")

    def _guard(self):
        hh = self.headers.get("Host") or ""
        host = (hh.split("]")[0] + "]") if hh.startswith("[") else hh.rsplit(":", 1)[0]
        if BIND_HOST in LOOPBACK and host not in LOOPBACK:
            self._json({"error": "Forbidden host"}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and up.urlsplit(origin).netloc != self.headers.get("Host"):
            self._json({"error": "Forbidden origin"}, 403)
            return False
        return True

    def _stream(self, host):
        """live job updates, pushed once a second (not slowed down when the tab is in the background)"""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.close_connection = True
        try:
            while True:
                data = json.dumps(jobs_payload(host)).encode("utf-8")
                self.wfile.write(b"data: " + data + b"\n\n")
                self.wfile.flush()
                time.sleep(1)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def _route(self, method):
        if not self._guard():
            return
        u = up.urlsplit(self.path)
        qs = dict(up.parse_qsl(u.query))
        country = qs.get("country", "").upper()
        if not re.fullmatch(r"[A-Z]{2}", country):
            country = ""
        path = u.path
        CTX.ck = qs.get("ck") == "1" and path in ("/api/search", "/api/playlist", "/api/formats")
        host = self.headers.get("Host") or f"127.0.0.1:{self.server.server_address[1]}"
        try:
            if method in ("GET", "HEAD"):
                if path in ("/", "/index.html"):
                    return self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
                if path == "/favicon.ico":
                    return self._send(204, b"", "image/x-icon")
                if path == "/sw.js":
                    return self._send(200, SW_JS.encode("utf-8"), "application/javascript; charset=utf-8",
                                      {"Service-Worker-Allowed": "/"})
                if path == "/api/ping":
                    return self._json({"ok": True, "keep": {"video": KEEP_VIDEO, "audio": KEEP_AUDIO},
                                       "free": free_bytes(), "dl_bps": avg_bps(),
                                       "out": str(OUTPUT_DIR), "ffmpeg": have_ffmpeg(),
                                       "ytdlp": ytdlp_version()})
                if path == "/api/stream":
                    return self._stream(host)
                if path == "/api/settings":
                    return self._json(api_settings_get())
                if path == "/api/browse":
                    return self._json(api_browse(qs))
                if path == "/api/ytdlp":
                    return self._json(ytdlp_status())
                if CTX.ck and not current_cookies():
                    raise ApiError("Use cookies.txt is on, but no cookies.txt file was found. Choose it in Settings or turn the button off.")
                if path == "/api/search":
                    return self._json(api_search(qs, country))
                if path == "/api/playlist":
                    return self._json(api_playlist(qs, country))
                if path == "/api/formats":
                    vid = qs.get("id") or ""
                    if not re.fullmatch(r"[\w-]{11}", vid):
                        raise ApiError("Bad video id")
                    return self._json(get_formats(vid, country))
                if path == "/api/speedlog":
                    return self._json(api_speedlog(qs))
                if path == "/api/jobs":
                    return self._json(jobs_payload(host))
                m = re.fullmatch(r"/files/([0-9a-f]{12})", path)
                if m:
                    return self._file(m.group(1))
            elif method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                if n > 30_000_000:
                    raise ApiError("Request too large", 413)
                raw = self.rfile.read(n) if n else b""

                def body():
                    try:
                        b = json.loads(raw.decode("utf-8") or "{}")
                    except ValueError:
                        raise ApiError("Bad request")
                    if not isinstance(b, dict):
                        raise ApiError("Bad request")
                    return b

                if path == "/api/download":
                    return self._json(start_downloads(body()))
                if path == "/api/settings":
                    return self._json(api_settings_set(body()))
                if path == "/api/mkdir":
                    return self._json(api_mkdir(body()))
                if path == "/api/ytdlp/reinstall":
                    return self._json(start_reinstall())
                if path in ("/api/jobs/cancel_all", "/api/jobs/resume_all", "/api/jobs/clear",
                            "/api/jobs/pause_all", "/api/jobs/unpause_all"):
                    do_bulk(path.rsplit("/", 1)[1])
                    return self._json({"ok": True})
                m = re.fullmatch(r"/api/jobs/([0-9a-f]{12})/(\w+)", path)
                if m:
                    do_job_action(m.group(1), m.group(2))
                    return self._json({"ok": True})
            self._json({"error": "Not found"}, 404)
        except ApiError as e:
            self._json({"error": str(e)}, e.code)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self._json({"error": clean_err(e)}, 500)
            except Exception:
                pass

    def do_GET(self):
        self._route("GET")

    def do_HEAD(self):
        self._route("HEAD")

    def do_POST(self):
        self._route("POST")

    # -- finished files (with Range support so videos can be played / resumed)
    def _file(self, jid):
        with CV:
            j = JOBS.get(jid)
        if not j or j["stage"] != "done" or not j.get("file") or not os.path.isfile(j["file"]):
            raise ApiError("File not found", 404)
        path = j["file"]
        size = os.path.getsize(path)
        start, end, code = 0, size - 1, 200
        rng = self.headers.get("Range")
        if rng:
            m = re.fullmatch(r"bytes=(\d*)-(\d*)", rng.strip())
            if m and (m.group(1) or m.group(2)):
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                else:
                    start = max(0, size - int(m.group(2)))
                end = min(end, size - 1)
                if start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                code = 206
        ctype = mimetypes.guess_type(path)[0] or {
            ".mkv": "video/x-matroska", ".m4a": "audio/mp4", ".opus": "audio/ogg"}.get(
            Path(path).suffix.lower(), "application/octet-stream")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Disposition",
                         "inline; filename*=UTF-8''" + up.quote(Path(path).name))
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    b = f.read(min(1 << 18, left))
                    if not b:
                        break
                    self.wfile.write(b)
                    left -= len(b)
        except (BrokenPipeError, ConnectionResetError):
            pass


def open_browser(url):
    try:
        if shutil.which("termux-open-url"):
            subprocess.Popen(["termux-open-url", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            webbrowser.open(url)
    except Exception:
        pass


def main():
    global BIND_HOST
    ap = argparse.ArgumentParser(description="Tube to Drive - local edition")
    ap.add_argument("--out", default=None)
    ap.add_argument("--cookies", default=None)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--keep-video-hours", type=float, default=None)
    ap.add_argument("--keep-audio-hours", type=float, default=None)
    args = ap.parse_args()

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    load_settings()
    if args.out:
        SET["out"] = args.out
    if args.cookies:
        SET["cookies"] = args.cookies
    if args.keep_video_hours is not None:
        SET["keep_video"] = max(0.0, args.keep_video_hours)
    if args.keep_audio_hours is not None:
        SET["keep_audio"] = max(0.0, args.keep_audio_hours)
    apply_settings()
    try:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"WARNING: cannot use the save folder {OUTPUT_DIR} ({e}). Using the default folder instead.")
        SET["out"] = ""
        apply_settings()
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ensure_work()
    BIND_HOST = args.host

    load_jobs()
    persist()          # creates / updates data.json right away
    threading.Thread(target=dispatcher, daemon=True).start()
    threading.Thread(target=smart_loop, daemon=True).start()
    threading.Thread(target=sampler, daemon=True).start()
    threading.Thread(target=sweeper, daemon=True).start()
    threading.Thread(target=auto_update_loop, daemon=True).start()

    srv = None
    for port in range(args.port, args.port + 25):
        try:
            srv = ThreadingHTTPServer((args.host, port), Handler)
            break
        except OSError:
            continue
    if not srv:
        print("Could not open a local port. Use --port to choose another one.")
        sys.exit(1)
    srv.daemon_threads = True
    url = f"http://{'127.0.0.1' if args.host in ('0.0.0.0', '') else args.host}:{port}/"

    print("-" * 58)
    print("               TUBE TO DRIVE  (local edition)")
    print("-" * 58)
    print(f"Open this page : {url}")
    print(f"Files saved in : {OUTPUT_DIR}")
    ck = current_cookies()
    print(f"Cookies        : {ck if ck else 'none found'}  (only used if a download asks for it and you allow it)")
    if yt_dlp:
        print(f"yt-dlp         : {ytdlp_version()}")
    else:
        print("yt-dlp         : NOT INSTALLED (the app installs it automatically)")
    if not have_ffmpeg():
        print("WARNING: ffmpeg not found. Merging and MP3 conversion need it (Termux: pkg install ffmpeg).")
    if not (shutil.which("deno") or shutil.which("node")):
        print("Tip: if some YouTube formats are missing, install deno or nodejs (Termux: pkg install nodejs).")
    if args.host not in LOOPBACK:
        print("NOTE: the page is open to your network. Anyone who can reach it can browse folders and change settings.")
    print("Press Ctrl+C to stop.\n")
    if not args.no_browser:
        threading.Timer(0.8, open_browser, args=(url,)).start()
    try:
        for sg in ("SIGTERM", "SIGHUP"):
            if hasattr(signal, sg):
                try:
                    signal.signal(getattr(signal, sg), lambda *a: (_ for _ in ()).throw(KeyboardInterrupt()))
                except Exception:
                    pass
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped. Unfinished downloads can be continued next time.")
    finally:
        persist()
        srv.server_close()


# ----------------------------------------------------------------------------
# the page
# ----------------------------------------------------------------------------
PAGE = r'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tube to Drive</title>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700;800&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{--bg:#e9eef5;--card:#fff;--ink:#16233b;--mut:#5d6b82;--line:#d3dbe7;--acc:#2f4bff;--ok:#15935a;--bad:#d6334a;--warn:#b7791f}
*{box-sizing:border-box}
[hidden]{display:none!important}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 'IBM Plex Sans',system-ui,sans-serif;padding-bottom:70px}
h1,h2,h3{font-family:'Bricolage Grotesque',sans-serif;margin:0}
.wrap{max-width:1040px;margin:0 auto;padding:16px}
header{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:12px}
h1{font-size:34px;font-weight:800;letter-spacing:-1px}
.hr{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.pill{display:inline-flex;gap:8px;align-items:center;padding:6px 12px;border-radius:99px;background:var(--card);border:1px solid var(--line);font-weight:500}
.pill.spd{color:var(--acc);font-weight:600}
.dot{width:10px;height:10px;border-radius:50%;background:var(--bad)}.on .dot{background:var(--ok)}
.ibtn{width:38px;height:38px;padding:0;display:inline-flex;align-items:center;justify-content:center;background:#fff;color:var(--ink);border:1px solid var(--line);border-radius:50%}
.ibtn svg{width:19px;height:19px}.ibtn.on{background:var(--acc);color:#fff;border-color:var(--acc)}
.banner{display:none;background:var(--bad);color:#fff;padding:12px 14px;border-radius:10px;margin-bottom:12px}
.offline .banner{display:block}
.offline .need{opacity:.45;pointer-events:none}
.row{display:flex;gap:8px;flex-wrap:wrap}
input[type=text],input[type=number],select{font:inherit;padding:11px 12px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--ink)}
input[type=text]{flex:1;min-width:160px}
input[type=number]{width:100%}
button{font:inherit;font-weight:600;border:0;border-radius:10px;padding:10px 14px;background:var(--acc);color:#fff;cursor:pointer}
button.alt{background:#fff;color:var(--ink);border:1px solid var(--line)}
button.sm{padding:5px 10px;font-size:13px}
button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #9fb0ff;outline-offset:1px}
button:disabled{opacity:.5}
section{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;margin-top:14px}
section>h2{font-size:20px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:8px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px}
.vid img{width:100%;border-radius:10px;aspect-ratio:16/9;object-fit:cover;background:#cfd8e6}
.vid h3{font-size:15px;margin:8px 0 2px;line-height:1.25;font-weight:700}
.mut{color:var(--mut);font-size:13px}
.vid .row{margin-top:8px}.vid button{flex:1;padding:8px}
.overlay{position:fixed;inset:0;background:rgba(15,25,45,.6);display:none;align-items:flex-start;justify-content:center;overflow:auto;padding:16px;z-index:9}
.overlay.show{display:flex}
#ov2{z-index:12}
.modal{background:#fff;border-radius:14px;padding:14px;width:100%;max-width:760px}
.modal iframe{width:100%;aspect-ratio:16/9;border:0;border-radius:10px}
.modal.wide{max-width:900px}
table{width:100%;border-collapse:collapse;font-size:14px}
td,th{padding:7px 6px;border-bottom:1px solid var(--line);text-align:left}
.tag{padding:1px 7px;border-radius:6px;font-size:12px;font-weight:600}
.tv{background:#e3e8ff;color:#2437b8}.ta{background:#d9f3e6;color:#0e6b42}.tm{background:#fdeccb;color:#8a5a0b}
.job{display:grid;grid-template-columns:96px 1fr;gap:10px;padding:10px 0;border-bottom:1px solid var(--line)}
.job img{width:96px;border-radius:8px;aspect-ratio:16/9;object-fit:cover}
.bar{height:9px;background:#e3e9f3;border-radius:9px;overflow:hidden}
.bar i{display:block;height:100%;background:var(--acc);width:0;transition:width .4s}
.bar.s{height:6px;margin-top:3px}
.bar.m i{background:var(--warn)}.bar.u i{background:var(--ok)}.bar.d i{background:var(--ok)}
.st{margin-top:7px;font-size:13px}
.sl{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap}
.sl .sr{color:var(--mut)}
.err{color:var(--bad);font-weight:500}
.lnk{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
.lnk a,.lnk button{padding:6px 10px;font-size:13px;border-radius:8px;text-decoration:none;background:var(--ok);color:#fff;border:0}
.lnk button{background:#fff;color:var(--ink);border:1px solid var(--line)}
.lk{display:flex;gap:6px;align-items:center;margin-top:6px}.lk a{background:var(--ok);color:#fff;text-decoration:none;padding:6px 10px;border-radius:8px;font-size:13px;font-weight:600}.lk button{padding:6px 10px;font-size:13px;background:#fff;color:var(--ink);border:1px solid var(--line)}
.ok{color:var(--ok);font-weight:500}.run{color:var(--acc);font-weight:600}
.ask{background:#fff6e0;border:1px solid #ecd28a;border-radius:10px;padding:10px;margin:8px 0}
.empty{color:var(--mut);padding:6px 0}
.ql{margin:2px 0}
#qsum{background:#eef2ff;border:1px solid #c9d2ff;border-radius:10px;padding:10px;margin-bottom:8px}
@media(prefers-reduced-motion:reduce){.bar i{transition:none}}

/* search bar */
.sbar{display:flex;gap:8px}
.sb{position:relative;flex:1;min-width:0}
.sb input[type=text]{width:100%;min-width:0;padding-right:48px}
.attach{position:absolute;right:5px;top:50%;transform:translateY(-50%);width:34px;height:34px;padding:0;display:inline-flex;align-items:center;justify-content:center;background:#eef2ff;color:var(--acc);border:1px solid #c9d2ff;border-radius:9px}
.attach:hover{background:var(--acc);color:#fff}
.attach svg{width:17px;height:17px}
.tools{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px}
.tg,button.tg{display:inline-flex;gap:7px;align-items:center;padding:7px 12px;border:1px solid var(--line);border-radius:99px;background:#fff;color:var(--ink);font-weight:600;font-size:14px;cursor:pointer;user-select:none}
.tg.on,button.tg.on{border-color:var(--acc);background:#eef2ff;color:#2437b8}
.tg input{width:16px;height:16px;margin:0;accent-color:var(--acc)}
.tg svg{width:16px;height:16px}
.cnt{background:var(--acc);color:#fff;border-radius:99px;font-size:12px;padding:0 7px;line-height:18px}
.fpanel{margin-top:10px;padding:12px;border:1px solid var(--line);border-radius:12px;background:#f6f8fc;display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;align-items:end}
.fpanel label{display:flex;flex-direction:column;gap:4px;font-size:13px;color:var(--mut);font-weight:500}
.fpanel select{width:100%}
.drop{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(47,75,255,.12);border:4px dashed var(--acc);font:800 22px 'Bricolage Grotesque',sans-serif;color:var(--acc);z-index:20;pointer-events:none}
.drop.show{display:flex}

/* cards + selection */
.vid{position:relative}.vid.sel .th img{outline:3px solid var(--acc)}.th{position:relative}
.pick{position:absolute;top:8px;left:8px;width:22px;height:22px}
.badge{position:absolute;right:6px;bottom:6px;background:rgba(0,0,0,.75);color:#fff;border-radius:6px;padding:1px 6px;font-size:12px}
.badge.dup{left:6px;right:auto;background:var(--ok);max-width:75%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.selbar{position:fixed;left:0;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);padding:10px 16px;display:none;gap:8px;align-items:center;flex-wrap:wrap;z-index:8}
.selbar.show{display:flex}.selbar b{margin-right:auto}
.seg button{background:#fff;color:var(--ink);border:1px solid var(--line)}.seg button.on{background:var(--acc);color:#fff;border-color:var(--acc)}

/* quality window */
.strip{display:flex;gap:8px;overflow-x:auto;padding:8px 0}
.chip{position:relative;flex:0 0 130px;border:2px solid var(--line);border-radius:10px;padding:4px;font-size:12px}.chip.pick1{cursor:pointer}.chip.on{border-color:var(--acc)}
.chip img{width:100%;border-radius:6px;aspect-ratio:16/9;object-fit:cover}.chip div{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.chip .x{position:absolute;top:2px;right:2px;width:22px;height:22px;padding:0;border-radius:50%;background:var(--bad);color:#fff;line-height:1;z-index:1}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:10px}@media(max-width:640px){.cols{grid-template-columns:1fr}}
.qlist{max-height:34vh;overflow:auto;border:1px solid var(--line);border-radius:10px}
.opt{display:flex;gap:8px;align-items:center;padding:7px 8px;border-bottom:1px solid var(--line);cursor:pointer}.opt .c{margin-left:auto;color:var(--mut);font-size:12px;white-space:nowrap}
.opt button{padding:2px 8px;font-size:12px}.sub{padding:4px 8px 8px 30px;font-size:12px;color:var(--mut)}
.sum{background:#eef2ff;border:1px solid #c9d2ff;border-radius:10px;padding:10px;margin-top:10px}
.g{color:var(--ok);font-weight:600}.r{color:var(--bad);font-weight:600}
.cat{display:inline-flex;gap:6px;align-items:center;padding:8px 12px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--ink);font-weight:600;cursor:pointer}.cat.on{background:var(--acc);color:#fff;border-color:var(--acc)}
.blk{margin-top:12px;padding-top:10px;border-top:1px solid var(--line)}.sh{font-size:17px;margin:0 0 6px}
.dst{word-break:break-all;margin-bottom:6px}
.fname{width:100%;margin-top:6px}

/* folder picker + settings */
.fpath{font-size:13px;word-break:break-all;background:#f1f4fa;border-radius:8px;padding:6px 8px;margin-top:6px}
.roots{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}
.roots button{padding:4px 10px;font-size:13px}
.fplist{max-height:48vh;overflow:auto;border:1px solid var(--line);border-radius:10px}
.fi{display:flex;gap:8px;padding:10px;border-bottom:1px solid var(--line);cursor:pointer;align-items:center;word-break:break-all}.fi:hover{background:#f1f5ff}
.set label.lb{display:block;font-weight:600;margin:14px 0 4px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.two label{font-size:13px;color:var(--mut)}
.log{background:#0f1830;color:#cfe0ff;font:12px/1.4 ui-monospace,Menlo,Consolas,monospace;padding:8px;border-radius:8px;max-height:160px;overflow:auto;white-space:pre-wrap;margin:8px 0 0}
</style>
</head>
<body>
<div class="wrap offline" id="app">
  <header>
    <h1>Tube to Drive</h1>
    <div class="hr">
      <div class="pill spd" id="gspd" hidden title="Current download speed - click for the speed graph" role="button" tabindex="0" style="cursor:pointer">&#8595; <b id="gspdv">0 KB/s</b></div>
      <div class="pill spd" id="gsw" hidden title="Automatic switching between slow and fast downloads"></div>
      <button class="ibtn" id="bell" type="button" title="Notifications" aria-label="Notifications"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></button>
      <button class="ibtn" id="gear" type="button" title="Settings" aria-label="Settings"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
      <div class="pill" id="status"><span class="dot"></span><span id="stxt">Program not connected</span></div>
    </div>
  </header>

  <div class="banner" id="banner"><b>Program is not running.</b> <span id="why">Start yt_batch.py again, then reload this page.</span></div>

  <section class="need" id="dl">
    <h2>Downloads
      <button class="alt sm" id="toggleFull" type="button" aria-expanded="false" aria-controls="downloadContent">Show full</button>
    </h2>
    <div id="qsum"><span class="mut">Nothing downloading.</span></div>
    <div class="row" id="pallbar" style="margin-bottom:8px" hidden>
      <button class="alt" id="pall" type="button">&#10074;&#10074; Pause all</button>
      <button class="alt" id="rall" type="button">&#9654; Resume all</button>
    </div>
    <div class="ask" id="stopbar" hidden>
      <b id="stopn"></b> <span class="mut">unfinished or stopped. Continue them all at once instead of one by one.</span>
      <div class="row" style="margin-top:6px"><button id="cnt" type="button">Continue all</button></div>
    </div>
    <div id="downloadContent" hidden>
      <div class="row" style="margin-bottom:6px">
        <button class="alt" id="cxa" type="button">Cancel all</button>
        <button class="alt" id="clr" type="button">Clear finished</button>
      </div>
      <div id="jobs"><div class="empty">Nothing downloading.</div></div>
      <div class="mut" id="keepnote" style="margin-top:8px"></div>
    </div>
  </section>

  <section class="need">
    <h2>Find videos</h2>
    <div class="sbar">
      <div class="sb">
        <input type="text" id="q" placeholder="Search YouTube or paste a video / playlist link" autocomplete="off">
        <button class="attach" id="attach" type="button" title="Upload a file that contains YouTube links" aria-label="Upload a file that contains YouTube links"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg></button>
      </div>
      <button id="go" type="button">Search</button>
    </div>
    <input type="file" id="fileIn" multiple hidden>
    <div class="tools">
      <label class="tg" id="multiLbl"><input type="checkbox" id="multi"> Multi select</label>
      <button class="tg" id="fbtn" type="button" aria-expanded="false" aria-controls="fpanel"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg> Filters <span class="cnt" id="fcnt" hidden></span></button>
    </div>
    <div class="fpanel" id="fpanel" hidden>
      <label>Type<select id="ftype"><option value="all">Videos and playlists</option><option value="video">Videos only</option><option value="playlist">Playlists only</option></select></label>
      <label>Upload date<select id="fdate"><option value="">Any upload date</option><option value="hour">Last hour</option><option value="today">Today</option><option value="week">This week</option><option value="month">This month</option><option value="year">This year</option></select></label>
      <label>Length<select id="fdur"><option value="">Any length</option><option value="short">Under 4 minutes</option><option value="medium">4 to 20 minutes</option><option value="long">Over 20 minutes</option></select></label>
      <label>Country (like a VPN)<select id="fcountry"><option value="">Automatic</option><option value="US">United States</option><option value="GB">United Kingdom</option><option value="CA">Canada</option><option value="AU">Australia</option><option value="DE">Germany</option><option value="FR">France</option><option value="NL">Netherlands</option><option value="SE">Sweden</option><option value="NO">Norway</option><option value="FI">Finland</option><option value="DK">Denmark</option><option value="CH">Switzerland</option><option value="AT">Austria</option><option value="BE">Belgium</option><option value="IE">Ireland</option><option value="ES">Spain</option><option value="PT">Portugal</option><option value="IT">Italy</option><option value="PL">Poland</option><option value="CZ">Czechia</option><option value="RO">Romania</option><option value="UA">Ukraine</option><option value="TR">Turkey</option><option value="IL">Israel</option><option value="AE">United Arab Emirates</option><option value="SA">Saudi Arabia</option><option value="IN">India</option><option value="PK">Pakistan</option><option value="BD">Bangladesh</option><option value="LK">Sri Lanka</option><option value="SG">Singapore</option><option value="MY">Malaysia</option><option value="ID">Indonesia</option><option value="TH">Thailand</option><option value="VN">Vietnam</option><option value="PH">Philippines</option><option value="JP">Japan</option><option value="KR">South Korea</option><option value="HK">Hong Kong</option><option value="TW">Taiwan</option><option value="NZ">New Zealand</option><option value="ZA">South Africa</option><option value="NG">Nigeria</option><option value="KE">Kenya</option><option value="EG">Egypt</option><option value="BR">Brazil</option><option value="AR">Argentina</option><option value="CL">Chile</option><option value="CO">Colombia</option><option value="MX">Mexico</option></select></label>
      <button class="alt" id="freset" type="button">Reset filters</button>
    </div>
    <div id="crumb" style="margin-top:8px"></div>
    <div id="msg" class="mut" style="margin-top:8px"></div>
    <div class="grid" id="results" style="margin-top:10px"></div>
    <div class="mut" id="more" style="text-align:center;margin-top:12px" hidden>Loading more&hellip;</div><div id="sentinel" style="height:1px"></div>
  </section>
</div>

<div class="selbar" id="selbar"><b id="sn"></b><button class="alt" id="selall">Select all shown</button><button class="alt" id="selclr">Clear</button><button id="selgo">Choose quality</button></div>
<div class="drop" id="drop">Drop a file that contains YouTube links</div>
<div class="overlay" id="ov"><div class="modal" id="modal"></div></div>
<div class="overlay" id="ov2"><div class="modal" id="modal2"></div></div>

<script>
const $=s=>document.querySelector(s);
const LS={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
const API=location.origin;
let online=false,busy=false,KEEPV=0,KEEPA=0,OUT='',FREE=null,BPS=8e6,skew=0;
let COUNTRY=LS.get('country')||'';$('#fcountry').value=COUNTRY;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mb=b=>b?(b>1e9?(b/1e9).toFixed(2)+' GB':(b/1e6).toFixed(1)+' MB'):'size unknown';
const dur=s=>{if(!s)return'';s=Math.round(s);const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(s%60).padStart(2,'0')};
const sp=b=>!b||b<1?'':b>=1e6?(b/1e6).toFixed(1)+' MB/s':Math.round(b/1e3)+' KB/s';
const trimT=(t,n)=>String(t).length>n?String(t).slice(0,n-1)+'\u2026':String(t);
const CK={on:LS.get('ck_on')==='1',s:LS.get('ck_s')!=='0',f:LS.get('ck_f')!=='0',d:LS.get('ck_d')!=='0'};
function ckUi(){const b=$('#s_ckon');if(!b)return;b.classList.toggle('on',CK.on);b.setAttribute('aria-pressed',String(CK.on));$('#s_ckst').textContent=CK.on?'On':'Off';
  $('#s_ckp').hidden=!CK.on;$('#s_cks').checked=CK.s;$('#s_ckf').checked=CK.f;$('#s_ckd').checked=CK.d}
function ckWire(){$('#s_ckon').onclick=()=>{CK.on=!CK.on;LS.set('ck_on',CK.on?'1':'0');ckUi()};
  [['s_cks','s'],['s_ckf','f'],['s_ckd','d']].forEach(([id,k])=>$('#'+id).onchange=e=>{CK[k]=e.target.checked;LS.set('ck_'+k,CK[k]?'1':'0')});ckUi()}
function ckFor(path){if(!CK.on)return false;
  if(/^\/api\/(search|playlist)/.test(path))return CK.s;
  if(/^\/api\/formats/.test(path))return CK.f;
  return false}
async function api(path,opt){
  if(ckFor(path)&&!/[?&]ck=/.test(path))path+=(path.includes('?')?'&':'?')+'ck=1';
  if(COUNTRY&&!/[?&]country=/.test(path))path+=(path.includes('?')?'&':'?')+'country='+COUNTRY;
  const r=await fetch(API+path,opt);
  const j=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(j.error||('Error '+r.status));
  return j;
}
const post=(p,o)=>api(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o||{})});

function setOnline(v,why){
  online=v;$('#app').classList.toggle('offline',!v);$('#status').classList.toggle('on',v);
  if(!v){$('#stxt').textContent='Program not connected';$('#gspd').hidden=true;$('#gsw').hidden=true;
    $('#why').textContent=why||'Start yt_batch.py again, then reload this page.'}
}
async function tryUrl(){try{const r=await fetch(API+'/api/ping');const j=await r.json();return j.ok?j:null}catch(e){return null}}
function gotOnline(p){
  const was=online;KEEPV=p.keep.video;KEEPA=p.keep.audio;OUT=p.out||'';FREE=p.free;BPS=p.dl_bps||8e6;
  $('#keepnote').textContent=(OUT?'Files are saved in '+OUT+' unless you choose a custom folder. ':'')+(KEEPV||KEEPA?'Merged videos are deleted '+KEEPV+' hours after they finish, audio-only files after '+KEEPA+' hours.':'Nothing is deleted automatically.');
  setOnline(true);
  $('#stxt').textContent=!p.ytdlp?'Running (yt-dlp missing)':!p.ffmpeg?'Running (ffmpeg not found)':'Running';
  if(!was){loadJobs();startStream()}
}
async function ping(){
  if(busy)return;busy=true;
  try{const p=await tryUrl();if(p)gotOnline(p);else setOnline(false)}finally{busy=false}
}

/* collapsible downloads */
function setDl(open){$('#downloadContent').hidden=!open;$('#toggleFull').textContent=open?'Show less':'Show full';$('#toggleFull').setAttribute('aria-expanded',String(open));LS.set('dlopen',open?'1':'0')}
$('#toggleFull').onclick=()=>setDl($('#downloadContent').hidden);
setDl(LS.get('dlopen')==='1');

/* state */
const SEL=new Map(),ITEMS=new Map(),famOrd={h264:0,vp9:1,av1:2},extOrd={m4a:0,webm:1,mp3:2};
let R=null,back=null,multi=false,Q=null;
const LIVE=['downloading','merging','uploading','cancelling'],END=['done','error','cancelled','expired','deleted'];
const clk=t=>new Date(t*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
const hm=s=>{s=Math.max(0,Math.round(s));const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return h?h+' h '+m+' min':m?m+' min '+s%60+' s':s+' s'};
const now=()=>Date.now()/1000+skew;

/* filters */
function updFilters(){let n=0;if($('#ftype').value!=='all')n++;if($('#fdate').value)n++;if($('#fdur').value)n++;if($('#fcountry').value)n++;
  $('#fcnt').hidden=!n;$('#fcnt').textContent=n;$('#fbtn').classList.toggle('on',n>0)}
$('#fbtn').onclick=()=>{const p=$('#fpanel');p.hidden=!p.hidden;$('#fbtn').setAttribute('aria-expanded',String(!p.hidden))};
$('#freset').onclick=()=>{$('#ftype').value='all';$('#fdate').value='';$('#fdur').value='';$('#fcountry').value='';COUNTRY='';LS.set('country','');
  $('#fdate').disabled=$('#fdur').disabled=false;updFilters();if($('#q').value.trim())search()};

/* search, load more, playlists */
function pageUrl(){return R.mode==='pl'?`/api/playlist?id=${R.id}&offset=${R.next}&n=12`:'/api/search?'+new URLSearchParams({q:R.q,type:R.p.type,date:R.p.date,dur:R.p.dur,offset:R.next,n:12})}
async function load(){
  const r=R;if(r.busy)return;r.busy=1;$('#more').hidden=!r.items.length;$('#msg').textContent=r.items.length?'':'Loading\u2026';
  try{const d=await api(pageUrl());if(R!==r)return;
    d.results.filter(v=>!r.items.some(x=>x.id===v.id)).forEach(v=>{ITEMS.set(v.id,v);r.items.push(v)});
    r.next=d.next;r.more=d.more&&d.results.length>0;r.loaded=1;r.busy=0;paint();
  }catch(e){r.err=1;if(R===r){$('#more').hidden=true;$('#msg').innerHTML='<span class="err">'+esc(e.message)+'</span>'}}
  finally{r.busy=0}
}
function search(){const q=$('#q').value.trim();if(!q)return;const pl=$('#ftype').value==='playlist';
  R={mode:'s',q,p:{type:$('#ftype').value,date:pl?'':$('#fdate').value,dur:pl?'':$('#fdur').value},items:[],next:0};$('#crumb').innerHTML='';$('#results').innerHTML='';load()}
$('#go').onclick=search;$('#q').onkeydown=e=>{if(e.key==='Enter')search()};
const SENT=$('#sentinel'),io=new IntersectionObserver(es=>{if(es.some(e=>e.isIntersecting)&&R&&R.more&&R.loaded&&!R.busy&&!R.err)load()},{rootMargin:'700px'});io.observe(SENT);
const watch=()=>setTimeout(()=>{io.unobserve(SENT);io.observe(SENT)},60);
$('#fcountry').onchange=()=>{COUNTRY=$('#fcountry').value;LS.set('country',COUNTRY);updFilters();if($('#q').value.trim())search()};
['ftype','fdate','fdur'].forEach(i=>$('#'+i).onchange=()=>{$('#fdate').disabled=$('#fdur').disabled=$('#ftype').value==='playlist';updFilters();if($('#q').value.trim())search()});
updFilters();
function card(v){
  if(v.type==='playlist')return `<div class="vid" data-id="${v.id}"><div class="th"><img src="${esc(v.thumb||'')}" alt=""><span class="badge">Playlist${v.count?' \u00b7 '+v.count+' videos':''}</span></div><h3>${esc(v.title)}</h3><div class="mut">${esc(v.channel||'')}</div><div class="row"><button class="alt" data-open="1">Open</button><button data-all="1">Download all</button></div></div>`;
  const on=SEL.has(v.id),sx=SEL.get(v.id),dup=multi&&sx&&sx.from!==fromOf();
  return `<div class="vid${on?' sel':''}" data-id="${v.id}"><div class="th"><img src="${esc(v.thumb)}" alt="">${multi?`<input type="checkbox" class="pick" ${on?'checked':''}>`:''}${dup?`<span class="badge dup">Already selected: ${esc(sx.from)}</span>`:''}${v.duration?`<span class="badge">${dur(v.duration)}</span>`:''}</div><h3>${esc(v.title)}</h3><div class="mut">${esc(v.channel||'')}</div><div class="row"><button class="alt" data-p="1">Play</button>${multi?'':'<button data-d="1">Download</button>'}</div></div>`}
const fromOf=()=>R.mode==='pl'?R.title:R.q;
function paint(){$('#results').innerHTML=R?R.items.map(card).join(''):'';$('#more').hidden=true;watch();updSel();
  if(R&&R.loaded){const n=multi?R.items.filter(v=>{const x=SEL.get(v.id);return x&&x.from!==fromOf()}).length:0;
    $('#msg').innerHTML=!R.items.length?'No results.':n?`<span class="g">${n} video${n>1?'s here are':' here is'} already in your selection from another search.</span>`:''}}
$('#results').onclick=e=>{const t=e.target,c=t.closest('.vid');if(!c)return;const id=c.dataset.id,v=ITEMS.get(id);
  if(t.dataset.p)return modal(`<iframe src="https://www.youtube.com/embed/${id}?autoplay=1" allow="autoplay;encrypted-media;fullscreen" allowfullscreen></iframe>${closeBtn()}`);
  if(t.dataset.d)return openQuality([v],{});
  if(t.dataset.open)return openPl(v);
  if(t.dataset.all)return plAll(v,t);
  if(multi&&v.type==='video'&&!t.closest('button')){SEL.has(id)?SEL.delete(id):SEL.set(id,{...v,from:fromOf()});c.classList.toggle('sel',SEL.has(id));const dd=c.querySelector('.dup');if(dd&&!SEL.has(id))dd.remove();const p=c.querySelector('.pick');if(p)p.checked=SEL.has(id);updSel()}};
function openPl(v){back=R;R={mode:'pl',id:v.id,title:v.title,items:[],next:0};$('#crumb').innerHTML=`<button class="alt" id="bk">\u2190 Back to results</button> <b>${esc(v.title)}</b>`;
  $('#bk').onclick=()=>{R=back;$('#crumb').innerHTML='';paint()};paint();load()}
async function plAll(v,b){b.disabled=true;b.textContent='Reading\u2026';
  try{const d=await api(`/api/playlist?id=${v.id}&all=1`);d.results.forEach(x=>ITEMS.set(x.id,x));openQuality(d.results,{playlist:v.title||d.title})}catch(e){alert(e.message)}
  b.disabled=false;b.textContent='Download all'}
$('#multi').onchange=e=>{multi=e.target.checked;$('#multiLbl').classList.toggle('on',multi);if(R)paint()};
function updSel(){$('#selbar').classList.toggle('show',multi&&SEL.size>0);$('#sn').textContent=SEL.size+' selected'}
$('#selall').onclick=()=>{R&&R.items.filter(v=>v.type==='video').forEach(v=>{if(!SEL.has(v.id))SEL.set(v.id,{...v,from:fromOf()})});paint()};
$('#selclr').onclick=()=>{SEL.clear();if(R)paint();else updSel()};
$('#selgo').onclick=()=>openQuality([...SEL.values()],{fromSel:1});

/* quality selection */
function pickV(L,w){if(!w||!L.length)return null;let f=L.find(x=>x.label===w.label);if(f)return{f,fb:0};
  const s=L.filter(x=>x.fam===w.fam),p=s.length?s:L;
  f=p.filter(x=>x.h<=w.h).sort((a,b)=>b.h-a.h||b.fps-a.fps)[0]||p.slice().sort((a,b)=>a.h-b.h)[0];return{f,fb:1}}
function pickA(L,w){if(!w||!L.length)return null;let f=L.find(x=>x.label===w.label);if(f)return{f,fb:0};
  let p=L.filter(x=>x.ext===w.ext);if(!p.length)p=L.filter(x=>x.ext==='mp3');if(!p.length)p=L;
  f=p.filter(x=>x.abr<=w.abr).sort((a,b)=>b.abr-a.abr)[0]||p.slice().sort((a,b)=>a.abr-b.abr)[0];return{f,fb:1}}
function agg(k){const m=new Map();Q.ok.forEach(it=>Q.info.get(it.id)[k].forEach(f=>{if(!m.has(f.label))m.set(f.label,{f,ids:[]});m.get(f.label).ids.push(it.id)}));
  return[...m.values()].sort(k==='videos'?(x,y)=>y.f.h-x.f.h||y.f.fps-x.f.fps||famOrd[x.f.fam]-famOrd[y.f.fam]:(x,y)=>extOrd[x.f.ext]-extOrd[y.f.ext]||y.f.abr-x.f.abr)}
const ctxOf=id=>Q.mode==='same'?Q.same:Q.each.get(id);
const MP3='MP3 192k',QA='AAC 128k',ms=b=>b?'~'+mb(b):'size unknown';
/* one choice = which types are ticked + the qualities ticked in each list + where the files go:
   cat  {vm,vo,ao} = Video+audio / Video only / Audio only ticked
   qp   video qualities ticked in "H.264 + AAC 128k" quick picks
   ox   video qualities ticked in "Other combinations" (paired with audio oa)
   vo   video-only qualities ticked   ao  audio-only qualities ticked
   dest {base:'' = default folder, useSub: put files in a new folder, name: that folder's name} */
const mkCtx=()=>({cat:{vm:1,vo:0,ao:0},qp:new Set(),ox:new Set(),oa:null,vo:new Set(),ao:new Set(),
  dest:{base:'',useSub:!!(Q&&Q.meta&&Q.meta.playlist),name:(Q&&Q.meta&&Q.meta.playlist)||'New folder'}});
const cloneCtx=c=>({cat:{...c.cat},qp:new Set(c.qp),ox:new Set(c.ox),oa:c.oa,vo:new Set(c.vo),ao:new Set(c.ao),dest:{...c.dest}});
const destTxt=c=>{const b=c.dest.base||OUT,sep=b.includes('\\')&&!b.includes('/')?'\\':'/';return c.dest.useSub?b.replace(/[\\/]+$/,'')+sep+(c.dest.name.trim()||'New folder'):b};
const fmtBy=(k,l)=>{for(const it of Q.ok){const f=Q.info.get(it.id)[k==='v'?'videos':'audios'].find(x=>x.label===l);if(f)return f}};
const szV=(id,w)=>{const v=pickV(Q.info.get(id).videos,w);return v?v.f.size||0:0};
const szA=(id,w)=>{const a=pickA(Q.info.get(id).audios,w);return a?a.f.size||0:0};
/* every file that will be downloaded for one video (duplicates collapse into one) */
function resAll(id){const L=Q.info.get(id),c=ctxOf(id),out=[],seen=new Set();let miss=0;
  const add=r=>{if(!r){miss++;return}const k=r.kind+'|'+(r.v?r.v.id:'')+'|'+(r.a?r.a.id:'');if(seen.has(k)){if(r.fb)out.dup=(out.dup||0)+1;return}seen.add(k);out.push(r)};
  const V=l=>pickV(L.videos,fmtBy('v',l)),A=l=>pickA(L.audios,fmtBy('a',l)),nt=(w,x)=>x&&x.fb?'wanted '+w+', using '+x.f.label:'';
  const mk=(vl,al)=>{const v=V(vl),a=A(al);return v&&a&&{kind:'video',v:v.f,a:a.f,fb:v.fb||a.fb,txt:[nt(vl,v),nt(al,a)].filter(Boolean).join('; ')}};
  if(c.cat.vm){c.qp.forEach(l=>add(mk(l,QA)));if(c.oa)c.ox.forEach(l=>add(mk(l,c.oa.label)))}
  if(c.cat.vo)c.vo.forEach(l=>{const v=V(l);add(v&&{kind:'vonly',v:v.f,a:null,fb:v.fb,txt:nt(l,v)})});
  if(c.cat.ao)c.ao.forEach(l=>{const a=A(l);add(a&&{kind:'audio',v:null,a:a.f,fb:a.fb,txt:nt(l,a)})});
  out.miss=miss;out.dup=out.dup||0;return out}
function defVM(c){const V=agg('videos'),H=V.filter(e=>e.f.fam==='h264'),all=e=>e.ids.length===Q.ok.length,bH=H.find(all)||H[0],b=V.find(all)||V[0];
  if(bH&&fmtBy('a',QA))c.qp.add(bH.f.label);else if(b)c.ox.add(b.f.label)}
function defaults(c,k){const V=agg('videos'),A=agg('audios');
  if(k==='vm'&&!c.qp.size&&!c.ox.size)defVM(c);
  if(k==='vo'&&!c.vo.size){const e=V.find(x=>x.ids.length===Q.ok.length)||V[0];if(e)c.vo.add(e.f.label)}
  if(k==='ao'&&!c.ao.size){const e=A.find(x=>x.f.label===MP3)||A[0];if(e)c.ao.add(e.f.label)}}
async function openQuality(items,meta){
  items=items.filter(Boolean);if(!items.length)return;
  Q={items,by:new Map(items.map(i=>[i.id,i])),meta,info:new Map(),mode:'same',cur:0,each:new Map(),open:new Set(),compat:true,loading:true,n:0,bad:0};
  modal('<div id="qb"></div>');$('#modal').className='modal wide';renderQ();const q=Q;let i=0;
  const w=async()=>{while(Q===q&&i<items.length){const it=items[i++];try{const f=await api('/api/formats?id='+it.id);q.info.set(it.id,f);if(it.fileSrc){it.title=f.title;it.thumb=f.thumb||it.thumb}}catch(e){q.bad++}q.n++;if(Q===q)renderQ()}};
  await Promise.all([w(),w(),w(),w()]);if(Q!==q)return;
  q.ok=items.filter(i=>q.info.has(i.id));q.loading=false;
  if(q.ok.length){const A=agg('audios'),c=mkCtx();c.oa=(A.find(e=>e.f.ext==='m4a')||A[0]||{}).f||null;defVM(c);
    q.same=c;q.ok.forEach(i=>q.each.set(i.id,cloneCtx(c)))}
  renderQ()}
function subList(lst,e){const have=new Set(e.ids),miss=Q.ok.filter(i=>!have.has(i.id)).map(i=>{const r=(lst==='videos'?pickV:pickA)(Q.info.get(i.id)[lst],e.f);return `<div class="r">\u26a0 ${esc(i.title)} \u2192 ${r?esc(r.f.label):'none'}</div>`});
  return `<div class="sub"><b class="g">Has it (${e.ids.length})</b>${e.ids.map(id=>`<div class="g">\u2713 ${esc(Q.by.get(id).title)}</div>`).join('')}${miss.length?`<b class="r">Will use the nearest quality (${miss.length})</b>${miss.join('')}`:''}</div>`}
function renderQ(){const q=Q,body=$('#qb');if(!q||!body)return;
  if(q.loading){body.innerHTML=`<h2 style="font-size:20px">Checking qualities\u2026</h2><p class="mut">${q.n} of ${q.items.length} videos</p><div class="bar"><i style="width:${q.n/q.items.length*100}%"></i></div>`;return}
  if(!q.ok.length){body.innerHTML='<p class="err">None of the selected videos could be read.</p>'+closeBtn();return}
  const sc=[...body.querySelectorAll('.qlist')].map(x=>x.scrollTop),N=q.ok.length,cur=q.ok[q.cur],c=ctxOf(cur.id),same=q.mode==='same',cn=same&&N>1;
  const rs=q.ok.map(i=>resAll(i.id)),jobs=rs.flat(),fb=jobs.filter(r=>r.fb).length+rs.reduce((t,r)=>t+r.dup,0),miss=rs.reduce((t,r)=>t+(r.miss||0),0);
  /* space estimate from everything ticked */
  const sz=r=>(r.v?r.v.size||0:0)+(r.a?r.a.size||0:0),by={video:[],vonly:[],audio:[]};jobs.forEach(r=>by[r.kind].push(r));
  const sum=l=>l.reduce((t,r)=>t+sz(r),0),fin=sum(jobs),peak=Math.max(0,...by.video.map(sz)),need=fin+peak,unk=jobs.filter(r=>!sz(r)).length;
  const brk=[['video','Video + audio'],['vonly','Video only'],['audio','Audio only']].filter(([k])=>by[k].length).map(([k,n])=>`${n}: <b>${ms(sum(by[k]))}</b> \u00b7 ${by[k].length} file${by[k].length>1?'s':''}`).join('<br>');
  const strip=N>1?`<div class="strip">${q.ok.map((it,i)=>{const r=rs[i],g=r.length&&!r.some(x=>x.fb)&&!r.miss&&!r.dup;return `<div class="chip ${same?'':'pick1'} ${!same&&i===q.cur?'on':''}" data-i="${i}"><button class="x" data-rm="${i}" title="Remove this video">\u00d7</button><img src="${esc(it.thumb)}" alt=""><div>${esc(it.title)}</div><div class="${g?'g':'r'}">${r.length?r.length+' file'+(r.length>1?'s':'')+(g?' \u2713':r.miss?' \u26a0 some missing':' \u26a0 nearest'):'\u2717 nothing to download'}</div></div>`}).join('')}</div>`:'';
  const info=(e,sk,fn)=>{const has=cn?e.ids.length===N:e.ids.includes(cur.id),tot=cn?q.ok.reduce((t,i)=>t+fn(i.id),0):fn(cur.id),sh=q.open.has(sk);
    return{has,sh,html:cn?`<b class="${has?'g':'r'}">available in ${e.ids.length} of ${N} videos</b> \u00b7 <span class="${has?'g':'r'}">${ms(tot)} in total</span> <button class="alt" data-show="${esc(sk)}">${sh?'Hide':'Show videos'}</button>`:has?`<span class="g">${ms(tot)}</span>`:'<span class="r">not available \u00b7 nearest is used</span>'}};
  const crow=(set,e,fn,text,lst)=>{const x=info(e,set+'|'+e.f.label,fn);
    return `<label class="opt"><input type="checkbox" data-set="${set}" data-l="${esc(e.f.label)}" ${c[set].has(e.f.label)?'checked':''}><span class="${x.has?'g':'r'}">${esc(text)}</span><span class="c">${x.html}</span></label>${x.sh?subList(lst,e):''}`};
  const arow=e=>{const x=info(e,'oa|'+e.f.label,id=>szA(id,e.f));
    return `<label class="opt"><input type="radio" name="oa" data-oa="1" data-l="${esc(e.f.label)}" ${c.oa&&c.oa.label===e.f.label?'checked':''}><span class="${x.has?'g':'r'}">${esc(e.f.label)}</span><span class="c">${x.html}</span></label>${x.sh?subList('audios',e):''}`};
  const V=agg('videos'),A=agg('audios'),H=V.filter(e=>e.f.fam==='h264'),qa=fmtBy('a',QA);
  const cats=[['vm','Video + audio'],['vo','Video only'],['ao','Audio only']];
  const catsH=`<div class="row" style="margin-top:8px">${cats.map(([k,n])=>`<label class="cat ${c.cat[k]?'on':''}"><input type="checkbox" data-cat="${k}" ${c.cat[k]?'checked':''}> ${n}</label>`).join('')}</div><div class="mut" style="margin-top:4px">Tick one or more types. Every quality you tick below is downloaded as its own file.</div>`;
  const secVM=c.cat.vm?`<div class="blk"><h3 class="sh">Video + audio</h3><b>Quick picks \u00b7 H.264 video + AAC 128k</b>
    <div class="qlist">${qa?(H.map(e=>crow('qp',e,id=>szV(id,e.f)+szA(id,qa),`${e.f.h}p${e.f.fps>30?e.f.fps:''} H.264 + AAC 128k`,'videos')).join('')||'<div class="sub">No H.264 formats for these videos.</div>'):'<div class="sub">AAC is not available for these videos.</div>'}</div>
    <b style="display:block;margin-top:10px">Other combinations</b>
    <div class="cols"><div><b>Video quality</b> <span class="mut">(tick several)</span><div class="qlist">${V.map(e=>crow('ox',e,id=>szV(id,e.f)+(c.oa?szA(id,c.oa):0),`${e.f.label} + ${c.oa?c.oa.label:'?'}`,'videos')).join('')}</div></div>
    <div><b>Audio quality</b> <span class="mut">(used with the ticked video qualities)</span><div class="qlist">${A.map(arow).join('')}</div></div></div></div>`:'';
  const secVO=c.cat.vo?`<div class="blk"><h3 class="sh">Video only <span class="mut">(no audio)</span></h3><div class="qlist">${V.map(e=>crow('vo',e,id=>szV(id,e.f),e.f.label,'videos')).join('')}</div></div>`:'';
  const secAO=c.cat.ao?`<div class="blk"><h3 class="sh">Audio only</h3><div class="qlist">${A.map(e=>crow('ao',e,id=>szA(id,e.f),e.f.label,'audios')).join('')}</div></div>`:'';
  const secDest=`<div class="blk"><h3 class="sh">Save to${!same?' <span class="mut">(this video)</span>':''}</h3>
    <div class="dst"><span class="mut">Folder:</span> <b>${esc(c.dest.base||OUT)}</b> ${c.dest.base?'':'<span class="tag tm">default</span>'}</div>
    <div class="row"><button class="alt" data-fold="1" type="button">\ud83d\udcc1 Custom folder</button>${c.dest.base?'<button class="alt" data-fdef="1" type="button">Use default folder</button>':''}</div>
    <label style="display:block;margin-top:8px"><input type="checkbox" data-sub="1" ${c.dest.useSub?'checked':''}> Save in a new folder${q.meta.playlist?' (named after the playlist)':''}</label>
    ${c.dest.useSub?`<input type="text" class="fname" data-name="1" value="${esc(c.dest.name)}" placeholder="Folder name"><div class="mut" style="margin-top:4px">Files will be saved in: <b id="dfinal">${esc(destTxt(c))}</b></div>`:''}</div>`;
  body.innerHTML=`<h2 style="font-size:20px">Choose quality</h2><div class="mut">${N} video${N>1?'s':''}${q.meta.playlist?' \u00b7 playlist: '+esc(q.meta.playlist):''}${q.bad?' \u00b7 '+q.bad+' could not be read':''}</div>
   ${N>1?`<div class="seg row" style="margin-top:8px"><button data-mode="same" class="${same?'on':''}">Same for all</button><button data-mode="each" class="${same?'':'on'}">Choose for each video</button></div>`:''}
   ${strip}${!same?`<div class="mut"><b>${esc(cur.title)}</b></div>`:''}
   ${catsH}${secVM}${secVO}${secAO}${secDest}
   ${!same&&N>1?`<div class="row" style="margin-top:8px"><button class="alt" id="qall">Use this choice for all ${N} videos</button></div>`:''}
   <div class="sum">${jobs.length?`<b>${jobs.length} file${jobs.length>1?'s':''}</b> from ${N} video${N>1?'s':''}, downloaded one after another`:'<b class="r">Nothing selected: tick at least one quality above.</b>'}${jobs.length&&!miss&&!fb?' \u00b7 <b class="g">all have the chosen quality</b>':''}${fb?` \u00b7 <b class="r">${fb} will use the nearest available quality</b>`:''}${miss?` \u00b7 <b class="r">${miss} not available, skipped</b>`:''}
     ${brk?`<br>${brk}`:''}
     <br>Space needed: <b>${ms(need)}</b>${peak?` = ${ms(fin)} for the finished files + ${ms(peak)} temporary working space (one video at a time)`:' for the finished files'}${unk?` \u00b7 ${unk} size${unk>1?'s':''} unknown`:''}
     <br>Free space in the default folder: ${FREE!=null?`<b class="${FREE>=need?'g':'r'}">${mb(FREE)}</b>${FREE>=need?'':' \u00b7 not enough for this selection'}`:'<span class="g">no limit reported</span>'} \u00b7 rough download time <b>${fin?'~'+hm(fin/BPS):'unknown'}</b> (merging adds more)
     <br>${KEEPV||KEEPA?`Finished videos are deleted after ${KEEPV} hours, audio-only files after ${KEEPA} hours.`:'Finished files stay in their folder until you delete them.'}</div>
   ${by.video.length?`<label style="display:block;margin-top:8px"><input type="checkbox" id="cp" ${q.compat?'checked':''}> Make merged files play everywhere (converts AV1/VP9 to H.264; slower)</label>`:''}
   <div class="row" style="margin-top:10px"><button id="qgo" ${jobs.length?'':'disabled'}>Start download (${jobs.length})</button><button class="alt" onclick="closeModal()">Cancel</button></div>`;
  body.querySelectorAll('.qlist').forEach((x,i)=>x.scrollTop=sc[i]||0)}
$('#modal').addEventListener('change',e=>{const t=e.target;if(!Q)return;
  if(t.id==='cp'){Q.compat=t.checked;return}
  if(Q.loading||!Q.ok||!Q.ok.length)return;const c=ctxOf(Q.ok[Q.cur].id);
  if(t.dataset.cat){const k=t.dataset.cat;c.cat[k]=t.checked?1:0;if(t.checked)defaults(c,k);return renderQ()}
  if(t.dataset.set){const s=c[t.dataset.set];t.checked?s.add(t.dataset.l):s.delete(t.dataset.l);return renderQ()}
  if(t.dataset.oa){c.oa=fmtBy('a',t.dataset.l);return renderQ()}
  if(t.dataset.sub){c.dest.useSub=t.checked;return renderQ()}});
$('#modal').addEventListener('input',e=>{const t=e.target;if(!Q||Q.loading||!Q.ok||!t.dataset||!t.dataset.name)return;
  const c=ctxOf(Q.ok[Q.cur].id);c.dest.name=t.value;const f=$('#dfinal');if(f)f.textContent=destTxt(c)});
$('#modal').addEventListener('click',e=>{if(!Q||Q.loading)return;const t=e.target,ch=t.closest('.chip');
  if(t.dataset.show){e.preventDefault();Q.open.has(t.dataset.show)?Q.open.delete(t.dataset.show):Q.open.add(t.dataset.show);return renderQ()}
  if(t.dataset.fold){const q=Q,c=ctxOf(q.ok[q.cur].id);return pickFolder({start:c.dest.base||OUT,title:'Choose a folder for the downloads'},p=>{c.dest.base=p;if(Q===q)renderQ()})}
  if(t.dataset.fdef){ctxOf(Q.ok[Q.cur].id).dest.base='';return renderQ()}
  if(t.dataset.rm!==undefined){const id=Q.ok[+t.dataset.rm].id;Q.ok=Q.ok.filter(i=>i.id!==id);Q.items=Q.items.filter(i=>i.id!==id);if(Q.meta.fromSel){SEL.delete(id);paint()}
    if(!Q.ok.length)return closeModal();Q.cur=Math.min(Q.cur,Q.ok.length-1);return renderQ()}
  if(t.id==='qall'){const c=cloneCtx(ctxOf(Q.ok[Q.cur].id));Q.same=cloneCtx(c);Q.ok.forEach(i=>Q.each.set(i.id,cloneCtx(c)));return renderQ()}
  if(t.dataset.mode){Q.mode=t.dataset.mode;return renderQ()}
  if(ch&&Q.mode==='each'){Q.cur=+ch.dataset.i;return renderQ()}
  if(t.id==='qgo'&&!t.disabled)startQ()});
async function startQ(){const items=[];
  Q.ok.forEach(it=>{const i=Q.info.get(it.id),pk=a=>({id:a.id,src:a.src,conv:a.conv,br:a.br,label:a.label,ext:a.ext}),c=ctxOf(it.id),
    dest={base:c.dest.base||'',sub:c.dest.useSub?(c.dest.name.trim()||'New folder'):''};
    resAll(it.id).forEach(r=>items.push({id:it.id,title:i.title,thumb:it.thumb,duration:i.duration,channel:i.channel,kind:r.kind,v:r.v?{id:r.v.id,label:r.v.label,fam:r.v.fam,h:r.v.h}:null,a:r.a?pk(r.a):null,est_bytes:(r.v?r.v.size||0:0)+(r.a?r.a.size||0:0),v_bytes:r.v?r.v.size||0:0,a_bytes:r.a?(r.a.dsize||r.a.size||0):0,fb:r.txt||null,dest}))});
  if(!items.length)return alert('Nothing to download.');
  const b=$('#qgo');if(b)b.disabled=true;
  try{await post('/api/download',{items,compat:Q.compat,playlist:Q.meta.playlist||null,use_cookies:CK.on&&CK.d});
    if(Q.meta.fromSel){SEL.clear();paint()}closeModal();setDl(true);loadJobs();$('#dl').scrollIntoView({behavior:'smooth'})}catch(e){alert(e.message);if(b)b.disabled=false}}
function closeModal(){Q=null;$('#ov').classList.remove('show');$('#modal').innerHTML='';$('#modal').className='modal'}
function modal(h){$('#modal').className='modal';$('#modal').innerHTML=h;$('#ov').classList.add('show')}
const closeBtn=()=>'<div class="row" style="margin-top:10px"><button class="alt" onclick="closeModal()">Close</button></div>';
$('#ov').onclick=e=>{if(e.target.id==='ov')closeModal()};

/* folder picker: works like a small file manager, no typing of paths */
let FP=null;
function pickFolder(o,cb){FP={mode:o.mode||'dir',ext:o.ext||'',title:o.title||'Choose folder',cb,data:null,err:'',busy:0};$('#ov2').classList.add('show');fpLoad(o.start||'')}
async function fpLoad(p){const f=FP;f.busy=1;renderFP();
  try{const d=await api('/api/browse?'+new URLSearchParams({path:p||'',files:f.mode==='file'?'1':'0',ext:f.ext}));if(FP!==f)return;f.data=d;f.err=d.error||''}catch(e){f.err=e.message}
  f.busy=0;if(FP===f)renderFP()}
function closeFP(){FP=null;$('#ov2').classList.remove('show');$('#modal2').innerHTML=''}
function renderFP(){const f=FP;if(!f)return;const d=f.data,dir=f.mode==='dir';
  if(!d){$('#modal2').innerHTML=`<h2 style="font-size:20px">${esc(f.title)}</h2><p class="mut">${f.err?'<span class="err">'+esc(f.err)+'</span>':'Loading\u2026'}</p><div class="row"><button class="alt" id="fpx">Cancel</button></div>`;return}
  $('#modal2').innerHTML=`<h2 style="font-size:20px">${esc(f.title)}</h2>
   <div class="fpath">${esc(d.path)}</div>
   <div class="roots">${d.roots.map(r=>`<button class="alt" data-p="${esc(r.path)}" data-k="d">${esc(r.name)}</button>`).join('')}</div>
   ${f.err?`<div class="err">${esc(f.err)}</div>`:''}${dir&&d.writable===false?'<div class="r">\u26a0 This folder may not be writable.</div>':''}
   <div class="fplist">
     ${d.parent?`<div class="fi" data-p="${esc(d.parent)}" data-k="d">\u2b06 Up one level</div>`:''}
     ${d.dirs.map(x=>`<div class="fi" data-p="${esc(x.path)}" data-k="d">\ud83d\udcc1 ${esc(x.name)}</div>`).join('')}
     ${d.files.map(x=>`<div class="fi" data-p="${esc(x.path)}" data-k="f">\ud83d\udcc4 ${esc(x.name)}</div>`).join('')}
     ${!d.dirs.length&&!d.files.length?`<div class="fi mut">${dir?'No folders here. You can still use this folder or make a new one.':'Nothing here.'}</div>`:''}
   </div>
   <div class="row" style="margin-top:10px">${dir?'<button class="alt" id="fpnew">New folder</button>':''}<button class="alt" id="fpx">Cancel</button>${dir?'<button id="fpuse">Use this folder</button>':''}</div>`}
$('#modal2').addEventListener('click',async e=>{const f=FP;if(!f)return;const t=e.target,it=t.closest('[data-p]');
  if(it){if(it.dataset.k==='f'){const p=it.dataset.p;closeFP();return f.cb(p)}return fpLoad(it.dataset.p)}
  if(t.id==='fpx')return closeFP();
  if(t.id==='fpuse'&&f.data){const p=f.data.path;closeFP();return f.cb(p)}
  if(t.id==='fpnew'&&f.data){const n=prompt('Name of the new folder');if(!n||!n.trim())return;
    try{const r=await post('/api/mkdir',{path:f.data.path,name:n.trim()});fpLoad(r.path)}catch(x){alert(x.message)}}});
$('#ov2').onclick=e=>{if(e.target.id==='ov2')closeFP()};

/* downloads */
const stageTxt={queued:'Waiting',downloading:'Downloading',merging:'Merging',uploading:'Saving to folder',cancelling:'Cancelling',cancelled:'Cancelled',expired:'Deleted (time limit)',deleted:'Deleted',confirm:'Unfinished job found',done:'Finished',error:'Stopped'};
const stageLabel=j=>j.stage==='merging'&&j.kind==='audio'?'Converting to MP3':(stageTxt[j.stage]||j.stage);
const jobPct=j=>j.stage==='downloading'?j.dl:j.stage==='merging'?j.merge:j.stage==='uploading'?j.up:0;
const stCls={done:'ok',downloading:'run',error:'err',pending:'mut'};
const lk=(t,u)=>u?`<div class="lk"><a href="${u}" target="_blank" rel="noopener">${t}</a><button onclick="navigator.clipboard.writeText('${u}')">Copy link</button></div>`:'';
const r30=t=>Math.round(t/30)*30;
const stepH=(s,k)=>{const bar=k!=='p'&&s.status!=='pending',pct=Math.max(0,Math.min(100,s.pct||0)),m=[];
  if(bar)m.push(`<b>${Math.floor(pct)}%</b>`);
  if(s.status==='downloading'&&(k==='v'||k==='a')&&s.spd)m.push(sp(s.spd));
  if(s.t0)m.push(`<b class="el" data-s="${s.t0}" data-f="${s.t1||''}"></b>`);
  if(s.status==='downloading'&&s.eta)m.push(`about <span class="left" data-s="${r30(s.eta)}"></span> left`);
  else if(s.status==='pending'&&s.est)m.push('estimated '+hm(s.est));
  const c=k==='m'||k==='c'?'m':k==='s'?'u':'';
  return `<div class="st"><div class="sl"><span class="${stCls[s.status]||'mut'}">${esc(s.text)}</span><span class="sr">${m.join(' \u00b7 ')}</span></div>${bar?`<div class="bar s ${c}"><i style="width:${pct}%"></i></div>`:''}</div>`};
const cookieAsk=j=>j.cookie_ask?`<div class="ask"><b>This video asks for cookies.txt.</b><div class="mut">Found: ${esc(j.cookie_ask)}<br>Use it for this download only?</div><div class="lnk"><button onclick="act('${j.id}','cookies')">Use cookies.txt</button><button class="alt" onclick="act('${j.id}','nocookies')">No</button></div></div>`:`<div class="ask"><b>This video asks for cookies.txt.</b><div class="mut">No cookies.txt found. Choose it in Settings or put it in ${esc(OUT||'the downloads folder')}.</div></div>`;
function jobHtml(j){const au=j.kind==='audio',vo=j.kind==='vonly',ql=au?j.a.label:vo?j.v.label:j.v.label+' + '+j.a.label,live=LIVE.includes(j.stage),fin=END.includes(j.stage);
  return `<img src="${esc(j.thumb)}" alt=""><div>${j.pos?`<span class="tag tv" title="Order of this video: the first one has priority">#${j.pos}</span> `:''}<b>${esc(j.title)}</b>
   <div class="mut"><span class="tag ${au?'ta':vo?'tm':'tv'}">${au?'Audio only':vo?'Video only':'Video + audio'}</span> ${esc(ql)}${j.playlist?' \u00b7 playlist: '+esc(j.playlist):''}</div>
   ${j.dest&&j.stage!=='done'?`<div class="mut">Folder: ${esc(j.dest)}</div>`:''}
   ${j.fallback?`<div class="mut">Nearest quality used: ${esc(j.fallback)}</div>`:''}
   <div class="${j.stage==='error'?'err':'mut'}"><b>${esc(stageLabel(j))}</b>${live&&j.stage!=='cancelling'?' '+Math.floor(jobPct(j))+'%':''}${j.note&&j.stage!=='done'?' \u2014 '+esc(j.note):''}</div>
   ${j.stage==='queued'?`<div class="mut">Starts in about <span class="left" data-s="${r30(j.start_at)}"></span> \u00b7 done around ${clk(r30(j.eta_at))}</div>`:''}
   ${j.started&&j.stage!=='queued'?`<div class="mut">Time taken <b class="el" data-s="${j.started}" data-f="${fin&&j.finished?j.finished:''}"></b>${live&&!j.paused?` \u00b7 about <span class="left" data-s="${r30(j.eta_at)}"></span> left \u00b7 done around ${clk(r30(j.eta_at))}`:''}</div>`:''}
   ${j.stage==='downloading'?`<div class="mut">${mb(j.done_b)} of ${mb(j.total_b)}${j.speed?' \u00b7 <b>'+sp(j.speed)+'</b> now':''}</div>`:''}
   ${(live||j.stage==='done'||j.stage==='error')?Object.entries(j.steps||{}).map(([k,s])=>stepH(j.paused?{...s,eta:0,spd:0}:s,k)).join(''):''}
   ${j.stage==='confirm'?`<div class="ask"><b>Continue this job?</b><div class="lnk"><button onclick="act('${j.id}','resume')">Continue</button><button class="alt" onclick="act('${j.id}','skip')">No, mark it complete</button></div></div>`:''}
   ${j.stage==='error'&&j.cookie_need?cookieAsk(j):''}${j.stage==='error'?`<div class="lnk"><button onclick="act('${j.id}','resume')">Retry</button><button class="alt" onclick="act('${j.id}','skip')">Mark complete</button></div>`:''}
   ${j.stage==='done'?lk(au?'Audio file':vo?'Video file (no audio)':'Merged video + audio',j.direct)+`${j.path?`<div class="mut">Saved: ${esc(j.path)}</div>`:''}${j.expires_at?`<div class="mut">Deleted automatically in <span class="left" data-s="${r30(j.expires_at)}"></span></div>`:''}<div class="lnk"><button onclick="del('${j.id}')">Delete now</button></div>`:''}
   ${['queued','confirm','error'].includes(j.stage)||(live&&j.stage!=='cancelling')?`<div class="lnk">${(j.stage==='queued'||(live&&j.stage!=='cancelling'))?(j.paused?`<button onclick="act('${j.id}','unpause')">&#9654; Resume</button>`:`<button class="alt" onclick="act('${j.id}','pause')">&#10074;&#10074; Pause</button>`):''}<button class="alt" onclick="cancelJob('${j.id}',${live})">Cancel${live?' and delete files':''}</button></div>`:''}</div>`}
const jobEls=new Map();
const verb=j=>j.stage==='downloading'?'Downloading':j.stage==='merging'?(j.kind==='audio'?'Converting':'Merging'):j.stage==='uploading'?'Saving':'Cancelling';
function renderSummary(d){
  const s=d.summary,live=d.jobs.filter(j=>LIVE.includes(j.stage)),wait=d.jobs.filter(j=>j.stage==='queued');
  $('#gspd').hidden=false;$('#gspdv').textContent=sp(s.speed)||'0 KB/s';
  const w=s.smart,gsw=$('#gsw');if(w&&w.kind){gsw.hidden=false;gsw.textContent=(w.kind==='switch'?'Switching video in ':w.kind==='pause'?'Limiting 2nd video in ':'Releasing 2nd video in ')+w.left+'s'}else gsw.hidden=true;
  let h='';
  if(!(s.active+s.queued))h='<span class="mut">Nothing downloading.</span>';
  else{
    h=live.map(j=>`<div class="ql"><span class="run">${verb(j)}</span> ${esc(j.title)} <b>${Math.floor(jobPct(j))}%</b>${j.stage==='downloading'&&j.speed?' \u00b7 '+sp(j.speed):''}</div>`).join('');
    if(s.queued)h+=`<div class="ql"><span class="mut">Waiting (${s.queued}):</span> ${wait.slice(0,3).map(j=>esc(trimT(j.title,40))).join(', ')}${s.queued>3?' +'+(s.queued-3)+' more':''}</div>`;
    h+=`<div class="mut" style="margin-top:4px">Everything, merging included, finishes in about <span class="left" data-s="${r30(s.finish_at)}"></span> (around ${clk(r30(s.finish_at))})</div>`;
  }
  $('#qsum').innerHTML=h;
  $('#pallbar').hidden=!(s.active+s.queued);
  $('#stopbar').hidden=!s.stopped;$('#stopn').textContent=s.stopped+' download'+(s.stopped>1?'s':'');$('#cnt').textContent='Continue all ('+s.stopped+')';
}
let HOLDUI=0;      /* a tap on a card stops that card from being redrawn for a moment, so the tap is never lost */
document.addEventListener('pointerdown',e=>{if(e.target.closest&&e.target.closest('#jobs'))HOLDUI=Date.now()+900},true);
function applyJobs(d){
  skew=d.now-Date.now()/1000;
  const L=d.jobs,box=$('#jobs');
  renderSummary(d);
  if(!L.length){box.innerHTML='<div class="empty">Nothing downloading.</div>';jobEls.clear()}
  else{
    const e0=box.querySelector('.empty');if(e0)e0.remove();
    L.forEach((j,i)=>{const h=jobHtml(j);let o=jobEls.get(j.id);
      if(!o){o={el:document.createElement('div'),html:''};o.el.className='job';jobEls.set(j.id,o)}
      if(o.html!==h&&Date.now()>HOLDUI&&!o.el.querySelector(':active')){o.el.innerHTML=h;o.html=h}
      if(box.children[i]!==o.el)box.insertBefore(o.el,box.children[i]||null)});
    const ids=new Set(L.map(j=>j.id));for(const[id,o]of jobEls)if(!ids.has(id)){o.el.remove();jobEls.delete(id)}
  }
  tock();noteUpdate(d)}
async function loadJobs(){if(!online)return;try{applyJobs(await api('/api/jobs'))}catch(e){}}
/* live updates pushed by the program every second (also while this tab is in the background) */
let ES=null,LASTMSG=0;
function startStream(){if(ES||!window.EventSource)return;
  ES=new EventSource(API+'/api/stream');ES.onmessage=e=>{LASTMSG=Date.now();try{applyJobs(JSON.parse(e.data))}catch(x){}}}
function tock(){const t=now();
  document.querySelectorAll('.el').forEach(e=>e.textContent=dur(Math.max(0,(+e.dataset.f||t)-+e.dataset.s))||'0:00');
  document.querySelectorAll('.left').forEach(e=>e.textContent=+e.dataset.s-t>1?hm(+e.dataset.s-t):'a moment')}
async function act(id,w){try{await api('/api/jobs/'+id+'/'+w,{method:'POST'});HOLDUI=0;loadJobs()}catch(e){alert(e.message)}}
function cancelJob(id,live){if(!live||confirm('Cancel this download? Everything downloaded for it is deleted.'))act(id,'cancel')}
function del(id){if(confirm('Delete this file from your device now?'))act(id,'delete')}
$('#pall').onclick=()=>api('/api/jobs/pause_all',{method:'POST'}).then(()=>{HOLDUI=0;loadJobs()}).catch(e=>alert(e.message));
$('#rall').onclick=()=>api('/api/jobs/unpause_all',{method:'POST'}).then(()=>{HOLDUI=0;loadJobs()}).catch(e=>alert(e.message));
$('#cxa').onclick=()=>{if(confirm('Cancel every waiting and running download and delete their files?'))api('/api/jobs/cancel_all',{method:'POST'}).then(loadJobs).catch(e=>alert(e.message))};
$('#cnt').onclick=async()=>{const b=$('#cnt');b.disabled=true;try{await api('/api/jobs/resume_all',{method:'POST'});await loadJobs()}catch(e){alert(e.message)}b.disabled=false};
$('#clr').onclick=async()=>{try{await api('/api/jobs/clear',{method:'POST'});loadJobs()}catch(e){}};

/* one single notification: what is downloading + what is waiting (needs this page open in a tab) */
let NOTE_ON=false,NOTE_DISMISSED=false,NOTE_KEY='',NOTE_LAST='',NOTE_WAS=false,NOTE_T=null,NOTE_BUSY=false,SWREG=null;
async function noteReg(){if(SWREG)return SWREG;if(!('serviceWorker' in navigator))return null;
  try{await navigator.serviceWorker.register('/sw.js');SWREG=await navigator.serviceWorker.ready}catch(e){}return SWREG}
function bellUi(){$('#bell').classList.toggle('on',NOTE_ON);$('#bell').title=NOTE_ON?'Notifications are on (click to turn off)':'Turn on notifications'}
async function enableNotes(){
  if(!('Notification' in window)){alert('Progress notifications are shown by the app itself (see your notification bar).');return false}
  if(!window.isSecureContext){alert('Notifications only work when you open this page as http://localhost:... or http://127.0.0.1:...');return false}
  let p=Notification.permission;if(p==='default')p=await Notification.requestPermission();
  if(p!=='granted'){alert('Notifications are blocked. Allow them for this site in Chrome (lock icon next to the address, Permissions).');NOTE_ON=false;LS.set('note','0');bellUi();return false}
  NOTE_ON=true;NOTE_DISMISSED=false;NOTE_LAST='';LS.set('note','1');await noteReg();bellUi();return true}
function disableNotes(){NOTE_ON=false;LS.set('note','0');noteClose();bellUi()}
async function noteClose(){try{const r=await noteReg();if(r)(await r.getNotifications({tag:'tube-status'})).forEach(n=>n.close())}catch(e){}}
async function noteShow(title,body,fin){
  const o={body,tag:'tube-status',silent:!fin,renotify:!!fin,requireInteraction:!fin};
  try{const r=await noteReg();if(r){await r.showNotification(title,o);return}}catch(e){}
  try{new Notification(title,o)}catch(e){}}
function noteText(d){
  const s=d.summary,live=d.jobs.filter(j=>LIVE.includes(j.stage)),wait=d.jobs.filter(j=>j.stage==='queued'),L=[];
  live.forEach(j=>L.push((j.stage==='downloading'?'\u2b07 Downloading':j.stage==='merging'?(j.kind==='audio'?'\ud83c\udfb5 Converting':'\u2699 Merging'):j.stage==='uploading'?'\ud83d\udcbe Saving':'\u2716 Cancelling')+': '+trimT(j.title,60)+' \u2014 '+Math.floor(jobPct(j))+'%'+(j.stage==='downloading'&&j.speed?' \u00b7 '+sp(j.speed):'')));
  if(s.queued)L.push('\u23f3 Waiting ('+s.queued+'): '+wait.slice(0,3).map(j=>trimT(j.title,32)).join(', ')+(s.queued>3?' +'+(s.queued-3)+' more':''));
  if(s.stopped)L.push('\u26a0 Stopped: '+s.stopped);
  return{title:'Tube to Drive'+(s.speed>0?' \u00b7 \u2193 '+sp(s.speed):''),body:L.join('\n')}}
async function noteUpdate(d){
  if(!NOTE_ON||!('Notification' in window)||Notification.permission!=='granted')return;
  const s=d.summary,active=s.active+s.queued>0,key=d.jobs.filter(j=>LIVE.includes(j.stage)).map(j=>j.id).join(',');
  if(key!==NOTE_KEY){NOTE_KEY=key;NOTE_DISMISSED=false}
  if(active){NOTE_WAS=true;clearTimeout(NOTE_T);if(NOTE_DISMISSED)return;
    const t=noteText(d),sig=t.title+'|'+t.body;if(sig===NOTE_LAST||NOTE_BUSY)return;
    NOTE_BUSY=true;NOTE_LAST=sig;try{await noteShow(t.title,t.body,false)}finally{NOTE_BUSY=false}}
  else if(NOTE_WAS){NOTE_WAS=false;NOTE_DISMISSED=false;NOTE_LAST='';
    await noteShow('Tube to Drive',s.stopped?'Finished. '+s.stopped+' stopped - open the page to retry.':'\u2713 All downloads finished',true);
    clearTimeout(NOTE_T);NOTE_T=setTimeout(noteClose,20000)}}
if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('message',e=>{if(e.data&&e.data.type==='note-closed')NOTE_DISMISSED=true});
$('#bell').onclick=()=>NOTE_ON?disableNotes():enableNotes();
if(LS.get('note')==='1'&&'Notification' in window&&Notification.permission==='granted'){NOTE_ON=true;noteReg()}
bellUi();
if(navigator.locks)navigator.locks.request('tube-keepalive',()=>new Promise(()=>{})).catch(()=>{});

/* speed graph: click the speed in the header */
let GR=null;
const GRR=[[300,'5 min'],[1800,'30 min'],[3600,'1 hour'],[21600,'6 hours']];
function openGraph(){if(!online)return;GR={secs:+LS.get('grsecs')||300,d:null};modal('<div id="gr"><p class="mut">Loading\u2026</p></div>');$('#modal').className='modal wide';drawGraph()}
async function drawGraph(){const g=GR;if(!g||!$('#gr'))return;
  try{const d=await api('/api/speedlog?secs='+g.secs);if(GR===g&&$('#gr')){g.d=d;renderGraph()}}catch(e){if(GR===g&&$('#gr'))$('#gr').innerHTML='<p class="err">'+esc(e.message)+'</p>'+closeBtn()}
  clearTimeout(g.t);g.t=setTimeout(()=>{if(GR===g&&$('#gr'))drawGraph()},2000)}
function niceMax(v){const m=v/1e6,st=[.5,1,2,5,10,20,50,100,200,500,1000];return(st.find(x=>x>=m)||Math.ceil(m))}
function renderGraph(){const g=GR,d=g.d,box=$('#gr');if(!box||!d)return;
  const W=640,H=230,L=52,R=12,T=12,B=26,x0=d.now-d.secs,X=t=>L+(t-x0)/d.secs*(W-L-R),top=niceMax(Math.max(1,...d.points.map(p=>p[1]))),Y=v=>T+(1-v/1e6/top)*(H-T-B);
  const pts=d.points,line=pts.map((p,i)=>(i?'L':'M')+X(p[0]).toFixed(1)+' '+Y(p[1]).toFixed(1)).join(' '),
    area=pts.length?line+` L${X(pts[pts.length-1][0]).toFixed(1)} ${Y(0)} L${X(pts[0][0]).toFixed(1)} ${Y(0)} Z`:'';
  const grid=[0,.5,1].map(f=>`<line x1="${L}" x2="${W-R}" y1="${Y(f*top*1e6)}" y2="${Y(f*top*1e6)}" stroke="#d3dbe7" stroke-width="1"/><text x="${L-6}" y="${Y(f*top*1e6)+4}" text-anchor="end" font-size="11" fill="#5d6b82">${+(f*top).toFixed(2)} MB/s</text>`).join('');
  const tl=[0,.5,1].map(f=>{const t=x0+f*d.secs;return `<text x="${L+f*(W-L-R)}" y="${H-8}" text-anchor="${f===0?'start':f===1?'end':'middle'}" font-size="11" fill="#5d6b82">${new Date(t*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:d.secs<=1800?'2-digit':undefined})}</text>`}).join('');
  const cur=pts.length?pts[pts.length-1][1]:0;
  box.innerHTML=`<h2 style="font-size:20px">Internet speed</h2>
   <div class="seg row" style="margin:8px 0">${GRR.map(r=>`<button data-gr="${r[0]}" class="${r[0]===g.secs?'on':''}" type="button">${r[1]}</button>`).join('')}</div>
   <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;background:#f6f8fc;border-radius:10px" role="img" aria-label="Download speed history">${grid}${tl}${area?`<path d="${area}" fill="rgba(47,75,255,.15)"/>`:''}${pts.length?`<path d="${line}" fill="none" stroke="#2f4bff" stroke-width="2" stroke-linejoin="round"/>`:`<text x="${W/2}" y="${H/2}" text-anchor="middle" fill="#5d6b82" font-size="13">No downloads in this time range</text>`}</svg>
   <div class="grid" style="margin-top:10px;grid-template-columns:repeat(auto-fill,minmax(150px,1fr))">
     <div class="sum"><div class="mut">Now</div><b>${sp(cur)||'0 KB/s'}</b></div>
     <div class="sum"><div class="mut">Average</div><b>${sp(d.avg)||'0 KB/s'}</b></div>
     <div class="sum"><div class="mut">Peak</div><b>${sp(d.peak)||'0 KB/s'}</b></div>
     <div class="sum"><div class="mut">Data used (${esc(GRR.find(r=>r[0]===g.secs)[1])})</div><b>${d.range_bytes?mb(d.range_bytes):'0 MB'}</b></div>
     <div class="sum"><div class="mut">Data used since the program started</div><b>${d.total_bytes?mb(d.total_bytes):'0 MB'}</b></div></div>
   <div class="mut" style="margin-top:6px">Counted since ${new Date(d.since*1000).toLocaleString()}. History is kept while the program runs.</div>${closeBtn()}`}
$('#modal').addEventListener('click',e=>{const t=e.target;if(t.dataset&&t.dataset.gr&&GR){GR.secs=+t.dataset.gr;LS.set('grsecs',String(GR.secs));drawGraph()}});
$('#gspd').onclick=openGraph;
$('#gspd').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openGraph()}};

/* settings */
function pinOk(v){const p=n=>String(n).padStart(2,'0'),d=Date.now();
  for(const o of [0,-1,1]){const t=new Date(d+o*60000);let h=t.getHours()%12;if(h===0)h=12;if(v===p(h)+p(t.getMinutes()))return true}return false}
$('#gear').onclick=()=>{
  modal('<h2 style="font-size:22px">Settings</h2><div class="mut">Enter the 4-digit PIN</div><div class="row" style="margin-top:10px"><input id="pinIn" type="password" inputmode="numeric" maxlength="4" autocomplete="off" style="width:130px;font-size:24px;letter-spacing:8px;text-align:center"><button id="pinGo" type="button">Open</button><button class="alt" onclick="closeModal()" type="button">Close</button></div><div id="pinMsg" class="err" style="margin-top:8px"></div>');
  const go=async()=>{const v=$('#pinIn').value.trim();
    if(!pinOk(v)){$('#pinMsg').textContent='Wrong PIN';$('#pinIn').value='';return}
    modal('<p class="mut">Loading\u2026</p>');
    try{renderSettings(await api('/api/settings'))}catch(e){$('#modal').innerHTML='<p class="err">'+esc(e.message)+'</p>'+closeBtn()}};
  $('#pinGo').onclick=go;$('#pinIn').onkeydown=e=>{if(e.key==='Enter')go()};setTimeout(()=>{const i=$('#pinIn');if(i)i.focus()},80)};
function renderSettings(s){
  $('#modal').innerHTML=`<h2 style="font-size:22px">Settings</h2><div class="set">
   <label class="lb" for="s_out">Save downloads in</label>
   <div class="row"><input type="text" id="s_out" value="${esc(s.out)}" spellcheck="false"><button class="alt" id="s_outb" type="button">Browse</button></div>
   <div class="mut">Default: ${esc(s.out_default)} ${s.out_custom?'<button class="alt sm" id="s_outr" type="button">Use default</button>':''}</div>
   <label class="lb" for="s_ck">cookies.txt file</label>
   <div class="row"><input type="text" id="s_ck" value="${esc(s.cookies)}" placeholder="Leave empty to find it automatically" spellcheck="false"><button class="alt" id="s_ckb" type="button">Browse</button><button class="alt" id="s_ckc" type="button">Clear</button></div>
   <div class="mut">${s.cookies_found?'In use if a download asks for it: '+esc(s.cookies_found):'No cookies.txt found yet.'} It is only used when a download asks for it and you allow it.</div>
   <label class="lb">Use cookies.txt</label>
   <div class="row"><button class="tg" id="s_ckon" type="button" aria-pressed="false">Use cookies.txt: <b id="s_ckst">Off</b></button></div>
   <div class="row" id="s_ckp" style="margin-top:8px" hidden>
     <label class="tg"><input type="checkbox" id="s_cks"> Search</label>
     <label class="tg"><input type="checkbox" id="s_ckf"> Available qualities</label>
     <label class="tg"><input type="checkbox" id="s_ckd"> Download</label>
   </div>
   <div class="mut">When on, cookies.txt is used only for the tasks you tick.</div>
   <label class="lb">Switch away from slow downloads</label>
   <div class="row"><button class="tg" id="s_smart" type="button" aria-pressed="false">Auto-switch: <b id="s_smartst">Off</b></button></div>
   <div class="two" style="margin-top:8px"><label>Minimum speed (MB/s)<input type="number" id="s_mmb" min="0" step="any" value="${s.min_mb}"></label><label>Wait (seconds)<input type="number" id="s_wsec" min="1" step="any" value="${s.wait_s}"></label></div>
   <div class="mut">When on, the first video is the priority. If its speed stays below the minimum for the wait time, the next video starts downloading too. When the first video is fast again for the wait time, the second one is paused until the first is slow again or finished. While the second video is running, the first one only needs 50% of the minimum speed to take over again, so it does not keep switching back and forth.</div>
   <label class="lb">Parallel work</label>
   <div class="row"><label class="tg"><input type="checkbox" id="s_pdl" ${s.par_dl?'checked':''}> Allow downloading several videos at once</label>
     <label class="mut">Number <input type="number" id="s_pn" min="1" max="8" step="1" value="${s.par_n}" style="width:70px"></label></div>
   <div class="row" style="margin-top:6px"><label class="tg"><input type="checkbox" id="s_dm" ${s.dl_merge?'checked':''}> Allow downloading while another video is merging</label></div>
   <div class="row" style="margin-top:6px"><label class="tg"><input type="checkbox" id="s_pm" ${s.par_merge?'checked':''}> Allow merging several videos at once</label>
     <label class="mut">Number <input type="number" id="s_mn" min="1" max="8" step="1" value="${s.merge_n}" style="width:70px"></label></div>
   <div class="two" style="margin-top:8px"><label>Second video speed while the first is fast (KB/s, 1 = almost paused)<input type="number" id="s_skb" min="1" step="any" value="${s.second_kb}"></label><label>Speed of extra videos (KB/s, 1 = almost paused)<input type="number" id="s_ekb" min="1" step="any" value="${s.extra_kb}"></label></div>
   <div class="two" style="margin-top:8px"><label>Speed of extra merges (% of full speed)<input type="number" id="s_mpc" min="5" max="100" step="any" value="${s.merge_pct}"></label></div>
   <div class="mut">With everything unticked, videos download one after another. When a video has finished downloading, the next one starts downloading while it merges (second box). Auto-switch above can still start a second download when the first is slow. Videos or merges beyond what these options allow are never stopped: they only run slowly (extra videos at the KB/s above, extra merges at the % above) until they are within the limit again.</div>
   <label class="lb">Delete finished files automatically (hours, 0 = never)</label>
   <div class="two"><label>Videos<input type="number" id="s_kv" min="0" step="any" value="${s.keep_video}"></label><label>Audio only<input type="number" id="s_ka" min="0" step="any" value="${s.keep_audio}"></label></div>
   <label class="lb">Notifications</label>
   <div class="row"><button class="alt" id="s_note" type="button">${NOTE_ON?'Turn off notifications':'Turn on notifications'}</button></div>
   <div class="mut">One notification shows what is downloading and what is waiting. Keep this page open in a Chrome tab; it can stay in the background.</div>
   <div class="blk"><h3 class="sh">yt-dlp</h3>
    <div class="mut">Installed version: <b id="yv">${esc(s.yt.version||'not installed')}</b> \u00b7 ffmpeg: ${s.ffmpeg?'found':'not found'}</div>
    <div class="mut" style="margin-top:6px">yt-dlp is reinstalled automatically every 4 days.</div>
    <pre class="log" id="ylog" hidden></pre></div>
   <div class="row" style="margin-top:14px"><button id="s_save" type="button">Save settings</button><button class="alt" onclick="closeModal()" type="button">Close</button></div>
   <div id="s_msg" class="mut" style="margin-top:8px"></div></div>`;
  $('#s_outb').onclick=()=>pickFolder({start:$('#s_out').value||OUT,title:'Save downloads in'},p=>{const i=$('#s_out');if(i)i.value=p});
  const rb=$('#s_outr');if(rb)rb.onclick=()=>{$('#s_out').value=s.out_default};
  $('#s_ckb').onclick=()=>pickFolder({mode:'file',ext:'.txt',start:$('#s_ck').value||OUT,title:'Choose your cookies.txt'},p=>{const i=$('#s_ck');if(i)i.value=p});
  $('#s_ckc').onclick=()=>{$('#s_ck').value=''};
  ckWire();
  /* the parallel-work options are saved the moment you change them */
  const autoSave=async()=>{const m=$('#s_msg');try{await post('/api/settings',{par_dl:$('#s_pdl').checked,par_n:$('#s_pn').value||1,dl_merge:$('#s_dm').checked,par_merge:$('#s_pm').checked,merge_n:$('#s_mn').value||1,second_kb:$('#s_skb').value||300,extra_kb:$('#s_ekb').value||400,merge_pct:$('#s_mpc').value||25});if(m){m.className='mut';m.innerHTML='<span class="g">Saved \u2713</span>'}}catch(e){if(m){m.className='mut';m.innerHTML='<span class="err">'+esc(e.message)+'</span>'}}};
  ['s_pdl','s_pn','s_dm','s_pm','s_mn','s_skb','s_ekb','s_mpc'].forEach(id=>{$('#'+id).onchange=autoSave});
  let smartOn=!!s.smart;const smartUi=()=>{const b=$('#s_smart');if(!b)return;b.classList.toggle('on',smartOn);b.setAttribute('aria-pressed',String(smartOn));$('#s_smartst').textContent=smartOn?'On':'Off'};
  smartUi();
  $('#s_smart').onclick=async()=>{const want=!smartOn;try{await post('/api/settings',{smart:want,min_mb:$('#s_mmb').value||0,wait_s:$('#s_wsec').value||10});smartOn=want;smartUi()}catch(e){alert(e.message)}};
  $('#s_note').onclick=async()=>{if(NOTE_ON)disableNotes();else await enableNotes();const b=$('#s_note');if(b)b.textContent=NOTE_ON?'Turn off notifications':'Turn on notifications'};
  $('#s_save').onclick=async()=>{const m=$('#s_msg');m.className='mut';m.textContent='Saving\u2026';
    try{const r=await post('/api/settings',{out:$('#s_out').value.trim(),cookies:$('#s_ck').value.trim(),keep_video:$('#s_kv').value||0,keep_audio:$('#s_ka').value||0,smart:smartOn,min_mb:$('#s_mmb').value||0,wait_s:$('#s_wsec').value||10,par_dl:$('#s_pdl').checked,par_n:$('#s_pn').value||1,dl_merge:$('#s_dm').checked,par_merge:$('#s_pm').checked,merge_n:$('#s_mn').value||1,second_kb:$('#s_skb').value||300,extra_kb:$('#s_ekb').value||400,merge_pct:$('#s_mpc').value||25});
      OUT=r.out;m.innerHTML='<span class="g">Saved \u2713</span>';ping()}catch(e){m.innerHTML='<span class="err">'+esc(e.message)+'</span>'}};
  if(s.yt.state==='running')ytPoll()}
function ytPoll(){if(!$('#ylog'))return;
  api('/api/ytdlp').then(y=>{const l=$('#ylog');if(!l)return;
    l.hidden=!y.log.length;l.textContent=y.log.join('\n');l.scrollTop=l.scrollHeight;
    $('#yv').textContent=y.version||'not installed';
    if(y.state==='running')setTimeout(ytPoll,1000);else ping()}).catch(()=>setTimeout(ytPoll,1500))}

/* videos from a file: any format, links are detected anywhere in its text */
async function inflate(u8){const r=new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate-raw')));return new Uint8Array(await r.arrayBuffer())}
async function unzipText(b){const out=[],dv=new DataView(b.buffer,b.byteOffset,b.byteLength),td=new TextDecoder();let e=-1;
  for(let i=b.length-22;i>=Math.max(0,b.length-70000);i--)if(dv.getUint32(i,true)===0x06054b50){e=i;break}
  if(e<0)return out;let p=dv.getUint32(e+16,true);const n=dv.getUint16(e+10,true);
  for(let k=0;k<n&&dv.getUint32(p,true)===0x02014b50;k++){
    const m=dv.getUint16(p+10,true),cs=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true),nm=td.decode(b.subarray(p+46,p+46+nl));p+=46+nl+el+cl;
    if(/\.(png|jpe?g|gif|bmp|webp|ico|mp[34]|ttf|otf|woff2?)$/i.test(nm)||cs>3e7)continue;
    try{const ds=lo+30+dv.getUint16(lo+26,true)+dv.getUint16(lo+28,true),raw=b.subarray(ds,ds+cs);
      out.push(td.decode(m===8?await inflate(raw):raw))}catch(x){}}
  return out}
async function fileText(f){const b=new Uint8Array(await f.arrayBuffer()),out=[];
  out.push(b[0]===0xFF&&b[1]===0xFE?new TextDecoder('utf-16le').decode(b):b[0]===0xFE&&b[1]===0xFF?new TextDecoder('utf-16be').decode(b):new TextDecoder('utf-8').decode(b));
  if(b[0]===0x50&&b[1]===0x4B)try{out.push(...await unzipText(b))}catch(e){}
  return out.join('\n')}
function ytFind(txt){
  let s=txt.replace(/\\\//g,'/').replace(/\\u0026/gi,'&').replace(/\\u003d/gi,'=').replace(/&amp;/gi,'&');
  if(/\u0000/.test(s))s+='\n'+s.replace(/\u0000/g,'');
  s+='\n'+s.replace(/%([0-9a-f]{2})/gi,(m,h)=>String.fromCharCode(parseInt(h,16)));
  const vids=new Set(),pls=new Set(),re=/(?<![\w.-])(?:https?:\/\/)?(?:[\w-]+\.)*(?:youtube(?:-nocookie)?\.com|youtu\.be)\/[^\s"'<>)\]\\,]*/gi;
  for(const m of s.matchAll(re)){const u=m[0];let x=/youtu\.be\/([\w-]{11})/i.exec(u)||/[?&]v=([\w-]{11})/.exec(u)||/\/(?:shorts|live|embed|v|e)\/([\w-]{11})/.exec(u);
    if(x)vids.add(x[1]);else{x=/[?&]list=([\w-]+)/.exec(u);if(x&&!/^(WL|LL)$/.test(x[1]))pls.add(x[1])}}
  return{vids,pls}}
async function handleFiles(files){if(!files.length)return;
  const vids=new Set(),pls=new Set();$('#msg').textContent='Reading file\u2026';
  for(const f of files){try{const r=ytFind(await fileText(f));r.vids.forEach(x=>vids.add(x));r.pls.forEach(x=>pls.add(x))}catch(x){}}
  if(!vids.size&&!pls.size){$('#msg').innerHTML='<span class="err">No YouTube links found in the file.</span>';return}
  const L=new Map();vids.forEach(id=>L.set(id,{type:'video',id,title:'Video '+id,thumb:`https://i.ytimg.com/vi/${id}/mqdefault.jpg`,fileSrc:1}));
  let n=0;for(const p of pls){$('#msg').textContent=`Reading playlist ${++n} of ${pls.size}\u2026`;
    try{const d=await api(`/api/playlist?id=${p}&all=1`);d.results.forEach(x=>{if(!L.has(x.id))L.set(x.id,{...x,fileSrc:1})})}catch(x){}}
  const items=[...L.values()];items.forEach(v=>ITEMS.set(v.id,v));
  $('#msg').innerHTML=`<span class="g">Found ${vids.size} video link${vids.size===1?'':'s'}${pls.size?' and '+pls.size+' playlist'+(pls.size>1?'s':''):''} in the file: ${items.length} video${items.length===1?'':'s'} in total.</span>`;
  if(items.length)openQuality(items,{})}
$('#attach').onclick=()=>$('#fileIn').click();
$('#fileIn').onchange=e=>{const f=[...e.target.files];e.target.value='';handleFiles(f)};
let dragN=0;const hasFiles=e=>e.dataTransfer&&[...(e.dataTransfer.types||[])].includes('Files');
addEventListener('dragenter',e=>{if(hasFiles(e)){dragN++;$('#drop').classList.add('show')}});
addEventListener('dragleave',e=>{if(hasFiles(e)){dragN=Math.max(0,dragN-1);if(!dragN)$('#drop').classList.remove('show')}});
addEventListener('dragover',e=>{if(hasFiles(e))e.preventDefault()});
addEventListener('drop',e=>{if(!hasFiles(e))return;e.preventDefault();dragN=0;$('#drop').classList.remove('show');handleFiles([...e.dataTransfer.files])});

ping();setInterval(ping,3000);setInterval(tock,1000);
setInterval(()=>{if(online&&Date.now()-LASTMSG>4000)loadJobs()},2000);
</script>
</body>
</html>
'''


if __name__ == "__main__":
    main()
