"""Bridge between the Android app (Kotlin) and yt_batch.py."""
import importlib
import os
import socket
import sys

_yt = None


def prepare(files_dir, out_dir, ytdlp_dir, bin_dir, lib_dirs):
    global _yt
    os.environ["HOME"] = files_dir
    os.environ["CD_OUT"] = out_dir
    os.environ["CD_YTDLP_DIR"] = ytdlp_dir
    os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")
    if lib_dirs:
        old = os.environ.get("LD_LIBRARY_PATH", "")
        os.environ["LD_LIBRARY_PATH"] = lib_dirs + (os.pathsep + old if old else "")
    os.makedirs(files_dir + "/.tube_local", exist_ok=True)
    _yt = importlib.import_module("yt_batch")


def ytdlp_info():
    i = _yt.ytdlp_latest_info()
    return "%s|%d" % (i["version"], i["size"])


def ytdlp_install():
    _yt.install_wheel()
    importlib.invalidate_caches()
    import yt_dlp
    _yt.yt_dlp = yt_dlp


def ytdlp_present():
    return _yt.yt_dlp is not None


def progress():
    p = _yt.INSTALL_PROGRESS
    return "%s|%d|%d" % (p["stage"], p["done"], p["total"])


def pick_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def serve(port, out_dir):
    from pathlib import Path
    _yt.DEFAULT_OUT = Path(out_dir)      # chosen after the storage permission answer
    sys.argv = ["yt_batch", "--no-browser", "--host", "127.0.0.1", "--port", str(port)]
    _yt.main()
