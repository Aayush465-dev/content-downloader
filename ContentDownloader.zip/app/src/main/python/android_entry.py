"""Bridge between the Android app (Kotlin) and yt_batch.py."""
import importlib
import os
import socket
import sys

_yt = None
_paths = {"bin": "", "ff": "", "lib": ""}
_log = []


def _diag(line):
    _log.append(line)
    try:
        with open(os.environ["CD_FFDIAG"], "w", encoding="utf-8") as f:
            f.write("\n".join(_log[-12:]))
    except Exception:
        pass


def _is_elf(p):
    try:
        with open(p, "rb") as f:
            return f.read(4) == b"\x7fELF"
    except OSError:
        return False


def _try(cmd):
    """start `cmd -version`; True only if it really prints an ffmpeg banner"""
    import subprocess
    try:
        r = subprocess.run(cmd + ["-version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, errors="replace", timeout=30)
        out = (r.stdout or "").strip()
        return (r.returncode == 0 and "ffmpeg version" in out), ("exit %s: %s" % (r.returncode, out[:160].replace("\n", " | ")))
    except Exception as e:
        return False, "%s: %s" % (type(e).__name__, e)


def _launcher(bin_dir, target, via_linker):
    link = os.path.join(bin_dir, "ffmpeg")
    try:
        os.remove(link)
    except OSError:
        pass
    if via_linker:
        with open(link, "w") as f:
            f.write('#!/system/bin/sh\nexec /system/bin/linker64 "%s" "$@"\n' % target)
    else:
        try:
            os.symlink(target, link)
        except OSError:
            import shutil
            shutil.copy(target, link)
    os.chmod(link, 0o755)


def find_ffmpeg(ff_dir, bin_dir):
    """test every possible ffmpeg file the app carries; set up bin/ffmpeg for the first that really runs"""
    os.makedirs(bin_dir, exist_ok=True)
    link = os.path.join(bin_dir, "ffmpeg")
    if os.path.exists(link):
        ok, out = _try([link])
        if ok:
            return True
        _diag("existing launcher failed: " + out)
    cands = []
    for root, _, files in os.walk(ff_dir or "/nonexistent"):
        for f in files:
            p = os.path.join(root, f)
            if "ffmpeg" in f.lower() and _is_elf(p):
                cands.append(p)
    cands.sort(key=lambda p: (os.path.basename(p) != "ffmpeg", os.path.basename(p) != "libffmpeg.so", p))
    if not cands:
        extra = ""
        try:
            with open(os.path.join(os.path.dirname(os.environ["CD_FFDIAG"]), "apk_libs.txt"), encoding="utf-8") as f:
                extra = f.read(500).replace("\n", "; ")
        except Exception:
            pass
        _diag("no ffmpeg program found inside the app | " + extra)
    for c in cands:
        try:
            os.chmod(c, 0o755)
        except OSError:
            pass
        ok, out = _try([c])
        _diag("direct %s -> %s" % (os.path.relpath(c, ff_dir), out))
        if ok:
            _launcher(bin_dir, c, False)
            break
        if os.path.exists("/system/bin/linker64"):
            ok, out = _try(["/system/bin/linker64", c])
            _diag("via linker %s -> %s" % (os.path.basename(c), out))
            if ok:
                _launcher(bin_dir, c, True)
                break
    for root, _, files in os.walk(ff_dir or "/nonexistent"):
        for f in files:
            if "ffprobe" in f.lower() and _is_elf(os.path.join(root, f)):
                lp = os.path.join(bin_dir, "ffprobe")
                try:
                    os.remove(lp)
                    os.symlink(os.path.join(root, f), lp)
                except OSError:
                    pass
    return os.path.exists(link) and _try([link])[0]


def ffmpeg_ok():
    return bool(_yt.ffmpeg_check(True))


def ffmpeg_msg():
    _yt.ffmpeg_check(True)
    return _yt.FF["msg"]


TERMUX = "https://packages.termux.dev/apt/termux-main/"
SKIP = {"termux-exec", "termux-tools", "termux-keyring", "termux-licenses", "termux-core", "apt", "dpkg",
        "bash", "coreutils", "busybox", "procps", "util-linux"}


def _get(url, prog=None):
    import urllib.request as ureq
    req = ureq.Request(url, headers={"User-Agent": "ContentDownloader"})
    buf = bytearray()
    with ureq.urlopen(req, timeout=60) as r:
        while True:
            b = r.read(1 << 16)
            if not b:
                break
            buf += b
            if prog is not None:
                prog["done"] += len(b)
    return bytes(buf)


def _termux_index():
    import gzip
    import lzma
    err = None
    data = None
    for name, dec in (("Packages.xz", lzma.decompress), ("Packages.gz", gzip.decompress), ("Packages", lambda x: x)):
        try:
            data = dec(_get(TERMUX + "dists/stable/main/binary-aarch64/" + name))
            break
        except Exception as e:
            err = e
    if data is None:
        raise RuntimeError("could not read the Termux package list: %s" % err)
    pk = {}
    for st in data.decode("utf-8", "replace").split("\n\n"):
        d = {}
        for line in st.split("\n"):
            if ": " in line and not line.startswith(" "):
                k, v = line.split(": ", 1)
                d[k] = v
        if "Package" in d:
            pk[d["Package"]] = d
    return pk


def _termux_resolve(pk, root="ffmpeg"):
    seen, order, q = set(), [], [root]
    while q:
        n = q.pop(0)
        if n in seen or n in SKIP or n not in pk:
            continue
        seen.add(n)
        order.append(n)
        for part in pk[n].get("Depends", "").split(","):
            name = part.split("|")[0].strip().split(" ")[0].strip()
            if name:
                q.append(name)
    return order


def _deb_data(deb):
    if deb[:8] != b"!<arch>\n":
        raise RuntimeError("not a .deb file")
    i = 8
    while i + 60 <= len(deb):
        hdr = deb[i:i + 60]
        name = hdr[:16].decode("ascii", "replace").strip().rstrip("/")
        size = int(hdr[48:58].decode().strip())
        if name.startswith("data.tar"):
            return name, deb[i + 60:i + 60 + size]
        i += 60 + size + (size & 1)
    raise RuntimeError("no data inside .deb")


def _extract_deb(deb, bin_dir, lib_dir):
    import io
    import tarfile
    name, body = _deb_data(deb)
    mode = {"xz": "r:xz", "gz": "r:gz", "bz2": "r:bz2"}.get(name.rsplit(".", 1)[-1])
    if not mode:
        raise RuntimeError("unsupported package format " + name)
    with tarfile.open(fileobj=io.BytesIO(body), mode=mode) as t:
        for m in t:
            marker = "files/usr/"
            if marker not in m.name:
                continue
            rel = m.name.split(marker, 1)[1]
            base = os.path.basename(rel)
            if rel == "bin/ffmpeg" and m.isfile():
                dst = os.path.join(bin_dir, "ffmpeg")
                with open(dst + ".new", "wb") as o:
                    o.write(t.extractfile(m).read())
                os.chmod(dst + ".new", 0o755)
                os.replace(dst + ".new", dst)
            elif rel.startswith("lib/") and rel.count("/") == 1 and ".so" in base:
                dst = os.path.join(lib_dir, base)
                if m.issym():
                    try:
                        os.remove(dst)
                    except OSError:
                        pass
                    os.symlink(m.linkname, dst)
                elif m.isfile():
                    with open(dst, "wb") as o:
                        o.write(t.extractfile(m).read())
                    os.chmod(dst, 0o755)


def ffmpeg_download():
    """fallback: download the Android build of ffmpeg (and the libraries it needs) from the Termux servers"""
    try:
        return _ffmpeg_download()
    except Exception as e:
        _diag("download failed: %s: %s" % (type(e).__name__, e))
        try:
            _yt.INSTALL_PROGRESS["stage"] = "done"
        except Exception:
            pass
        return False


def _ffmpeg_download():
    prog = _yt.INSTALL_PROGRESS
    bin_dir, lib_dir = _paths["bin"], _paths["lib"]
    os.makedirs(bin_dir, exist_ok=True)
    os.makedirs(lib_dir, exist_ok=True)
    prog.update(stage="Reading ffmpeg package list", done=0, total=0)
    pk = _termux_index()
    order = _termux_resolve(pk)
    if "ffmpeg" not in order:
        raise RuntimeError("ffmpeg is not in the package list")
    prog.update(stage="Downloading ffmpeg", done=0, total=sum(int(pk[n].get("Size") or 0) for n in order))
    for n in order:
        _extract_deb(_get(TERMUX + pk[n]["Filename"], prog), bin_dir, lib_dir)
    prog["stage"] = "done"
    ok, out = _try([os.path.join(bin_dir, "ffmpeg")])
    _diag("downloaded %d packages; ffmpeg -> %s" % (len(order), out))
    return ok


def prepare(files_dir, out_dir, ytdlp_dir, bin_dir, lib_dirs, ff_dir=""):
    global _yt
    os.environ["HOME"] = files_dir
    os.environ["CD_OUT"] = out_dir
    os.environ["CD_YTDLP_DIR"] = ytdlp_dir
    os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")
    if lib_dirs:
        old = os.environ.get("LD_LIBRARY_PATH", "")
        os.environ["LD_LIBRARY_PATH"] = lib_dirs + (os.pathsep + old if old else "")
    os.makedirs(files_dir + "/.tube_local", exist_ok=True)
    os.environ["CD_FFDIAG"] = files_dir + "/ffmpeg_diag.txt"
    tlib = files_dir + "/tlib"
    os.makedirs(tlib, exist_ok=True)
    os.environ["LD_LIBRARY_PATH"] = tlib + os.pathsep + os.environ.get("LD_LIBRARY_PATH", "")
    _paths["bin"], _paths["ff"], _paths["lib"] = bin_dir, ff_dir, tlib
    try:
        find_ffmpeg(ff_dir, bin_dir)
    except Exception as e:
        _diag("find_ffmpeg crashed: %s: %s" % (type(e).__name__, e))
    _yt = importlib.import_module("yt_batch")


def ytdlp_info():
    i = _yt.ytdlp_latest_info()
    return "%s|%d" % (i["version"], i["size"])


def ytdlp_install():
    _yt.install_wheel()
    importlib.invalidate_caches()
    import yt_dlp
    _yt.yt_dlp = yt_dlp


def ytdlp_present():
    return _yt.yt_dlp is not None


def progress():
    p = _yt.INSTALL_PROGRESS
    return "%s|%d|%d" % (p["stage"], p["done"], p["total"])


def pick_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def serve(port, out_dir):
    from pathlib import Path
    _yt.DEFAULT_OUT = Path(out_dir)      # chosen after the storage permission answer
    sys.argv = ["yt_batch", "--no-browser", "--host", "127.0.0.1", "--port", str(port)]
    _yt.main()
