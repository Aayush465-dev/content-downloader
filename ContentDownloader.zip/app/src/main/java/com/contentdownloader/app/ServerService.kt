package com.contentdownloader.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Keeps the downloader alive in the background and shows what it is doing. */
class ServerService : Service() {
    private var started = false
    private var wake: PowerManager.WakeLock? = null
    @Volatile private var alive = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            alive = false
            try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) { }
            stopForeground(true)
            stopSelf()
            android.os.Process.killProcess(android.os.Process.myPid())
            return START_NOT_STICKY
        }
        startForeground(1, build("Starting\u2026", "CONTENT DOWNLOADER", null, 0, false))
        if (!started) {
            started = true
            Thread { try { Core.serveForever(this) } catch (e: Throwable) { e.printStackTrace() } }.start()
            Thread { poll() }.start()
        }
        return START_STICKY
    }

    private fun clip(s: String, n: Int) = if (s.length > n) s.substring(0, n - 1).trim() + "\u2026" else s

    private fun left(sec: Long): String = when {
        sec <= 0 -> ""
        sec < 90 -> "$sec s left"
        sec < 5400 -> "${(sec + 30) / 60} min left"
        else -> "${sec / 3600} h ${(sec % 3600) / 60} min left"
    }

    private fun poll() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "contentdownloader:dl")
        var last = ""
        while (alive) {
            var title = "CONTENT DOWNLOADER"
            var text = "Starting\u2026"
            var big: String? = null
            var pct = 0
            var showBar = false
            var busy = false
            val p = Core.port
            if (p != 0) {
                try {
                    val c = URL("http://127.0.0.1:$p/api/jobs").openConnection() as HttpURLConnection
                    c.connectTimeout = 1500; c.readTimeout = 2500
                    val js = JSONObject(c.inputStream.bufferedReader().readText())
                    c.disconnect()
                    val now = js.optDouble("now", 0.0)
                    val s = js.optJSONObject("summary")
                    val queued = s?.optInt("queued") ?: 0
                    val speed = s?.optDouble("speed") ?: 0.0
                    val arr = js.optJSONArray("jobs")
                    val lines = ArrayList<String>()
                    var first: String? = null
                    var firstLine = ""
                    var live = 0
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val j = arr.getJSONObject(i)
                            val st = j.optString("stage")
                            if (st != "downloading" && st != "merging" && st != "uploading") continue
                            live++
                            val verb = when (st) { "merging" -> "Merging"; "uploading" -> "Saving"; else -> "Downloading" }
                            val pc = when (st) {
                                "merging" -> j.optDouble("merge", 0.0)
                                "uploading" -> j.optDouble("up", 0.0)
                                else -> j.optDouble("dl", 0.0)
                            }.toInt().coerceIn(0, 100)
                            val eta = j.optDouble("eta_at", 0.0)
                            val lf = if (eta > 0 && now > 0) left((eta - now).toLong()) else ""
                            val sp = j.optDouble("speed", 0.0)
                            val paused = j.optBoolean("paused", false)
                            val parts = ArrayList<String>()
                            parts.add(if (paused) "Paused $pc%" else "$verb $pc%")
                            if (!paused && sp > 0 && st == "downloading") parts.add(String.format(Locale.US, "%.1f MB/s", sp / 1e6))
                            if (!paused && lf.isNotEmpty()) parts.add(lf)
                            val t = j.optString("title", "Video")
                            if (first == null) { first = t; firstLine = parts.joinToString(" \u00b7 "); pct = pc; showBar = true }
                            if (lines.size < 4) lines.add("\u2022 " + clip(t, 46) + "\n   " + parts.joinToString(" \u00b7 "))
                        }
                    }
                    busy = live + queued > 0
                    if (live > 0) {
                        title = if (live == 1) clip(first ?: "Video", 60) else "$live downloads"
                        text = if (live == 1) firstLine else "$firstLine \u00b7 total " + String.format(Locale.US, "%.1f MB/s", speed / 1e6)
                        if (queued > 0) text += " \u00b7 $queued waiting"
                        big = lines.joinToString("\n") + (if (queued > 0) "\n+ $queued waiting" else "")
                    } else if (queued > 0) {
                        text = "$queued waiting"
                    } else {
                        text = "Ready"
                    }
                } catch (e: Exception) { text = "Starting\u2026" }
            }
            try {
                if (busy && wake?.isHeld == false) wake?.acquire()
                if (!busy && wake?.isHeld == true) wake?.release()
            } catch (e: Exception) { }
            val sig = "$title|$text|$pct|$big"
            if (sig != last) {
                last = sig
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .notify(1, build(text, title, big, pct, showBar))
            }
            try { Thread.sleep(2000) } catch (e: InterruptedException) { }
        }
    }

    private fun build(text: String, title: String, big: String?, pct: Int, showBar: Boolean): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("dl", "Downloads", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ServerService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, "dl")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setSubText("CONTENT DOWNLOADER")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Close app", stop)
        if (big != null) b.setStyle(NotificationCompat.BigTextStyle().bigText(big))
        if (showBar) b.setProgress(100, pct, false)
        return b.build()
    }

    override fun onDestroy() { alive = false; super.onDestroy() }
}
