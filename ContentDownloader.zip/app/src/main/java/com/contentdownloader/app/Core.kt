package com.contentdownloader.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.system.Os
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/** Everything that talks to Python / ffmpeg lives here. */
object Core {
    @Volatile var port = 0
    @Volatile private var prepared = false
    @Volatile private var serving = false

    fun hasStorage(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 ||
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Default save folder: Download/Content Downloader (or an app folder if storage was denied) */
    fun outDir(ctx: Context): File {
        val base = if (hasStorage(ctx)) Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        else (ctx.getExternalFilesDir(null) ?: ctx.filesDir)
        return File(base, "Content Downloader")
    }

    private fun ffmpegSource(ctx: Context): File? {
        val dir = File(ctx.applicationInfo.nativeLibraryDir)
        val all = dir.listFiles()?.filter { it.isFile && it.name.contains("ffmpeg") } ?: return null
        return all.firstOrNull { it.name.endsWith(".zip.so") } ?: all.firstOrNull()
    }

    /** size of the bundled ffmpeg package in bytes (0 if missing) */
    fun ffmpegSize(ctx: Context): Long = ffmpegSource(ctx)?.length() ?: 0L

    private fun isZip(f: File): Boolean = try {
        FileInputStream(f).use { val a = it.read(); val b = it.read(); a == 0x50 && b == 0x4B }
    } catch (e: Exception) { false }

    /** unpack ffmpeg once per app version; returns the colon list of library folders */
    private fun setupFfmpeg(ctx: Context): String {
        val dest = File(ctx.filesDir, "ffmpeg")
        val bin = File(ctx.filesDir, "bin").apply { mkdirs() }
        val stamp = File(dest, ".stamp")
        val want = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime.toString()
        val src = ffmpegSource(ctx)
        if (src == null) return ""
        if (!(stamp.exists() && stamp.readText() == want)) {
            dest.deleteRecursively(); dest.mkdirs()
            if (isZip(src)) {
                val root = dest.canonicalPath + File.separator
                ZipInputStream(FileInputStream(src)).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        if (e.isDirectory) continue
                        val t = File(dest, e.name)
                        if (!t.canonicalPath.startsWith(root)) continue
                        t.parentFile?.mkdirs()
                        FileOutputStream(t).use { o -> z.copyTo(o) }
                    }
                }
                // zip "symlinks" are stored as tiny files holding the target name: turn them into copies
                dest.walkTopDown().filter { it.isFile && it.length() in 1..200 }.toList().forEach { f ->
                    val name = try { f.readText().trim() } catch (e: Exception) { "" }
                    val tgt = File(f.parentFile, name)
                    if (name.isNotEmpty() && !name.contains('\n') && tgt.isFile && tgt != f) tgt.copyTo(f, overwrite = true)
                }
            } else {
                src.copyTo(File(dest, "libffmpeg.so"), overwrite = true)
            }
            dest.walkTopDown().filter { it.isFile }.forEach { it.setReadable(true, false); it.setExecutable(true, false) }
            stamp.writeText(want)
        }
        val exe = dest.walkTopDown().firstOrNull { it.isFile && (it.name == "libffmpeg.so" || it.name == "ffmpeg") }
        if (exe != null) {
            val link = File(bin, "ffmpeg"); link.delete()
            try { Os.symlink(exe.absolutePath, link.absolutePath) } catch (e: Exception) { exe.copyTo(link, true); link.setExecutable(true, false) }
        }
        val probe = dest.walkTopDown().firstOrNull { it.isFile && (it.name == "libffprobe.so" || it.name == "ffprobe") }
        if (probe != null) {
            val link = File(bin, "ffprobe"); link.delete()
            try { Os.symlink(probe.absolutePath, link.absolutePath) } catch (e: Exception) { }
        }
        return dest.walkTopDown().filter { it.isFile && (it.name.endsWith(".so") || it.name.contains(".so.")) }
            .map { it.parentFile!!.absolutePath }.distinct().joinToString(":")
    }

    @Synchronized
    fun prepare(ctx: Context) {
        if (prepared) return
        val app = ctx.applicationContext
        if (!Python.isStarted()) Python.start(AndroidPlatform(app))
        val libs = setupFfmpeg(app)
        py().callAttr(
            "prepare", app.filesDir.absolutePath, outDir(app).absolutePath,
            File(app.filesDir, "ytdlp").absolutePath, File(app.filesDir, "bin").absolutePath, libs
        )
        prepared = true
    }

    private fun py() = Python.getInstance().getModule("android_entry")

    /** "version|bytes" of the newest yt-dlp on PyPI */
    fun ytdlpInfo(): Pair<String, Long> {
        val s = py().callAttr("ytdlp_info").toString().split("|")
        return Pair(s[0], s[1].toLong())
    }

    /** size lookup used by the setup screen (needs Python, not ffmpeg) */
    fun prepareForInfo(ctx: Context): Pair<String, Long> {
        prepare(ctx)
        return ytdlpInfo()
    }

    fun ytdlpInstall() { py().callAttr("ytdlp_install") }
    fun ytdlpPresent(): Boolean = py().callAttr("ytdlp_present").toBoolean()

    /** (stage, bytesDone, bytesTotal) */
    fun progress(): Triple<String, Long, Long> {
        val s = py().callAttr("progress").toString().split("|")
        return Triple(s[0], s[1].toLong(), s[2].toLong())
    }

    /** blocks forever (runs the web server); call from a background thread */
    fun serveForever(ctx: Context) {
        if (serving) return
        serving = true
        prepare(ctx)
        val p = py().callAttr("pick_port").toInt()
        port = p
        py().callAttr("serve", p, outDir(ctx.applicationContext).absolutePath)
    }
}
