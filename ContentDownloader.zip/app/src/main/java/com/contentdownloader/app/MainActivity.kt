package com.contentdownloader.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var polling = false

    // setup screen widgets
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var go: Button

    private val prefs get() = getSharedPreferences("app", MODE_PRIVATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (prefs.getBoolean("setup_done", false)) showMain() else showSetup()
    }

    private fun mb(n: Long) = String.format(Locale.US, "%.1f MB", n / 1048576.0)

    // ------------------------------------------------------------------ first-time setup
    private fun showSetup() {
        val pad = (28 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(pad, pad, pad, pad)
        }
        col.addView(TextView(this).apply {
            text = "CONTENT DOWNLOADER"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        info = TextView(this).apply {
            text = "Setting up\u2026"; textSize = 15f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad / 2)
        }
        col.addView(info)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; isIndeterminate = true }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        status = TextView(this).apply {
            textSize = 13f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, pad / 2, 0, pad / 2)
            text = "This happens only once."
        }
        col.addView(status)
        go = Button(this).apply {
            text = "Try again"; visibility = View.GONE
            setOnClickListener { visibility = View.GONE; begin() }
        }
        col.addView(go)
        setContentView(col)
        begin()
    }

    private fun begin() {
        info.text = "Setting up\u2026"
        bar.isIndeterminate = true
        if (Build.VERSION.SDK_INT >= 23 && !Core.hasStorage(this)) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 7)
        } else runSetup()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 7) runSetup()
    }

    private fun runSetup() {
        polling = true
        val tick = object : Runnable {
            override fun run() {
                try {
                    val (stage, done, total) = Core.progress()
                    if (stage.isNotEmpty() && stage != "done" && total > 0) {
                        bar.isIndeterminate = false
                        val pc = (done * 100 / total).toInt().coerceIn(0, 100)
                        bar.progress = pc * 10
                        info.text = "Setting up\u2026 $pc%"
                    }
                } catch (e: Throwable) { }
                if (polling) ui.postDelayed(this, 300)
            }
        }
        ui.post(tick)
        Thread {
            try {
                Core.prepare(this)
                Core.ytdlpInstall()
                if (!Core.ffmpegOk()) Core.ffmpegDownload()
                polling = false
                prefs.edit().putBoolean("setup_done", true).apply()
                ui.post { showMain() }
            } catch (e: Throwable) {
                polling = false
                ui.post {
                    bar.isIndeterminate = false
                    info.text = "Setup could not finish"
                    status.text = "Check your internet connection and try again."
                    go.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ the app itself (WebView)
    private fun showMain() {
        val w = WebView(this)
        web = w
        val loading = TextView(this).apply {
            text = "Starting\u2026"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val root = android.widget.FrameLayout(this)
        root.addView(w, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(loading, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val h = r.url.host ?: ""
                if (h == "127.0.0.1" || h == "localhost") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }
            override fun onPageFinished(v: WebView, url: String) { loading.visibility = View.GONE }
        }
        w.setDownloadListener { _, _, _, _, _ ->
            Toast.makeText(this, "Finished files are in Download/Content Downloader", Toast.LENGTH_LONG).show()
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try {
                    startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 9)
                    true
                } catch (e: Exception) { chooser = null; false }
            }
            override fun onJsAlert(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }.show(); return true
            }
            override fun onJsConfirm(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }.show(); return true
            }
            override fun onJsPrompt(v: WebView, url: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val et = EditText(this@MainActivity).apply { setText(d ?: "") }
                AlertDialog.Builder(this@MainActivity).setMessage(m).setView(et).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> r.confirm(et.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }.show(); return true
            }
            override fun onConsoleMessage(c: ConsoleMessage?): Boolean = true
        }

        val svc = Intent(this, ServerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)

        Thread {
            var ok = false
            for (i in 0 until 180) {
                val p = Core.port
                if (p != 0) {
                    try {
                        val c = URL("http://127.0.0.1:$p/api/ping").openConnection() as HttpURLConnection
                        c.connectTimeout = 1000; c.readTimeout = 1500
                        if (c.responseCode == 200) { ok = true; c.disconnect(); break }
                        c.disconnect()
                    } catch (e: Exception) { }
                }
                try { Thread.sleep(500) } catch (e: InterruptedException) { }
            }
            ui.post {
                if (ok) w.loadUrl("http://127.0.0.1:${Core.port}/")
                else loading.text = "The app could not start. Close it fully and open it again."
            }
        }.start()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 9) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            chooser = null
        }
    }

    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else moveTaskToBack(true)
    }
}
