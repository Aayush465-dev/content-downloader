plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.contentdownloader.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.contentdownloader.app"
        minSdk = 24
        // 28 on purpose: Android only lets apps run unpacked programs (ffmpeg) from their own folder when targetSdk <= 28
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { jniLibs { useLegacyPackaging = true } }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        buildPython("python3")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // only used for the ready-made ffmpeg build (arm64) it carries inside
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
